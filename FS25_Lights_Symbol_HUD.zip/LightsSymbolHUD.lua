LightsSymbolHUD = {}
local LightsSymbolHUD_mt = Class(LightsSymbolHUD, HUDDisplayElement)

-- All HUD dimensions are expressed in the same pixel-to-screen scaling
-- system used by the vanilla speedometer. The five slots themselves are
-- fixed; only the whole HUD scales with the speedometer/display resolution.
LightsSymbolHUD.ICON_SIZE = {42, 42}
-- Work-light icons use the same 42 px icon box as the standard light symbols.
-- The artwork itself has transparent margins, so its visible size remains
-- optically consistent with the existing high/low-beam symbols.
-- Work-light icons reduced by 20% from the matched 42 px size.
-- Both use identical dimensions; the existing slot-centering/alignment remains unchanged.
LightsSymbolHUD.WORK_FRONT_ICON_SIZE = {33.6, 33.6}
LightsSymbolHUD.WORK_BACK_ICON_SIZE = {33.6, 33.6}
LightsSymbolHUD.SLOT_HEIGHT = 48
LightsSymbolHUD.ICON_GAP = -2
LightsSymbolHUD.LEFT_GAP = 12
LightsSymbolHUD.BLINKER_ICON_SIZE = {32, 32}
LightsSymbolHUD.SLIP_ICON_SIZE = {32.34, 32.34}
LightsSymbolHUD.SLIP_TEXT_SIZE = 11.56
LightsSymbolHUD.SLIP_THRESHOLD_PERCENT = 1.0
LightsSymbolHUD.SLIP_SMOOTH_UP = 0.28
LightsSymbolHUD.SLIP_SMOOTH_DOWN = 0.20
LightsSymbolHUD.SLIP_DISPLAY_STEP_MS = 50
LightsSymbolHUD.SLIP_ZERO_HOLD_MS = 1000
LightsSymbolHUD.SLIP_TARGET_MAX_STEP = 10.0

LightsSymbolHUD.ICONS = {
    low = "resources/low.dds",
    high = "resources/high.dds",
    workFront = "resources/work_front.dds",
    workBack = "resources/work_back.dds",
    beacon = "resources/beacon.dds"
}

-- Fixed light slots:
-- 4 = beacon, 5 = front work light, 6 = rear work light.
LightsSymbolHUD.SLOT_ORDER = {
    "blinkers",
    "low",
    "high",
    "beacon",
    "workFront",
    "workBack"
}

-- Optical X corrections for the actual artwork inside each 128px DDS.
-- The files have different transparent margins, so geometric slot-centering
-- alone does not visually center the symbols. Values are derived from the
-- actual alpha bounding boxes of the supplied DDS files.
LightsSymbolHUD.ICON_OPTICAL_X_OFFSET = {
    -- Optical alignment V3: align the VISIBLE RIGHT EDGE of every light
    -- symbol to the low-beam reference line. This is more suitable for a
    -- narrow HUD column than center alignment because the symbols have
    -- different widths and transparent margins.
    -- Slots 2/3/4: 4 px further left for improved optical alignment.
    low = -4.00,
    high = -4.00,
    workFront = 1.36,
    -- Rear work-light artwork: 4 px left from the previous optical position.
    workBack = 3.96,
    beacon = 5.84
}

-- Wheel-slip slots are explicitly 5 and 6:
-- front wheel slip = slot 5, rear wheel slip = slot 6.
-- These are independent display rows and do not alter the light slots.
LightsSymbolHUD.SLIP_SLOT_ORDER = {
    front = 5,
    rear = 6
}

-- Preserve the currently confirmed position while making it an explicit
-- slot definition for the new layout system.
LightsSymbolHUD.SLIP_SLOT_Y_OFFSET = -22

-- Positioning/debug mode: keep both slip slots visible while finding their
-- final position. This does not alter slip calculation.
LightsSymbolHUD.SLIP_POSITION_DEBUG = true

-- Startup release: actual wheel/axle rotation is the physical indication
-- that wheel physics has become active. Ground contact is NOT used.
LightsSymbolHUD.STARTUP_AXLE_SPEED_THRESHOLD = 0.05


function LightsSymbolHUD:new(speedMeter, modDirectory)
    local self = setmetatable({}, LightsSymbolHUD_mt)

    self.speedMeter = speedMeter
    self.modDirectory = modDirectory
    self.vehicle = nil
    self.isCalculated = false
    self.icons = {}
    self.inactiveIcons = {}
    self.blinkerIcons = {}
    self.blinkerState = 0
    self.slipFrontPercent = 0
    self.slipRearPercent = 0
    self.slipDisplayLabels = {front = "V", rear = "H"}
    self.slipFrontTarget = 0
    self.slipRearTarget = 0
    self.slipFilteredTargetFront = 0
    self.slipFilteredTargetRear = 0

    self.slipLastSmoothTime = 0
    self.slipZeroSince = nil
    self.positions = {}
    self.slipPositions = {}
    self.slipIcons = {}
    self.background = nil

    return self
end

function LightsSymbolHUD:load()
    self:createElements()
    self:setVehicle(nil)
end

-- Convert pixel-based atlas rectangles to the native FS25 UV format.
-- GuiUtils.getUVs() is the GIANTS-supported conversion and returns the
-- 8-value UV array required by Overlay:setUVs().
local function getNormalizedUVs(rect)
    if rect == nil or rect[1] == nil or rect[2] == nil or rect[3] == nil or rect[4] == nil then
        return {0, 0, 0, 1, 1, 0, 1, 1}
    end

    local x, y, width, height = rect[1], rect[2], rect[3], rect[4]
    return GuiUtils.getUVs(
        string.format("%dpx %dpx %dpx %dpx", x, y, width, height),
        {64, 64},
        {0, 0, 0, 1, 1, 0, 1, 1}
    )
end

function LightsSymbolHUD:createElements()
    local width, height =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.ICON_SIZE)
    local workFrontWidth, workFrontHeight =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.WORK_FRONT_ICON_SIZE)
    local workBackWidth, workBackHeight =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.WORK_BACK_ICON_SIZE)

    for name, filename in pairs(LightsSymbolHUD.ICONS) do
        local elementWidth, elementHeight = width, height

        if name == "workFront" then
            elementWidth, elementHeight = workFrontWidth, workFrontHeight
        elseif name == "workBack" then
            elementWidth, elementHeight = workBackWidth, workBackHeight
        end

        local overlay = Overlay.new(
            Utils.getFilename(filename, self.modDirectory),
            0, 0, elementWidth, elementHeight
        )

        local element = HUDElement.new(overlay)

        -- Low-beam status is intentionally green; all other icons keep
        -- their original texture colors.
        if name == "low" then
            overlay:setColor(0.2, 1.0, 0.2, 1.0)
        end

        element:setVisible(false)
        self.icons[name] = element

        -- Dedicated neutral-grey inactive variant. This avoids color
        -- contamination from the original green/blue/amber textures.
        local inactiveOverlay = Overlay.new(
            Utils.getFilename("resources/inactive_" .. name .. ".dds", self.modDirectory),
            0, 0, elementWidth, elementHeight
        )
        inactiveOverlay:setColor(1.0, 1.0, 1.0, 0.50)
        local inactiveElement = HUDElement.new(inactiveOverlay)
        inactiveElement:setVisible(false)
        self.inactiveIcons[name] = inactiveElement
    end

    local blinkWidth, blinkHeight =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.BLINKER_ICON_SIZE)

    self.blinkerIcons = {}

    local blinkerFiles = {
        left = "resources/blink_left.dds",
        right = "resources/blink_right.dds",
        hazard = "resources/blink_hazard.dds"
    }

    for state, filename in pairs(blinkerFiles) do
        local iconWidth = blinkWidth
        local iconHeight = blinkHeight

        -- Only the left/right indicator symbols are reduced by 30%.
        -- Hazard remains at its existing size.
        if state == "left" or state == "right" then
            -- Left/right blinkers use the same size as the other light symbols.
            iconWidth = blinkWidth
            iconHeight = blinkHeight
        end

        local overlay = Overlay.new(
            Utils.getFilename(filename, self.modDirectory),
            0, 0, iconWidth, iconHeight
        )

        self.blinkerIcons[state] = HUDElement.new(overlay)
        self.blinkerIcons[state]:setVisible(false)
    end

    local slipWidth, slipHeight =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.SLIP_ICON_SIZE)

    self.slipIcons = {}
    for _, name in ipairs({"front", "rear"}) do
        local overlay = Overlay.new(
            Utils.getFilename("resources/wheel_slip.dds", self.modDirectory),
            0, 0, slipWidth, slipHeight
        )
        local element = HUDElement.new(overlay)
        element:setVisible(false)
        self.slipIcons[name] = element
    end

    self.slipIconSize = {slipWidth, slipHeight}

    self.iconSizes = {
        blinkers = {blinkWidth, blinkHeight},
        low = {width, height},
        high = {width, height},
        workFront = {workFrontWidth, workFrontHeight},
        workBack = {workBackWidth, workBackHeight},
        beacon = {width, height}
    }

    self.slotHeight = self.speedMeter:scalePixelToScreenHeight(
        LightsSymbolHUD.SLOT_HEIGHT
    )

    self.gap = self.speedMeter:scalePixelToScreenHeight(
        LightsSymbolHUD.ICON_GAP
    )

    -- The distance to the vanilla speedometer scales with the speedometer.
    _, self.leftGap = self.speedMeter:scalePixelToScreenVector({
        LightsSymbolHUD.LEFT_GAP, 0
    })

    -- AutoDrive-style background:
    -- one single GIANTS base-UI overlay, using the same native background UVs
    -- as AutoDrive. No composed corners/side pieces and no custom background DDS.
    self.background = Overlay.new(g_baseUIFilename, 0, 0, 0, 0)
    self.background:setUVs(g_colorBgUVs)
    self.background:setColor(0, 0, 0, 0.55)

    self.isCalculated = false
end

function LightsSymbolHUD:delete()
    for _, element in pairs(self.icons) do
        if element ~= nil then
            element:delete()
        end
    end

    for _, element in pairs(self.inactiveIcons) do
        if element ~= nil then
            element:delete()
        end
    end

    for _, element in pairs(self.blinkerIcons) do
        if element ~= nil then
            element:delete()
        end
    end

    for _, element in pairs(self.slipIcons) do
        if element ~= nil then
            element:delete()
        end
    end

    self.icons = {}
    self.inactiveIcons = {}
    self.blinkerIcons = {}
    self.slipIcons = {}
    self.positions = {}
    self.slipPositions = {}

    if self.background ~= nil then
        self.background:delete()
        self.background = nil
    end
end

function LightsSymbolHUD:setVehicle(vehicle)
    self.vehicle = vehicle

    -- Do not move/recalculate slots based on which lights are active.
    -- The five HUD slots are always fixed relative to the speedometer.
    self.isCalculated = false

    for _, element in pairs(self.icons) do
        element:setVisible(false)
    end

    for _, element in pairs(self.inactiveIcons) do
        element:setVisible(false)
    end

    for _, element in pairs(self.blinkerIcons) do
        element:setVisible(false)
    end

    self.blinkerState = 0
    self.slipFrontPercent = 0
    self.slipRearPercent = 0
    self.slipFrontTarget = 0
    self.slipRearTarget = 0
    self.slipFilteredTargetFront = 0
    self.slipFilteredTargetRear = 0
    self.slipLastSmoothTime = 0
    self.slipZeroSince = nil
    for _, element in pairs(self.slipIcons) do
        element:setVisible(false)
    end
end

function LightsSymbolHUD:calculatePosition()
    if self.speedMeter == nil or self.speedMeter.speedBg == nil then
        return false
    end

    local bg = self.speedMeter.speedBg

    -- Anchor the complete HUD to the vanilla speedometer.
    -- This keeps the relationship correct at 1080p, 1440p, 4K, etc.
    local rightEdge = bg.x - self.leftGap

    local totalHeight =
        self.slotHeight * #LightsSymbolHUD.SLOT_ORDER
        + self.gap * (#LightsSymbolHUD.SLOT_ORDER - 1)

    local firstSlotTop =
        bg.y + (bg.height + totalHeight) * 0.5

    self.positions = {}

    local bgPadding = self.speedMeter:scalePixelToScreenHeight(2)
    local hudWidth = 0
    for _, name in ipairs(LightsSymbolHUD.SLOT_ORDER) do
        hudWidth = math.max(hudWidth, self.iconSizes[name][1])
    end

    local hudHeight =
        self.slotHeight * #LightsSymbolHUD.SLOT_ORDER
        + self.gap * (#LightsSymbolHUD.SLOT_ORDER - 1)

    local hudX = rightEdge - hudWidth - bgPadding
    local hudBottom = firstSlotTop - hudHeight
    local hudBgWidth = hudWidth + bgPadding * 2
    -- Background starts at the upper edge of the blinker slot.
    -- Slip symbols/percentages are inside the same two-column HUD area;
    -- do not reserve an extra background row above the blinker slot.
    local hudBgHeight = hudHeight + bgPadding * 2

    for index, name in ipairs(LightsSymbolHUD.SLOT_ORDER) do
        local slotTop =
            firstSlotTop
            - (index - 1) * (self.slotHeight + self.gap)

        local size = self.iconSizes[name]
        local opticalX = LightsSymbolHUD.ICON_OPTICAL_X_OFFSET[name] or 0
        local iconX = hudX + (hudWidth - size[1]) * 0.5
            + self.speedMeter:scalePixelToScreenWidth(opticalX)

        -- Every icon owns its own fixed slot. The icon itself is centered
        -- vertically inside that slot, while its right edge is aligned.
        local iconY =
            slotTop - (self.slotHeight + size[2]) * 0.5

        self.positions[name] = {iconX, iconY}
    end

    -- The light column keeps its exact existing position.
    local rightHudX = hudX
    local rightHudWidth = hudWidth

    -- Own slip slots: calculate a separate left column from the current
    -- confirmed position. The right-hand light slots are not moved.
    local firstPos = self.positions.blinkers
    if firstPos ~= nil then
        local step = self.slotHeight + self.gap
        local textSize = self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.SLIP_TEXT_SIZE)
        local probeText = "H 100%"
        local textWidth = getTextWidth(textSize, probeText)
        local textRight = firstPos[1]
        local textLeft = textRight - textWidth

        -- The wheel symbol sits above the text and is centered over the
        -- maximum text width. This keeps the group stable for 0..100%.
        local iconGap = self.speedMeter:scalePixelToScreenHeight(2)
        local slipX = textLeft + (textWidth - self.slipIconSize[1]) * 0.5
        -- Move both wheel-slip groups 24 px upward for a more homogeneous
        -- spacing relative to the light-symbol column.
        -- Final position: 12 px upward relative to the original position.
        -- Front remains at +12 px; rear is 4 px lower for improved spacing.
        -- Explicit wheel-slip/light row anchors:
        -- slot 5 = front work light + front slip
        -- slot 6 = rear work light + rear slip.
        -- The two indicators use the same screen position so their visible
        -- centers stay aligned. Their artwork-specific transparent margins
        -- are compensated by the tiny center correction below.
        local workFrontCenterCorrection =
            self.speedMeter:scalePixelToScreenHeight(0.5)
        local workBackCenterCorrection =
            self.speedMeter:scalePixelToScreenHeight(0.5)

        -- Keep the work-light symbols in the LIGHT column.
        -- Only their vertical position is synchronized with the slip rows.
        -- The slip symbols remain in their own left-hand column.
        local workFrontX = self.positions.workFront[1]
        local workBackX = self.positions.workBack[1]
        local slipIconYFront =
            self.positions.workFront[2]
            + workFrontCenterCorrection
            + self.speedMeter:scalePixelToScreenHeight(9)
        local slipIconYRear =
            self.positions.workBack[2]
            + workBackCenterCorrection
            + self.speedMeter:scalePixelToScreenHeight(9)

        self.slipPositions.front = {slipX, slipIconYFront}
        self.slipPositions.rear = {slipX, slipIconYRear}

        -- LEFT blinker: slot 1 of the slip-symbol column, row 2.
        -- RIGHT blinker and hazard remain in the original row-1 blinker slot.
        -- The position is assigned only after slipX is finalized, avoiding
        -- any dependency from the main slot layout on the blinker layout.
        self.blinkerPositions = self.blinkerPositions or {}
        self.blinkerPositions.left = {
            slipX,
            self.positions.blinkers[2]
        }

        -- Same Y as the corresponding slip symbol, but retain the original
        -- light-column X position and its optical correction.
        self.positions.workFront[1] = workFrontX
        self.positions.workFront[2] = slipIconYFront
        self.positions.workBack[1] = workBackX
        self.positions.workBack[2] = slipIconYRear

        -- Fixed background size: include the complete slip group, but do not
        -- resize it while driving.
        local slipLeft = textLeft
        local slipRight = textRight
        local oldLeft = rightHudX
        local newLeft = math.min(oldLeft, slipLeft - bgPadding)
        local newRight = math.max(rightHudX + rightHudWidth, slipRight + bgPadding)

        hudX = newLeft
        hudBgWidth = newRight - newLeft
    end

    self.hudX = hudX
    self.hudBottom = hudBottom
    self.hudWidth = hudBgWidth
    self.hudHeight = hudBgHeight

    -- AutoDrive-style single-overlay positioning.
    -- The native GIANTS background texture is stretched to our fixed HUD box.
    if self.background ~= nil then
        self.background:setPosition(hudX, hudBottom - bgPadding)
        self.background:setDimension(hudBgWidth, hudBgHeight)
    end

    self.isCalculated = true
    return true
end

local function isMaskActive(mask, lightType)
    if mask == nil or lightType == nil then
        return false
    end

    return bit32.band(mask, 2 ^ lightType) ~= 0
end

local function getWheelSlipPercent(wheel, vehicle)
    if wheel == nil or wheel.node == nil or wheel.physics == nil then
        return 0
    end

    local wheelShape = wheel.physics.wheelShape
    local radius = wheel.physics.radius or 0
    if wheelShape == nil or radius <= 0 then
        return 0
    end

    local okSpeed, axleSpeed = pcall(getWheelShapeAxleSpeed, wheel.node, wheelShape)
    if not okSpeed or axleSpeed == nil then
        return 0
    end

    local wheelLinearSpeed = math.abs(axleSpeed * radius)

    -- lastSpeedReal is m/ms in FS25.
    local vehicleSpeed = 0
    if vehicle ~= nil and vehicle.lastSpeedReal ~= nil then
        vehicleSpeed = math.abs(vehicle.lastSpeedReal * 1000)
    end

    local hasGroundContact = wheel.physics.hasGroundContact == true

    -- Airborne wheel:
    -- At low/zero vehicle speed we still want to show a genuinely spinning
    -- free wheel. A small rotation threshold suppresses suspension/physics
    -- twitch. The display is deliberately not 1:1 with wheel speed.
    if not hasGroundContact then
        if vehicleSpeed < 1.0 then
            if wheelLinearSpeed <= 0.75 then
                return 0
            end

            local spinRatio = (wheelLinearSpeed - 0.75) / 3.25
            return math.clamp(spinRatio * 100, 0, 100)
        end

        if wheelLinearSpeed <= 0.50 then
            return 0
        end

        local airborneRatio = (wheelLinearSpeed - vehicleSpeed) / math.max(vehicleSpeed, 1.0)
        if airborneRatio <= 0.01 then
            return 0
        end

        return math.clamp(airborneRatio * 100, 0, 100)
    end

    -- Stationary vehicle with a wheel against an obstacle:
    -- lastSpeedReal is near zero, so a pure wheel-speed/vehicle-speed ratio
    -- cannot work. FS25 exposes the actual wheel longitudinal slip through
    -- getWheelShapeSlip(); use that first for grounded wheels.
    if vehicleSpeed < 0.75 then
        local okSlip, longitudinalSlip = pcall(getWheelShapeSlip, wheel.node, wheelShape)

        if okSlip and longitudinalSlip ~= nil then
            local slip = math.abs(longitudinalSlip)
            if slip > 0.01 then
                return math.clamp(slip * 100, 0, 100)
            end
        end

        -- Fallback if the engine does not report useful slip for this
        -- contact. Require meaningful wheel rotation so a small twitch does
        -- not become visible slip.
        if wheelLinearSpeed <= 0.75 then
            return 0
        end

        local spinRatio = (wheelLinearSpeed - 0.75) / 3.25
        return math.clamp(spinRatio * 100, 0, 100)
    end

    -- Normal moving, grounded wheel:
    -- Keep the previously working behavior unchanged.
    if wheelLinearSpeed <= vehicleSpeed then
        return 0
    end

    local referenceSpeed = math.max(vehicleSpeed, 1.0)
    local slipRatio = (wheelLinearSpeed - vehicleSpeed) / referenceSpeed

    if slipRatio < 0.01 then
        return 0
    end

    return math.clamp(slipRatio * 100, 0, 100)
end

-- Build an authoritative set of traction wheels from GIANTS' drivetrain.
-- Motorized differentials are recursive: a differential can point to wheels
-- or to other differentials. Crawler speed-reference wheels are added for
-- crawler vehicles because the Crawlers specialization explicitly defines
-- those wheels as the crawler's speed references.
local function getTractionWheels(vehicle)
    local traction = {}
    local specMotorized = vehicle ~= nil and vehicle.spec_motorized or nil

    if specMotorized ~= nil and specMotorized.differentials ~= nil then
        local diffs = specMotorized.differentials
        local visited = {}

        local function visitDiff(index)
            if index == nil or visited[index] then
                return
            end
            visited[index] = true

            local diff = diffs[index]
            if diff == nil then
                return
            end

            if diff.diffIndex1IsWheel then
                traction[diff.diffIndex1] = true
            else
                visitDiff(diff.diffIndex1)
            end

            if diff.diffIndex2IsWheel then
                traction[diff.diffIndex2] = true
            else
                visitDiff(diff.diffIndex2)
            end
        end

        for index, _ in pairs(diffs) do
            visitDiff(index)
        end
    end

    local crawlerSpec = vehicle ~= nil and vehicle.spec_crawlers or nil
    if crawlerSpec ~= nil and crawlerSpec.crawlers ~= nil then
        for _, crawler in ipairs(crawlerSpec.crawlers) do
            -- GIANTS defines crawler.wheels from wheelIndex/wheelIndices and
            -- wheelNodes. These are speed-reference wheels for the crawler.
            if crawler.wheels ~= nil then
                for _, entry in ipairs(crawler.wheels) do
                    if entry.wheel ~= nil and entry.wheel.wheelIndex ~= nil then
                        traction[entry.wheel.wheelIndex] = true
                    end
                end
            end
        end
    end

    return traction
end

local function getWheelIndexKey(wheel, fallbackIndex)
    if wheel ~= nil and wheel.wheelIndex ~= nil then
        return wheel.wheelIndex
    end
    return fallbackIndex
end

local function getWheelSlipValue(wheel, vehicle)
    if wheel == nil or wheel.physics == nil or wheel.physics.wheelShape == nil then
        return 0
    end

    local ok, slip = pcall(getWheelShapeSlip, wheel.node, wheel.physics.wheelShape)
    if ok and slip ~= nil then
        return math.abs(slip) * 100
    end

    return 0
end

local function collectPhysicalAxles(vehicle, tractionOnly)
    local result = {}

    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return result
    end

    local traction = getTractionWheels(vehicle)
    local entries = {}

    for index, wheel in pairs(vehicle.spec_wheels.wheels) do
        if wheel ~= nil and wheel.repr ~= nil then
            local wheelKey = getWheelIndexKey(wheel, index)
            if not tractionOnly or traction[wheelKey] then
                local ok, _, _, z = pcall(getTranslation, wheel.repr)
                if ok and z ~= nil then
                    table.insert(entries, {
                        wheel = wheel,
                        wheelIndex = wheelKey,
                        z = z
                    })
                end
            end
        end
    end

    -- A physical axle is a left/right pair at the same longitudinal position.
    -- GIANTS' WheelAxle explicitly connects two wheels of an axle. Where the
    -- runtime exposes wheelAxles we use those authoritative pairs first.
    local used = {}

    local wheelAxles = vehicle.wheelAxles
    if wheelAxles == nil and vehicle.spec_wheels ~= nil then
        wheelAxles = vehicle.spec_wheels.wheelAxles
    end

    if wheelAxles ~= nil then
        for _, axle in pairs(wheelAxles) do
            local w1 = axle.wheel1
            local w2 = axle.wheel2
            if w1 ~= nil and w2 ~= nil then
                local include = true
                if tractionOnly then
                    include = traction[getWheelIndexKey(w1, nil)] or traction[getWheelIndexKey(w2, nil)] or false
                end

                if include then
                    table.insert(result, {wheels = {w1, w2}, z = 0})
                    used[getWheelIndexKey(w1, nil)] = true
                    used[getWheelIndexKey(w2, nil)] = true
                end
            end
        end
    end

    -- Fallback/extension for wheels without an explicit WheelAxle object.
    for _, entry in ipairs(entries) do
        if not used[entry.wheelIndex] then
            local group = nil
            for _, axle in ipairs(result) do
                if math.abs(entry.z - axle.z) <= 0.05 then
                    group = axle
                    break
                end
            end

            if group == nil then
                group = {wheels = {}, z = entry.z}
                table.insert(result, group)
            end

            table.insert(group.wheels, entry.wheel)
            local sumZ = 0
            for _, w in ipairs(group.wheels) do
                local ok, _, _, wz = pcall(getTranslation, w.repr)
                if ok and wz ~= nil then
                    sumZ = sumZ + wz
                end
            end
            if #group.wheels > 0 then
                group.z = sumZ / #group.wheels
            end
        end
    end

    table.sort(result, function(a, b)
        return a.z > b.z
    end)

    return result
end

local function isSlipStartupBlocked(vehicle)
    if vehicle == nil then
        return true
    end

    local spec = vehicle.spec_motorized
    if spec == nil then
        return false
    end

    -- GIANTS exposes the active motor's configured start duration through
    -- spec.motorStartDuration. We only use it when the corresponding start
    -- timestamp is available; otherwise we leave the existing behavior intact.
    local startTime = spec.motorStartTime
    local duration = spec.motorStartDuration

    if startTime ~= nil and duration ~= nil and duration > 0 then
        local now = g_currentMission ~= nil and g_currentMission.time or 0
        if now < startTime + duration then
            return true
        end
    end

    return false
end

local function calculateAxleSlip(vehicle)
    local result = {front = 0, rear = 0}

    if vehicle == nil or vehicle.spec_wheels == nil then
        return result
    end

    -- Only wheels belonging to the drivetrain are used for displayed
    -- traction slip. Free-rolling wheels are deliberately excluded.
    local axles = collectPhysicalAxles(vehicle, true)

    if #axles == 0 then
        -- If a vehicle has no differential definition at all, retain the
        -- previous behavior rather than producing a permanently zero HUD.
        axles = collectPhysicalAxles(vehicle, false)
    end

    if #axles == 0 then
        return result
    end

    local frontAxle = axles[1]
    local rearAxle = axles[#axles]

    for _, wheel in ipairs(frontAxle.wheels) do
        result.front = math.max(result.front, getWheelSlipPercent(wheel, vehicle))
    end

    if #axles > 1 then
        for _, wheel in ipairs(rearAxle.wheels) do
            result.rear = math.max(result.rear, getWheelSlipPercent(wheel, vehicle))
        end
    else
        result.rear = result.front
    end

    return result
end

-- Recognition is kept separate from the displayed labels. This records all
-- physical wheel/crawler/axle information first; the label decision is made
-- only afterwards.

local function getCrawlerWheelSet(vehicle)
    local crawlerWheelSet = {}
    local crawlerWheelRefs = {}
    local crawlerWheelNodeRefs = {}
    local crawlerSpec = vehicle ~= nil and vehicle.spec_crawlers or nil

    if crawlerSpec == nil or crawlerSpec.crawlers == nil then
        return crawlerWheelSet, crawlerWheelRefs, crawlerWheelNodeRefs
    end

    for crawlerIndex, crawler in ipairs(crawlerSpec.crawlers) do
        -- GIANTS may expose resolved wheel objects in crawler.wheels.
        if crawler.wheels ~= nil then
            for _, wheel in pairs(crawler.wheels) do
                if wheel ~= nil then
                    crawlerWheelSet[wheel] = true

                    if wheel.wheelIndex ~= nil then
                        crawlerWheelSet[wheel.wheelIndex] = true
                    end

                    if wheel.repr ~= nil then
                        crawlerWheelRefs[wheel.repr] = true
                    end

                    if wheel.driveNode ~= nil then
                        crawlerWheelRefs[wheel.driveNode] = true
                    end

                    if wheel.linkNode ~= nil then
                        crawlerWheelRefs[wheel.linkNode] = true
                    end
                end
            end
        end

        if crawler.wheelIndices ~= nil then
            for _, wheelIndex in pairs(crawler.wheelIndices) do
                crawlerWheelSet[wheelIndex] = true
            end
        end

        -- Preserve the original crawler wheel-node references as a second
        -- source of truth. Leitwolf uses four wheelNodes per crawler.
        if crawler.wheelNodes ~= nil then
            for _, node in pairs(crawler.wheelNodes) do
                if node ~= nil then
                    crawlerWheelNodeRefs[node] = true
                end
            end
        end
    end

    return crawlerWheelSet, crawlerWheelRefs, crawlerWheelNodeRefs
end

local function wheelMatchesCrawlerReference(wheel, crawlerWheelSet, crawlerWheelRefs, crawlerWheelNodeRefs)
    if wheel == nil then
        return false
    end

    if crawlerWheelSet[wheel]
        or (wheel.wheelIndex ~= nil and crawlerWheelSet[wheel.wheelIndex]) then
        return true
    end

    if wheel.repr ~= nil and (crawlerWheelRefs[wheel.repr] or crawlerWheelNodeRefs[wheel.repr]) then
        return true
    end

    if wheel.driveNode ~= nil and (crawlerWheelRefs[wheel.driveNode] or crawlerWheelNodeRefs[wheel.driveNode]) then
        return true
    end

    if wheel.linkNode ~= nil and (crawlerWheelRefs[wheel.linkNode] or crawlerWheelNodeRefs[wheel.linkNode]) then
        return true
    end

    return false
end

local function isWheelCrawlerType(wheel)
    if wheel == nil or WheelsUtil == nil or WheelsUtil.getTireType == nil then
        return false
    end

    local crawlerTireType = WheelsUtil.getTireType("crawler")
    return crawlerTireType ~= nil and wheel.tireType == crawlerTireType
end

local function getCrawlerWheelMembers(vehicle, crawler, allWheels)
    local members = {}
    local seen = {}

    local function addWheel(wheel)
        if wheel ~= nil and not seen[wheel] then
            seen[wheel] = true
            table.insert(members, wheel)
        end
    end

    -- Primary: resolved crawler wheels with real wheel identity.
    if crawler.wheels ~= nil then
        for _, wheel in pairs(crawler.wheels) do
            if wheel ~= nil and (
                wheel.wheelIndex ~= nil
                or wheel.repr ~= nil
                or wheel.driveNode ~= nil
                or wheel.linkNode ~= nil
            ) then
                addWheel(wheel)
            end
        end
    end

    -- Primary: explicit crawler wheelNodes.
    if crawler.wheelNodes ~= nil then
        for _, node in pairs(crawler.wheelNodes) do
            if node ~= nil then
                for _, wheel in pairs(allWheels) do
                    if wheel ~= nil
                        and (wheel.repr == node
                            or wheel.driveNode == node
                            or wheel.linkNode == node) then
                        addWheel(wheel)
                    end
                end
            end
        end
    end

    -- Fallback only when explicit membership is unresolved:
    -- use physical side + crawler tire type to associate internal wheels
    -- with this crawler. This does not affect normal resolved crawlers.
    if #members == 0 then
        local candidates = {}

        for _, wheel in pairs(allWheels) do
            if wheel ~= nil and wheel.repr ~= nil
                and isWheelCrawlerType(wheel) then
                local ok, x, _, z = pcall(getTranslation, wheel.repr)
                if ok and x ~= nil and z ~= nil then
                    table.insert(candidates, {wheel=wheel, x=x, z=z})
                end
            end
        end

        local sideSign = crawler.isLeft and -1 or 1
        local sideCandidates = {}

        for _, candidate in ipairs(candidates) do
            if candidate.x * sideSign > 0.02 then
                table.insert(sideCandidates, candidate)
            end
        end

        for _, candidate in ipairs(sideCandidates) do
            addWheel(candidate.wheel)
        end

        -- If the model's local X convention is mirrored, retry opposite side
        -- only when the first side yielded nothing.
        if #members == 0 then
            for _, candidate in ipairs(candidates) do
                if candidate.x * (-sideSign) > 0.02 then
                    addWheel(candidate.wheel)
                end
            end
        end
    end

    return members
end

local function collectAllChassisUnits(vehicle)
    local manifest = {
        units = {},
        crawlerUnits = {},
        wheelUnits = {},
        totalUnits = 0,
        crawlerCount = 0,
        wheelUnitCount = 0,
        normalWheelCount = 0
    }

    if vehicle == nil
        or vehicle.spec_wheels == nil
        or vehicle.spec_wheels.wheels == nil then
        return manifest
    end

    local allWheels = vehicle.spec_wheels.wheels
    local crawlerSpec = vehicle.spec_crawlers
    local crawlerWheelSet, crawlerWheelRefs, crawlerWheelNodeRefs =
        getCrawlerWheelSet(vehicle)

    local assignedCrawlerWheels = {}

    -- ================================================================
    -- PHASE 1A: DECLARE ALL CRAWLER UNITS AND RESOLVE ALL OF THEIR
    -- INTERNAL WHEELS BEFORE LOOKING FOR NORMAL WHEEL UNITS.
    -- ================================================================
    if crawlerSpec ~= nil and crawlerSpec.crawlers ~= nil then
        for crawlerIndex, crawler in ipairs(crawlerSpec.crawlers) do
            local members = getCrawlerWheelMembers(vehicle, crawler, allWheels)

            print(string.format(
                "[Lights Symbol HUD][CHASSIS DEBUG] crawler=%d resolvedMembers=%d side=%s",
                crawlerIndex,
                #members,
                crawler.isLeft and "LEFT" or "RIGHT"
            ))

            local unit = {
                id = "CRAWLER_" .. tostring(crawlerIndex),
                kind = "CRAWLER",
                index = crawlerIndex,
                side = crawler.isLeft and "LEFT" or "RIGHT",
                wheels = members,
                wheelCount = #members
            }

            for _, wheel in ipairs(members) do
                assignedCrawlerWheels[wheel] = true

                if wheel.wheelIndex ~= nil then
                    assignedCrawlerWheels[wheel.wheelIndex] = true
                end
            end

            table.insert(manifest.crawlerUnits, unit)
            table.insert(manifest.units, unit)
        end
    end

    -- ================================================================
    -- PHASE 1B: ONLY AFTER EVERY CRAWLER UNIT IS COMPLETE, scan all
    -- remaining spec_wheels.wheels for genuine normal wheel units.
    -- ================================================================
    local normalEntries = {}

    for index, wheel in pairs(allWheels) do
        local isCrawlerWheel = assignedCrawlerWheels[wheel]
            or assignedCrawlerWheels[index]

        if not isCrawlerWheel and wheel ~= nil and wheel.wheelIndex ~= nil then
            isCrawlerWheel = assignedCrawlerWheels[wheel.wheelIndex]
        end

        -- Existing crawler tireType remains a fallback, but only for a
        -- wheel not already assigned to a crawler by explicit membership.
        if not isCrawlerWheel and isWheelCrawlerType(wheel) then
            isCrawlerWheel = true
        end

        if not isCrawlerWheel and wheel ~= nil and wheel.repr ~= nil then
            local ok, _, _, z = pcall(getTranslation, wheel.repr)

            if ok and z ~= nil then
                table.insert(normalEntries, {
                    wheel = wheel,
                    index = index,
                    z = z
                })
            end
        end
    end

    -- Group genuine normal wheels by physical longitudinal position.
    table.sort(normalEntries, function(a, b)
        return a.z > b.z
    end)

    for _, entry in ipairs(normalEntries) do
        local unit = nil

        for _, candidate in ipairs(manifest.wheelUnits) do
            if math.abs(entry.z - candidate.z) <= 0.05 then
                unit = candidate
                break
            end
        end

        if unit == nil then
            unit = {
                id = "WHEEL_" .. tostring(#manifest.wheelUnits + 1),
                kind = "WHEEL",
                wheels = {},
                wheelCount = 0,
                z = entry.z
            }

            table.insert(manifest.wheelUnits, unit)
            table.insert(manifest.units, unit)
        end

        table.insert(unit.wheels, entry.wheel)
        unit.wheelCount = #unit.wheels

        local sum, count = 0, 0
        for _, wheel in ipairs(unit.wheels) do
            local ok, _, _, z = pcall(getTranslation, wheel.repr)

            if ok and z ~= nil then
                sum = sum + z
                count = count + 1
            end
        end

        if count > 0 then
            unit.z = sum / count
        end
    end

    -- ================================================================
    -- PHASE 1C: COMPLETE MANIFEST COUNTS. Nothing above this point
    -- makes an L/R or V/H decision.
    -- ================================================================
    manifest.totalUnits = #manifest.units
    manifest.crawlerCount = #manifest.crawlerUnits
    manifest.wheelUnitCount = #manifest.wheelUnits

    for _, unit in ipairs(manifest.wheelUnits) do
        manifest.normalWheelCount =
            manifest.normalWheelCount + unit.wheelCount
    end

    return manifest
end

-- PHASE 2:
-- Evaluate the completed manifest. Still no HUD decision.
local function isLeitwolfVehicle(vehicle)
    if vehicle == nil then
        return false
    end

    local names = {}

    local function addName(value)
        if value ~= nil then
            local text = tostring(value)
            if text ~= "" then
                table.insert(names, text)
            end
        end
    end

    -- Check the vehicle's available display/configuration names.
    addName(vehicle.getFullName ~= nil and vehicle:getFullName() or nil)
    addName(vehicle.getName ~= nil and vehicle:getName() or nil)
    addName(vehicle.name)
    addName(vehicle.configFileName)
    addName(vehicle.xmlFileName)

    for _, value in ipairs(names) do
        local normalized = string.lower(value)
        if string.find(normalized, "prinoth leitwolf", 1, true) ~= nil
            or string.find(normalized, "leitwolf agripower", 1, true) ~= nil then
            return true
        end
    end

    return false
end

local function evaluateChassisManifest(manifest)
    local evaluation = {
        totalUnits = manifest.totalUnits,
        crawlerCount = manifest.crawlerCount,
        wheelUnitCount = manifest.wheelUnitCount,
        normalWheelCount = manifest.normalWheelCount,
        crawlerLeft = 0,
        crawlerRight = 0,
        isPureTwoSidedCrawler = false,
        isMixedCrawlerWheel = false,
        isMultiCrawler = false
    }

    for _, unit in ipairs(manifest.crawlerUnits) do
        if unit.side == "LEFT" then
            evaluation.crawlerLeft = evaluation.crawlerLeft + 1
        else
            evaluation.crawlerRight = evaluation.crawlerRight + 1
        end
    end

    evaluation.isPureTwoSidedCrawler =
        evaluation.totalUnits == 2
        and evaluation.crawlerCount == 2
        and evaluation.crawlerLeft == 1
        and evaluation.crawlerRight == 1
        and evaluation.wheelUnitCount == 0

    evaluation.isMixedCrawlerWheel =
        evaluation.crawlerCount > 0
        and evaluation.wheelUnitCount > 0

    evaluation.isMultiCrawler =
        evaluation.crawlerCount > 2

    return evaluation
end

local function analyzeChassis(vehicle)
    local info = {
        type = "WHEEL",
        layoutType = "WHEEL_ONLY",

        wheelCount = 0,
        tractionWheelCount = 0,

        -- Raw/future multi-axle fields. They are not used for the
        -- basic L/R vs V/H decision.
        axleCount = 0,
        conventionalAxleCount = 0,

        crawlerCount = 0,
        crawlerLeft = 0,
        crawlerRight = 0,

        chassisUnitCount = 0,
        crawlerUnitCount = 0,
        wheelUnitCount = 0,
        normalWheelCount = 0,

        chassisUnits = {},
        chassisEvaluation = nil,

        displayMode = "FRONT_REAR",
        frontLabel = "V",
        rearLabel = "H"
    }

    if vehicle == nil
        or vehicle.spec_wheels == nil
        or vehicle.spec_wheels.wheels == nil then
        return info
    end

    -- ================================================================
    -- PHASE 1: COMPLETE MANIFEST
    -- EVERYTHING belonging to the vehicle's running gear is collected
    -- and declared before ANY classification/decision is made.
    -- ================================================================
    local manifest = collectAllChassisUnits(vehicle)

    info.chassisUnits = manifest.units
    info.chassisUnitCount = manifest.totalUnits
    info.crawlerUnitCount = manifest.crawlerCount
    info.wheelUnitCount = manifest.wheelUnitCount
    info.normalWheelCount = manifest.normalWheelCount

    -- ================================================================
    -- PHASE 2: EVALUATE THE COMPLETED MANIFEST
    -- Count/classify only after the complete vehicle has been scanned.
    -- ================================================================
    local evaluation = evaluateChassisManifest(manifest)
    info.chassisEvaluation = evaluation

    -- Explicit vehicle-name fallback for the two known Prinoth Leitwolf
    -- variants. This overrides ONLY the final L/R vs V/H display decision.
    -- The underlying chassis manifest remains fully intact for future use.
    info.forceLeftRight = isLeitwolfVehicle(vehicle)

    if info.forceLeftRight then
        print(string.format(
            "[Lights Symbol HUD][CHASSIS DEBUG] LEITWOLF NAME OVERRIDE active for %s",
            tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.name or "unknown")
        ))
    end

    -- Temporary diagnostic: dump the COMPLETE chassis manifest after
    -- collection and evaluation. This does not alter any decision.
    if evaluation.crawlerCount > 0 then
        print(string.format(
            "[Lights Symbol HUD][CHASSIS DEBUG] vehicle=%s units=%d crawlerUnits=%d wheelUnits=%d normalWheels=%d",
            tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.name or "unknown"),
            evaluation.totalUnits,
            evaluation.crawlerCount,
            evaluation.wheelUnitCount,
            evaluation.normalWheelCount
        ))

        for unitIndex, unit in ipairs(manifest.units) do
            print(string.format(
                "[Lights Symbol HUD][CHASSIS DEBUG] unit=%d id=%s kind=%s side=%s wheels=%d z=%s",
                unitIndex,
                tostring(unit.id),
                tostring(unit.kind),
                tostring(unit.side or "-"),
                tonumber(unit.wheelCount or 0),
                tostring(unit.z or "-")
            ))
        end

        for crawlerIndex, crawler in ipairs(manifest.crawlerUnits) do
            print(string.format(
                "[Lights Symbol HUD][CHASSIS DEBUG] crawler=%d side=%s manifestWheels=%d",
                crawlerIndex,
                tostring(crawler.side),
                tonumber(crawler.wheelCount or 0)
            ))

            for memberIndex, wheel in ipairs(crawler.wheels) do
                print(string.format(
                    "[Lights Symbol HUD][CHASSIS DEBUG] crawler=%d member=%d wheelIndex=%s repr=%s driveNode=%s linkNode=%s tireType=%s",
                    crawlerIndex,
                    memberIndex,
                    tostring(wheel.wheelIndex or "-"),
                    tostring(wheel.repr or "-"),
                    tostring(wheel.driveNode or "-"),
                    tostring(wheel.linkNode or "-"),
                    tostring(wheel.tireType or "-")
                ))
            end
        end
    end

    info.crawlerCount = evaluation.crawlerCount
    info.crawlerLeft = evaluation.crawlerLeft
    info.crawlerRight = evaluation.crawlerRight

    -- Keep raw/future axle values separate from the display decision.
    info.conventionalAxleCount = evaluation.wheelUnitCount
    info.axleCount = evaluation.wheelUnitCount

    for _, wheel in pairs(vehicle.spec_wheels.wheels) do
        info.wheelCount = info.wheelCount + 1
    end

    local traction = getTractionWheels(vehicle)
    for index, wheel in pairs(vehicle.spec_wheels.wheels) do
        local key = getWheelIndexKey(wheel, index)

        if traction[key] then
            info.tractionWheelCount = info.tractionWheelCount + 1
        end
    end

    -- ================================================================
    -- PHASE 3: FINAL DECISION
    -- Only the COMPLETED manifest/evaluation is allowed here.
    -- ================================================================
    if info.forceLeftRight then
        info.displayMode = "LEFT_RIGHT"
        info.frontLabel = "L"
        info.rearLabel = "R"
    elseif evaluation.isPureTwoSidedCrawler then
        info.type = "CRAWLER"
        info.layoutType = "CRAWLER_ONLY"
        info.displayMode = "LEFT_RIGHT"
        info.frontLabel = "L"
        info.rearLabel = "R"

    elseif evaluation.isMixedCrawlerWheel then
        info.type = "CRAWLER"
        info.layoutType = "MIXED_CRAWLER_WHEEL"
        info.displayMode = "FRONT_REAR"
        info.frontLabel = "V"
        info.rearLabel = "H"

    elseif evaluation.isMultiCrawler then
        info.type = "CRAWLER"
        info.layoutType = "MULTI_CRAWLER"
        info.displayMode = "FRONT_REAR"
        info.frontLabel = "V"
        info.rearLabel = "H"

    else
        info.type = "WHEEL"
        info.layoutType = "WHEEL_ONLY"
        info.displayMode = "FRONT_REAR"
        info.frontLabel = "V"
        info.rearLabel = "H"
    end

    return info
end

local function updateSlipDisplayLabels(self, vehicle)
    self.slipChassisInfo = analyzeChassis(vehicle)
    self.slipDisplayLabels = {
        front = self.slipChassisInfo.frontLabel,
        rear = self.slipChassisInfo.rearLabel
    }
end

function LightsSymbolHUD:updateStates()
    local vehicle = self.vehicle

    if vehicle == nil or vehicle.spec_lights == nil then
        for _, element in pairs(self.icons) do
            element:setVisible(false)
        end
        for _, element in pairs(self.inactiveIcons) do
            element:setVisible(false)
        end
        return
    end

    local spec = vehicle.spec_lights
    local mask = spec.lightsTypesMask or 0

    local highActive = isMaskActive(mask, Lights.LIGHT_TYPE_HIGHBEAM)
    local lowActive = isMaskActive(mask, Lights.LIGHT_TYPE_DEFAULT)
        and not highActive

    self.active = self.active or {}
    self.active.low = lowActive
    self.active.high = highActive
    -- Work-light state is read directly from the engine light-type bit mask.
    -- This is the authoritative FS25 state for front/rear work lights.
    self.active.workFront =
        bit32.band(mask, 2 ^ Lights.LIGHT_TYPE_WORK_FRONT) ~= 0
    self.active.workBack =
        bit32.band(mask, 2 ^ Lights.LIGHT_TYPE_WORK_BACK) ~= 0
    self.active.beacon = spec.beaconLightsActive == true

    -- Vanilla FS25 turnLightState, as used by the supplied Turn Signal HUD:
    -- 0 = off, 1 = left, 2 = right, 3 = hazard.
    self.blinkerState = spec.turnLightState or 0
    updateSlipDisplayLabels(self, vehicle)

    local slip = calculateAxleSlip(vehicle)

        if isSlipStartupBlocked(vehicle) then
            slip.front = 0
            slip.rear = 0
        end
    self.slipFrontTarget = slip.front
    self.slipRearTarget = slip.rear

    -- First limit sudden target jumps. This is especially important for
    -- tracked vehicles when the contact material changes (asphalt/grass/snow).
    -- A surface transition can change the raw physics value by many percent
    -- in one frame even though the visible wheel slip changes much less.
    local function limitTarget(current, target, maxStep)
        local delta = target - current
        if delta > maxStep then
            return current + maxStep
        elseif delta < -maxStep then
            return current - maxStep
        end
        return target
    end

    self.slipFilteredTargetFront =
        limitTarget(self.slipFilteredTargetFront or 0, self.slipFrontTarget, LightsSymbolHUD.SLIP_TARGET_MAX_STEP)
    self.slipFilteredTargetRear =
        limitTarget(self.slipFilteredTargetRear or 0, self.slipRearTarget, LightsSymbolHUD.SLIP_TARGET_MAX_STEP)

    -- Smooth the displayed value instead of following every physics tick.
    -- Rising values react faster; falling values decay more gently.
    local now = g_currentMission ~= nil and g_currentMission.time or 0
    local dtMs = now - (self.slipLastSmoothTime or now)
    if dtMs < 0 or dtMs > 250 then
        dtMs = 50
    end

    if dtMs >= LightsSymbolHUD.SLIP_DISPLAY_STEP_MS then
        local factorBase = math.min(dtMs / 50, 4)

        local up = 1 - (1 - LightsSymbolHUD.SLIP_SMOOTH_UP) ^ factorBase
        local down = 1 - (1 - LightsSymbolHUD.SLIP_SMOOTH_DOWN) ^ factorBase

        local function smooth(current, target)
            if target > current then
                return current + (target - current) * up
            else
                return current + (target - current) * down
            end
        end

        self.slipFrontPercent = smooth(self.slipFrontPercent, self.slipFilteredTargetFront)
        self.slipRearPercent = smooth(self.slipRearPercent, self.slipFilteredTargetRear)

        -- When real slip has ended, keep the last visible values for one
        -- second before allowing the smooth fade to reach zero.
        local targetsZero =
            self.slipFilteredTargetFront < LightsSymbolHUD.SLIP_THRESHOLD_PERCENT
            and self.slipFilteredTargetRear < LightsSymbolHUD.SLIP_THRESHOLD_PERCENT

        if targetsZero then
            if self.slipZeroSince == nil then
                self.slipZeroSince = now
            elseif now - self.slipZeroSince >= LightsSymbolHUD.SLIP_ZERO_HOLD_MS then
                self.slipFrontPercent = smooth(self.slipFrontPercent, 0)
                self.slipRearPercent = smooth(self.slipRearPercent, 0)
            end
        else
            self.slipZeroSince = nil
        end

        self.slipLastSmoothTime = now
    end

    -- All five light symbols remain visible.
    -- Active = original colored artwork.
    -- Inactive = dedicated neutral-grey artwork at 50% alpha.
    for name, element in pairs(self.icons) do
        local inactiveElement = self.inactiveIcons[name]

        if self.active[name] == true then
            element:setVisible(true)
            if inactiveElement ~= nil then
                inactiveElement:setVisible(false)
            end

            if name == "low" then
                element.overlay:setColor(0.2, 1.0, 0.2, 1.0)
            else
                element.overlay:setColor(1.0, 1.0, 1.0, 1.0)
            end
        else
            element:setVisible(false)
            if inactiveElement ~= nil then
                -- The inactive DDS is already neutral gray. Keep the overlay
                -- neutral as well so no source-icon hue can bleed through.
                inactiveElement.overlay:setColor(1.0, 1.0, 1.0, 1.0)
                inactiveElement:setVisible(true)
            end
        end
    end

    -- Blinker overlays are deliberately kept outside self.icons.
    for _, element in pairs(self.blinkerIcons) do
        element:setVisible(false)
    end

    if self.blinkerState == 1 then
        self.blinkerIcons.left:setVisible(true)
    elseif self.blinkerState == 2 then
        self.blinkerIcons.right:setVisible(true)
    elseif self.blinkerState == 3 then
        -- Hazard warning uses both directional arrows instead of the
        -- dedicated hazard symbol.
        self.blinkerIcons.left:setVisible(true)
        self.blinkerIcons.right:setVisible(true)
        self.blinkerIcons.hazard:setVisible(false)
    end
end

function LightsSymbolHUD:drawHUD()
    if self.vehicle == nil
        or self.speedMeter == nil
        or not self.speedMeter.isVehicleDrawSafe
        or g_dedicatedServerInfo ~= nil then
        return
    end

    if self.vehicle.spec_lights == nil then
        return
    end

    if not self.isCalculated then
        if not self:calculatePosition() then
            return
        end
    end

    self:updateStates()

    -- The HUD background is permanently visible.
    -- The previous active-only condition is intentionally retained nowhere:
    -- this is the permanent-HUD mode requested for the next version.
    if self.background ~= nil then
        self.background:render()
    end

    -- First fixed slot: blinker symbol only.
    -- The blinking phase is calculated locally for this HUD. It does not
    -- change turnLightState, vehicle lights, or any other HUD.
    if self.blinkerState ~= nil and self.blinkerState ~= 0 then
        -- FS25 time is in milliseconds. Keep the phase local to this HUD.
        -- 500 ms ON / 500 ms OFF gives a normal indicator rhythm.
        local gameTime = g_currentMission ~= nil and g_currentMission.time or nil
        local blinkOn = true

        if gameTime ~= nil then
            blinkOn = (gameTime % 1000) < 500
        end

        if blinkOn then
            local function renderBlinker(element, pos)
                if element ~= nil and pos ~= nil then
                    element:setPosition(pos[1], pos[2])
                    element.overlay:render()
                end
            end

            local rightPos = self.positions.blinkers
            local leftPos = nil

            if self.blinkerPositions ~= nil then
                leftPos = self.blinkerPositions.left
            end

            if self.blinkerState == 1 then
                -- LEFT remains in the slip-symbol column, row 1.
                renderBlinker(self.blinkerIcons.left, leftPos)
            elseif self.blinkerState == 2 then
                -- RIGHT remains in the original light-symbol blinker slot.
                renderBlinker(self.blinkerIcons.right, rightPos)
            elseif self.blinkerState == 3 then
                -- HAZARD: show both directional arrows simultaneously.
                renderBlinker(self.blinkerIcons.left, leftPos)
                renderBlinker(self.blinkerIcons.right, rightPos)
            end
        end
    end

    -- Remaining five fixed slots: always render their current state.
    -- Inactive symbols have already been greyed/translucent in updateStates().
    for index = 2, #LightsSymbolHUD.SLOT_ORDER do
        local name = LightsSymbolHUD.SLOT_ORDER[index]
        local element = self.icons[name]

        local inactiveElement = self.inactiveIcons[name]
        local elementToRender = element

        if self.active ~= nil and self.active[name] ~= true and inactiveElement ~= nil then
            elementToRender = inactiveElement
        end

        if elementToRender ~= nil then
            local pos = self.positions[name]
            elementToRender:setPosition(pos[1], pos[2])
            elementToRender.overlay:render()
        end
    end

    local function drawSlipRow(name, percent)
        local element = self.slipIcons[name]
        if element == nil then return end

        local isActive = percent >= LightsSymbolHUD.SLIP_THRESHOLD_PERCENT
        if LightsSymbolHUD.SLIP_POSITION_DEBUG then
            element:setVisible(true)
        else
            element:setVisible(isActive)
            if not isActive then
                return
            end
        end

        -- GIANTS drive-release timing. Wheel/axle rotation is still sampled
        -- for diagnostics, but it does not determine READY while stationary.
        -- No ground-contact condition is used.
        local motorStarted = false
        if self.vehicle.getIsMotorStarted ~= nil then
            motorStarted = self.vehicle:getIsMotorStarted()
        elseif self.vehicle.spec_motorized ~= nil then
            motorStarted = self.vehicle.spec_motorized.isMotorStarted == true
        end

        local motorStartTime = 0
        if self.vehicle.getMotorStartTime ~= nil then
            motorStartTime = self.vehicle:getMotorStartTime()
        elseif self.vehicle.spec_motorized ~= nil then
            motorStartTime = self.vehicle.spec_motorized.motorStartTime or 0
        end

        local motorDriveReady = motorStarted
            and motorStartTime <= g_currentMission.time

        -- After motorStartDuration has ended, only rotation of a drivetrain
        -- wheel may release the slip display. Free-rolling wheels are ignored.
        local wheelRotationDetected = false
        local drivetrainAxles = collectPhysicalAxles(self.vehicle, true)

        for _, axle in ipairs(drivetrainAxles) do
            for _, wheel in ipairs(axle.wheels) do
                local axleSpeed = 0
                if wheel.node ~= nil and wheel.physics ~= nil and wheel.physics.wheelShape ~= nil then
                    local ok, value = pcall(
                        getWheelShapeAxleSpeed,
                        wheel.node,
                        wheel.physics.wheelShape
                    )
                    if ok and value ~= nil then
                        axleSpeed = math.abs(value)
                    end
                end

                if axleSpeed > LightsSymbolHUD.STARTUP_AXLE_SPEED_THRESHOLD then
                    wheelRotationDetected = true
                    break
                end
            end

            if wheelRotationDetected then
                break
            end
        end

        -- READY means the engine/drive system is started and the GIANTS
        -- drive-release time has passed. Vehicle movement is NOT required:
        -- at a standstill a ready vehicle must stay green.
        -- Use the exact same motorStartDuration-aware startup gate as the
        -- slip suppression in updateStates(). This prevents a first-frame
        -- physics peak from becoming visible before the vehicle is truly
        -- drive-ready.
        local startupBlocked = isSlipStartupBlocked(self.vehicle)
        local driveReady = motorDriveReady and not startupBlocked

        local r, g, b
        local displayPercent = percent

        if not driveReady then
            -- Before GIANTS' drive-release point: exact same white/50% RGBA as inactive light symbols and 0%.
            r, g, b = 1.0, 1.0, 1.0
            displayPercent = 0
        elseif not wheelRotationDetected then
            -- Vehicle is ready, but no drivetrain wheel is rotating yet.
            -- Keep the ready state green while suppressing startup physics peaks.
            r, g, b = 0.18, 0.55, 0.18
            displayPercent = 0
        elseif percent <= 40 then
            -- Drive-ready + 0-40%: slightly dark green.
            r, g, b = 0.18, 0.55, 0.18
        else
            -- Drive-ready + 41-100%: bright light red.
            r, g, b = 1.0, 0.25, 0.25
        end

        -- wheel_slip.dds is a neutral white mask, so this tint is now the
        -- actual displayed color rather than a multiplication with red artwork.
        if not driveReady then
            element.overlay:setColor(r, g, b, 0.50)
        else
            element.overlay:setColor(r, g, b, 1.0)
        end

        local pos = self.slipPositions[name]
        if pos == nil then
            element:setVisible(false)
            return
        end

        element:setPosition(pos[1], pos[2])
        element.overlay:render()

        local textSize = self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.SLIP_TEXT_SIZE)
        local percentText = string.format("%d%%", math.floor(displayPercent + 0.5))
        local label = self.slipDisplayLabels ~= nil
            and self.slipDisplayLabels[name]
            or (name == "front" and "V" or "H")
        local labelText = label .. " " .. percentText

        -- V/H + percentage is rendered below the wheel icon. The right edge
        -- remains fixed at the light-column X coordinate for 0..100%.
        setTextAlignment(RenderText.ALIGN_RIGHT)
        setTextBold(true)
        setTextColor(1, 1, 1, 1)

        local textRightX = self.positions.blinkers[1]
        local textY = pos[2] - self.speedMeter:scalePixelToScreenHeight(8)
        renderText(
            textRightX,
            textY,
            textSize,
            labelText
        )

        setTextBold(false)
        setTextAlignment(RenderText.ALIGN_LEFT)
    end

    drawSlipRow("front", self.slipFrontPercent)
    drawSlipRow("rear", self.slipRearPercent)
end

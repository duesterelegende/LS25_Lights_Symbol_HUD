-- Lights Symbol HUD loader
-- HUD-only: does not modify vehicle light ranges or vehicle light functions.
-- The vanilla HUD methods are extended, never replaced.

local directory = g_currentModDirectory
local lightsSymbolHUDInstance = nil

source(Utils.getFilename("LightsSymbolHUD.lua", directory))

local function LSH_loadedMission(mission)
    if mission == nil or mission.cancelLoading then
        return
    end

    if mission.hud == nil or mission.hud.speedMeter == nil then
        return
    end

    if lightsSymbolHUDInstance == nil then
        lightsSymbolHUDInstance = LightsSymbolHUD:new(
            mission.hud.speedMeter,
            directory
        )
        lightsSymbolHUDInstance:load()

        mission.hud.drawControlledEntityHUD =
            Utils.appendedFunction(
                mission.hud.drawControlledEntityHUD,
                function(hud)
                    if lightsSymbolHUDInstance ~= nil and hud.isVisible then
                        lightsSymbolHUDInstance:drawHUD()
                    end
                end
            )

        mission.hud.setControlledVehicle =
            Utils.appendedFunction(
                mission.hud.setControlledVehicle,
                function(_, vehicle)
                    if lightsSymbolHUDInstance ~= nil then
                        lightsSymbolHUDInstance:setVehicle(vehicle)
                    end
                end
            )
    end
end

local function LSH_unload()
    if lightsSymbolHUDInstance ~= nil then
        lightsSymbolHUDInstance:delete()
        lightsSymbolHUDInstance = nil
    end
end

Mission00.loadMission00Finished =
    Utils.appendedFunction(Mission00.loadMission00Finished, LSH_loadedMission)

FSBaseMission.delete =
    Utils.appendedFunction(FSBaseMission.delete, LSH_unload)

LightsSymbolHUD = {}
LightsSymbolHUD.VERSION = "RELEASE_1_2_2_4"
LightsSymbolHUD.DEBUG_ENABLED = false
local LightsSymbolHUD_mt = Class(LightsSymbolHUD, HUDDisplayElement)

-- All HUD dimensions are expressed in the same pixel-to-screen scaling
-- system used by the vanilla speedometer. The five slots themselves are
-- fixed; only the whole HUD scales with the speedometer/display resolution.
LightsSymbolHUD.ICON_SIZE = {42, 42}
-- Work-light icons use the same 42 px icon box as the standard light symbols.
-- The artwork itself has transparent margins, so its visible size remains
-- optically consistent with the existing high/low-beam symbols.
-- Work-light icons reduced by 20% from the matched 42 px size.
-- Both use identical dimensions; the existing slot-centering/alignment remains unchanged.
LightsSymbolHUD.WORK_FRONT_ICON_SIZE = {33.6, 33.6}
LightsSymbolHUD.WORK_BACK_ICON_SIZE = {33.6, 33.6}
LightsSymbolHUD.SLOT_HEIGHT = 48
LightsSymbolHUD.ICON_GAP = -2
LightsSymbolHUD.LEFT_GAP = 12
-- Minimal view: keep the light-symbol column aligned with the established
-- full-view HUD position and clear of the tachometer/other HUDs.
-- This offset applies only to the light-symbol HUD column; the minimal
-- sphere/slip bar keeps its independent column-2/3 anchor unchanged.
LightsSymbolHUD.MINIMAL_LIGHT_HUD_X_OFFSET = -12
LightsSymbolHUD.BLINKER_ICON_SIZE = {32, 32}
-- Tire-condition icon is optically smaller to match the existing light symbols.
LightsSymbolHUD.TIRE_CONDITION_ICON_SIZE = {24, 24}
-- B1.1.0.133: crawler/steel symbols intentionally use the full HUD slot.
LightsSymbolHUD.RUNNING_GEAR_ICON_SIZE = {48, 48}
LightsSymbolHUD.WFS_ICON_SIZE = {24, 24}
LightsSymbolHUD.SLIP_ICON_SIZE = {32.34, 32.34}
LightsSymbolHUD.SLIP_TEXT_SIZE = 11.56
LightsSymbolHUD.WHEEL_DISPLAY_MAX = 12
LightsSymbolHUD.WHEEL_COLUMN_GAP = 10
LightsSymbolHUD.SLIP_THRESHOLD_PERCENT = 1.0
LightsSymbolHUD.SLIP_COLOR_LOCK_MS = 200
-- Percentage display smoothing: fixed 50 ms steps, no zero-hold.
-- Target changes are limited to 15 percentage points per smoothing step,
-- then the displayed value follows with separate rise/fall coefficients.
-- Percentage smoothing tuned for human-readable HUD perception.
-- Below 40%: calm progression. At/above 40%: faster response so the
-- critical red range becomes visible without a long artificial delay.
LightsSymbolHUD.SLIP_SMOOTH_UP = 0.045
LightsSymbolHUD.SLIP_SMOOTH_DOWN = 0.050
LightsSymbolHUD.SLIP_SMOOTH_UP_HIGH = 0.080
LightsSymbolHUD.SLIP_SMOOTH_DOWN_HIGH = 0.065
LightsSymbolHUD.SLIP_SMOOTH_STEP = 0.01
LightsSymbolHUD.SLIP_TARGET_MAX_STEP = 12.0
LightsSymbolHUD.SLIP_RED_THRESHOLD_PERCENT = 40.0
-- Prevent green/red flicker around the 40% threshold.
LightsSymbolHUD.SLIP_COLOR_HOLD_MS = 200

LightsSymbolHUD.ICONS = {
    low = "resources/low.dds",
    high = "resources/high.dds",
    workFront = "resources/work_front.dds",
    workBack = "resources/work_back.dds",
    beacon = "resources/beacon.dds"
}

-- Fixed light slots:
-- 4 = beacon, 5 = front work light, 6 = rear work light.
LightsSymbolHUD.SLOT_ORDER = {
    "blinkers",
    "low",
    "high",
    "beacon",
    "workFront",
    "workBack"
}

-- Optical X corrections for the actual artwork inside each 128px DDS.
-- The files have different transparent margins, so geometric slot-centering
-- alone does not visually center the symbols. Values are derived from the
-- actual alpha bounding boxes of the supplied DDS files.
LightsSymbolHUD.ICON_OPTICAL_X_OFFSET = {
    -- Optical alignment V3: align the VISIBLE RIGHT EDGE of every light
    -- symbol to the low-beam reference line. This is more suitable for a
    -- narrow HUD column than center alignment because the symbols have
    -- different widths and transparent margins.
    -- Slots 2/3/4: 4 px further left for improved optical alignment.
    low = -4.00,
    high = -4.00,
    workFront = 1.36,
    -- Rear work-light artwork: 4 px left from the previous optical position.
    workBack = 3.96,
    beacon = 5.84
}

-- Wheel-slip slots are explicitly 5 and 6:
-- front wheel slip = slot 5, rear wheel slip = slot 6.
-- These are independent display rows and do not alter the light slots.
LightsSymbolHUD.SLIP_SLOT_ORDER = {
    front = 5,
    rear = 6
}

-- Preserve the currently confirmed position while making it an explicit
-- slot definition for the new layout system.
LightsSymbolHUD.SLIP_SLOT_Y_OFFSET = -22

-- Runtime throttling/caching: structural wheel/chassis data is confirmed
-- four consecutive times per vehicle and then reused until the vehicle changes.
-- Dynamic wheel physics is sampled every HUD draw; no artificial response delay is introduced.
LightsSymbolHUD.STRUCTURE_CONFIRMATIONS = 4

-- Startup release: actual wheel/axle rotation is the physical indication
-- that wheel physics has become active. Ground contact is NOT used.
LightsSymbolHUD.STARTUP_AXLE_SPEED_THRESHOLD = 0.05

-- B1_1_0_153: torque arc kept unchanged; only endpoint label positions adjusted.
-- The torque arc keeps its dedicated 0..15 scale (x1000 Nm), but the numeric
-- live readout is removed. Instead, only a small "Nm" label is rendered at the
-- arc start and a small "x1000" label at the arc end.
LightsSymbolHUD.TORQUE_GAUGE_MAX_NM = 5000
LightsSymbolHUD.TORQUE_GAUGE_ARC_RADIUS_PX = 98
LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG = 210
LightsSymbolHUD.TORQUE_GAUGE_ARC_END_DEG = -30
LightsSymbolHUD.TORQUE_GAUGE_SEGMENTS = 144
LightsSymbolHUD.TORQUE_GAUGE_BASE_WIDTH_PX = 11
LightsSymbolHUD.TORQUE_GAUGE_ACTIVE_WIDTH_PX = 6
LightsSymbolHUD.TORQUE_GAUGE_TEXT_GAP_PX = 4
LightsSymbolHUD.TORQUE_GAUGE_READOUT_Y_OFFSET_PX = -10
LightsSymbolHUD.TORQUE_GAUGE_SMOOTH_TIME_MS = 260
LightsSymbolHUD.TORQUE_GAUGE_SCALE_LABELS = {0, 1, 2, 3, 4, 5}
LightsSymbolHUD.TORQUE_GAUGE_SCALE_TEXT_SIZE_FACTOR = 1.24
LightsSymbolHUD.TORQUE_GAUGE_SCALE_LABEL_RADIUS_PX = 113
LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_INNER_RADIUS_PX = 99
LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_OUTER_RADIUS_PX = 103
LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_WIDTH_PX = 2
LightsSymbolHUD.TORQUE_GAUGE_SCALE_ALPHA = 0.90
LightsSymbolHUD.TORQUE_GAUGE_SCALE_COLOR_FACTOR = 0.78
LightsSymbolHUD.TORQUE_GAUGE_ENDPOINT_TEXT_SIZE_FACTOR = 1.05
LightsSymbolHUD.TORQUE_GAUGE_ENDPOINT_LABEL_RADIUS_PX = 109
LightsSymbolHUD.TORQUE_GAUGE_START_LABEL_TEXT = "Nm"
LightsSymbolHUD.TORQUE_GAUGE_END_LABEL_TEXT = ""
LightsSymbolHUD.TORQUE_GAUGE_START_LABEL_X_OFFSET_PX = 10
LightsSymbolHUD.TORQUE_GAUGE_END_LABEL_X_OFFSET_PX = 0
LightsSymbolHUD.TORQUE_GAUGE_START_LABEL_Y_OFFSET_PX = 6
LightsSymbolHUD.TORQUE_GAUGE_END_LABEL_Y_OFFSET_PX = 0
LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICKS = {0.5, 1.5, 2.5, 3.5, 4.5}
LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICK_INNER_RADIUS_PX = 100
LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICK_OUTER_RADIUS_PX = 103
LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICK_WIDTH_PX = 2
LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_TEXT = "x1000"
LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_ANCHOR = "fraction"
LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_FRACTION = 0.5
LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_RADIUS_PX = 116
LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_X_OFFSET_PX = 0
LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_Y_OFFSET_PX = 12
LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_TEXT_SIZE_FACTOR = 0.80
LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_CENTER_CHAR_INDEX = 3

local function getCurrentAppliedMotorTorqueNm(vehicle)
    local spec = vehicle ~= nil and vehicle.spec_motorized or nil
    local motor = spec ~= nil and spec.motor or nil
    if motor == nil then
        return nil
    end

    local rawTorque = nil
    if type(motor.getMotorAppliedTorque) == "function" then
        local ok, value = pcall(motor.getMotorAppliedTorque, motor)
        if ok and type(value) == "number" then
            rawTorque = value
        end
    end

    if rawTorque == nil and type(motor.motorAppliedTorque) == "number" then
        rawTorque = motor.motorAppliedTorque
    end

    if rawTorque == nil or rawTorque ~= rawTorque or math.abs(rawTorque) == math.huge then
        return 0
    end

    rawTorque = math.abs(rawTorque)

    -- GIANTS' VehicleMotor runtime torque is normally exposed in kNm-scale
    -- values (e.g. 0.924 for about 924 Nm). Keep the same defensive unit
    -- normalization as the proven dynamic FORCE diagnostic branch.
    if rawTorque < 100 then
        return rawTorque * 1000
    end

    return rawTorque
end

local function drawTorqueGaugeScale(centerX, centerY, speedMeter, activeColor)
    if speedMeter == nil or activeColor == nil then
        return
    end

    local labels = LightsSymbolHUD.TORQUE_GAUGE_SCALE_LABELS or {0, 3, 6, 9, 12, 15}
    local textSize = math.max(0.0008, (speedMeter.gaugeUnitTextSize or 0.012) * LightsSymbolHUD.TORQUE_GAUGE_SCALE_TEXT_SIZE_FACTOR)
    local labelRadiusX = speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_SCALE_LABEL_RADIUS_PX)
    local labelRadiusY = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_SCALE_LABEL_RADIUS_PX)
    local tickInnerX = speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_INNER_RADIUS_PX)
    local tickInnerY = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_INNER_RADIUS_PX)
    local tickOuterX = speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_OUTER_RADIUS_PX)
    local tickOuterY = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_OUTER_RADIUS_PX)
    local tickWidth = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_WIDTH_PX)
    local minorTickInnerX = speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICK_INNER_RADIUS_PX or LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_INNER_RADIUS_PX)
    local minorTickInnerY = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICK_INNER_RADIUS_PX or LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_INNER_RADIUS_PX)
    local minorTickOuterX = speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICK_OUTER_RADIUS_PX or LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_OUTER_RADIUS_PX)
    local minorTickOuterY = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICK_OUTER_RADIUS_PX or LightsSymbolHUD.TORQUE_GAUGE_SCALE_TICK_OUTER_RADIUS_PX)
    local minorTickWidth = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICK_WIDTH_PX or 1)
    local alpha = LightsSymbolHUD.TORQUE_GAUGE_SCALE_ALPHA or 0.9
    local colorFactor = LightsSymbolHUD.TORQUE_GAUGE_SCALE_COLOR_FACTOR or 1.0
    local r = math.max(0, math.min(1, (activeColor[1] or 1) * colorFactor))
    local g = math.max(0, math.min(1, (activeColor[2] or 1) * colorFactor))
    local b = math.max(0, math.min(1, (activeColor[3] or 1) * colorFactor))

    local function valueToFraction(value)
        if LightsSymbolHUD.TORQUE_GAUGE_MAX_NM <= 0 then
            return 0
        end
        return math.max(0, math.min(1, (value * 1000) / LightsSymbolHUD.TORQUE_GAUGE_MAX_NM))
    end

    local minorTicks = LightsSymbolHUD.TORQUE_GAUGE_MINOR_TICKS or {}
    for _, tickValue in ipairs(minorTicks) do
        local fraction = valueToFraction(tickValue)
        local angleDeg = LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG + (LightsSymbolHUD.TORQUE_GAUGE_ARC_END_DEG - LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG) * fraction
        local angle = math.rad(angleDeg)
        local x1 = centerX + math.cos(angle) * minorTickInnerX
        local y1 = centerY + math.sin(angle) * minorTickInnerY
        local x2 = centerX + math.cos(angle) * minorTickOuterX
        local y2 = centerY + math.sin(angle) * minorTickOuterY
        drawLine2D(x1, y1, x2, y2, minorTickWidth, r, g, b, alpha)
    end

    for _, label in ipairs(labels) do
        local fraction = valueToFraction(label)
        local angleDeg = LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG + (LightsSymbolHUD.TORQUE_GAUGE_ARC_END_DEG - LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG) * fraction
        local angle = math.rad(angleDeg)

        local x1 = centerX + math.cos(angle) * tickInnerX
        local y1 = centerY + math.sin(angle) * tickInnerY
        local x2 = centerX + math.cos(angle) * tickOuterX
        local y2 = centerY + math.sin(angle) * tickOuterY
        drawLine2D(x1, y1, x2, y2, tickWidth, r, g, b, alpha)

        local labelX = centerX + math.cos(angle) * labelRadiusX
        local labelY = centerY + math.sin(angle) * labelRadiusY - textSize * 0.50
        local labelText = tostring(label)
        local labelWidth = getTextWidth(textSize, labelText)
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextBold(false)
        setTextColor(r, g, b, alpha)
        renderText(labelX - labelWidth * 0.5, labelY, textSize, labelText)
    end

    setTextColor(1, 1, 1, 1)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
end


local function drawTorqueGaugeEndpoints(centerX, centerY, speedMeter, activeColor)
    if speedMeter == nil or activeColor == nil then
        return
    end

    local textSize = math.max(0.0008, (speedMeter.gaugeUnitTextSize or 0.012) * (LightsSymbolHUD.TORQUE_GAUGE_ENDPOINT_TEXT_SIZE_FACTOR or 1.0))
    local radiusX = speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_ENDPOINT_LABEL_RADIUS_PX)
    local radiusY = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_ENDPOINT_LABEL_RADIUS_PX)
    local colorFactor = LightsSymbolHUD.TORQUE_GAUGE_SCALE_COLOR_FACTOR or 1.0
    local r = math.max(0, math.min(1, (activeColor[1] or 1) * colorFactor))
    local g = math.max(0, math.min(1, (activeColor[2] or 1) * colorFactor))
    local b = math.max(0, math.min(1, (activeColor[3] or 1) * colorFactor))
    local a = activeColor[4] or 1

    local function drawAtAngle(angleDeg, label, xOffsetPx, yOffsetPx)
        if label == nil or label == "" then
            return
        end
        local angle = math.rad(angleDeg)
        local x = centerX + math.cos(angle) * radiusX
        local y = centerY + math.sin(angle) * radiusY - textSize * 0.5
        local w = getTextWidth(textSize, label)
        local xOffset = speedMeter:scalePixelToScreenWidth(xOffsetPx or 0)
        local yOffset = speedMeter:scalePixelToScreenHeight(yOffsetPx or 0)
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextBold(false)
        setTextColor(r, g, b, a)
        renderText(x - w * 0.5 + xOffset, y - yOffset, textSize, label)
    end

    drawAtAngle(
        LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG,
        LightsSymbolHUD.TORQUE_GAUGE_START_LABEL_TEXT or "Nm",
        LightsSymbolHUD.TORQUE_GAUGE_START_LABEL_X_OFFSET_PX,
        LightsSymbolHUD.TORQUE_GAUGE_START_LABEL_Y_OFFSET_PX
    )
    drawAtAngle(
        LightsSymbolHUD.TORQUE_GAUGE_ARC_END_DEG,
        LightsSymbolHUD.TORQUE_GAUGE_END_LABEL_TEXT or "",
        LightsSymbolHUD.TORQUE_GAUGE_END_LABEL_X_OFFSET_PX,
        LightsSymbolHUD.TORQUE_GAUGE_END_LABEL_Y_OFFSET_PX
    )

    setTextColor(1, 1, 1, 1)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
end

local function drawTorqueGaugeFactorLabel(centerX, centerY, speedMeter, activeColor)
    local label = LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_TEXT
    if speedMeter == nil or activeColor == nil or label == nil or label == "" then
        return
    end

    local textSize = math.max(0.0008, (speedMeter.gaugeUnitTextSize or 0.012) * (LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_TEXT_SIZE_FACTOR or 0.6))
    local radiusX = speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_RADIUS_PX or LightsSymbolHUD.TORQUE_GAUGE_ENDPOINT_LABEL_RADIUS_PX)
    local radiusY = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_RADIUS_PX or LightsSymbolHUD.TORQUE_GAUGE_ENDPOINT_LABEL_RADIUS_PX)
    local colorFactor = LightsSymbolHUD.TORQUE_GAUGE_SCALE_COLOR_FACTOR or 1.0
    local r = math.max(0, math.min(1, (activeColor[1] or 1) * colorFactor))
    local g = math.max(0, math.min(1, (activeColor[2] or 1) * colorFactor))
    local b = math.max(0, math.min(1, (activeColor[3] or 1) * colorFactor))
    local a = activeColor[4] or 1

    local anchorMode = LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_ANCHOR or "fraction"
    local angleDeg = LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG
    if anchorMode == "start" then
        angleDeg = LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG
    elseif anchorMode == "end" then
        angleDeg = LightsSymbolHUD.TORQUE_GAUGE_ARC_END_DEG
    else
        local fraction = math.max(0, math.min(1, tonumber(LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_FRACTION) or 0.5))
        angleDeg = LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG + (LightsSymbolHUD.TORQUE_GAUGE_ARC_END_DEG - LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG) * fraction
    end

    local angle = math.rad(angleDeg)
    local x = centerX + math.cos(angle) * radiusX
    local y = centerY + math.sin(angle) * radiusY - textSize * 0.5
    local w = getTextWidth(textSize, label)
    local xOffset = speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_X_OFFSET_PX or 0)
    local yOffset = speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_Y_OFFSET_PX or 0)
    local anchorWidth = w * 0.5
    local anchorCharIndex = tonumber(LightsSymbolHUD.TORQUE_GAUGE_FACTOR_LABEL_CENTER_CHAR_INDEX)
    if anchorCharIndex ~= nil and anchorCharIndex >= 1 and anchorCharIndex <= string.len(label) then
        local prefix = string.sub(label, 1, anchorCharIndex - 1)
        local centerChar = string.sub(label, anchorCharIndex, anchorCharIndex)
        anchorWidth = getTextWidth(textSize, prefix) + getTextWidth(textSize, centerChar) * 0.5
    end

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
    setTextColor(r, g, b, a)
    renderText(x - anchorWidth + xOffset, y - yOffset, textSize, label)

    setTextColor(1, 1, 1, 1)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
end

local function drawTorqueArc(centerX, centerY, radiusX, radiusY, startDeg, endDeg, fraction, width, color, segments)
    if width == nil or width <= 0 or color == nil then
        return
    end

    local clampedFraction = math.max(0, math.min(1, tonumber(fraction) or 0))
    if clampedFraction <= 0 then
        return
    end

    -- Keep one fixed segment raster for the complete arc. The previous
    -- implementation redistributed all active segment points whenever the
    -- torque fraction changed, which could make the green arc look frayed
    -- or jump between slightly different polygonal approximations.
    local totalSegments = math.max(1, math.floor(tonumber(segments) or 1))
    local r = color[1] or 1
    local g = color[2] or 1
    local b = color[3] or 1
    local a = color[4] or 1
    local arcRangeDeg = endDeg - startDeg

    local function pointAt(t)
        local angle = math.rad(startDeg + arcRangeDeg * t)
        return centerX + math.cos(angle) * radiusX, centerY + math.sin(angle) * radiusY
    end

    local exactSegments = totalSegments * clampedFraction
    local fullSegments = math.floor(exactSegments)

    for i = 1, fullSegments do
        local x1, y1 = pointAt((i - 1) / totalSegments)
        local x2, y2 = pointAt(i / totalSegments)
        drawLine2D(x1, y1, x2, y2, width, r, g, b, a)
    end

    -- Draw only the final partial segment continuously. All completed
    -- segments keep exactly the same geometry from frame to frame.
    if fullSegments < totalSegments then
        local partial = exactSegments - fullSegments
        if partial > 0.000001 then
            local x1, y1 = pointAt(fullSegments / totalSegments)
            local x2, y2 = pointAt(clampedFraction)
            drawLine2D(x1, y1, x2, y2, width, r, g, b, a)
        end
    end
end

function LightsSymbolHUD:new(speedMeter, modDirectory)
    local self = setmetatable({}, LightsSymbolHUD_mt)

    self.speedMeter = speedMeter
    self.modDirectory = modDirectory
    self.vehicle = nil
    self.isCalculated = false
    self.torqueGaugeTargetNm = 0
    self.torqueGaugeDisplayNm = 0
    self.icons = {}
    self.inactiveIcons = {}
    self.blinkerIcons = {}
    self.blinkerState = 0
    self.slipFrontPercent = 0
    self.slipRearPercent = 0
    self.slipDisplayLabels = {front = "V", rear = "H"}
    self.slipFrontTarget = 0
    self.slipRearTarget = 0
    self.slipFilteredTargetFront = 0
    self.slipFilteredTargetRear = 0

    -- Up to four physical traction axles. Axles 1/2 preserve the existing
    -- V/H display; axles 3/4 use the same icon, percentage, smoothing and
    -- startup/rotation logic.
    self.slipAxlePercent = {0, 0, 0, 0, 0, 0}
    self.slipAxleTarget = {0, 0, 0, 0, 0, 0}
    self.slipAxleFilteredTarget = {0, 0, 0, 0}
    self.slipAxleZeroSince = {nil, nil, nil, nil}
    self.slipAxleCount = 2
    self.slipDisplayLabels.axle1 = "V"
    self.slipDisplayLabels.axle2 = "H"

    self.slipWheelRotationDetected = false
    -- Per-vehicle physics-validity latch: raw slip may exist during startup,
    -- but is not valid for evaluation/display until a real post-start rotation.
    self.slipVehiclePhysicsReady = false
    self.slipZeroSince = nil
    self.slipLastSmoothTime = 0
    self.slipConfiguredAxleLimit = 4
    self.slipConfiguredDisplayMode = 0
    self.minimalSphereOrientation = 0 -- 0 vertical, 1 horizontal (minimal only)
    self.slipSmoothAccumulator = 0
    self.positions = {}
    self.slipPositions = {}
    self.slipWheelPercent = {}
    self.slipWheelTarget = {}
    self.slipWheelLabels = {}
    self.slipColorState = {}
    self.slipColorCandidate = {}
    self.slipColorCandidateSince = {}
    self.slipColorLastChange = {}
    self.slipWheelEntries = {}
    self.slipWheelCount = 0
    self.slipLabelAxleCount = nil
    self.slipChassisInfo = nil
    self.slipLayoutAxleCount = nil
    self.background = nil
    self.minimalLightBarBackground = nil
    self.baseHudX = nil
    self.baseHudWidth = nil
    self.baseHudHeight = nil
    self.minimalSymbolHudX = nil
    self.minimalSymbolHudWidth = nil


    return self
end

function LightsSymbolHUD:load()
    self:createElements()
    self:setVehicle(nil)
end

-- Convert pixel-based atlas rectangles to the native FS25 UV format.
-- GuiUtils.getUVs() is the GIANTS-supported conversion and returns the
-- 8-value UV array required by Overlay:setUVs().
local function getNormalizedUVs(rect)
    if rect == nil or rect[1] == nil or rect[2] == nil or rect[3] == nil or rect[4] == nil then
        return {0, 0, 0, 1, 1, 0, 1, 1}
    end

    local x, y, width, height = rect[1], rect[2], rect[3], rect[4]
    return GuiUtils.getUVs(
        string.format("%dpx %dpx %dpx %dpx", x, y, width, height),
        {64, 64},
        {0, 0, 0, 1, 1, 0, 1, 1}
    )
end

function LightsSymbolHUD:createElements()
    local width, height =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.ICON_SIZE)
    local workFrontWidth, workFrontHeight =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.WORK_FRONT_ICON_SIZE)
    local workBackWidth, workBackHeight =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.WORK_BACK_ICON_SIZE)

    for name, filename in pairs(LightsSymbolHUD.ICONS) do
        local elementWidth, elementHeight = width, height

        if name == "workFront" then
            elementWidth, elementHeight = workFrontWidth, workFrontHeight
        elseif name == "workBack" then
            elementWidth, elementHeight = workBackWidth, workBackHeight
        end

        local overlay = Overlay.new(
            Utils.getFilename(filename, self.modDirectory),
            0, 0, elementWidth, elementHeight
        )

        local element = HUDElement.new(overlay)

        -- Low-beam status is intentionally green; all other icons keep
        -- their original texture colors.
        if name == "low" then
            overlay:setColor(0.2, 1.0, 0.2, 1.0)
        end

        element:setVisible(false)
        self.icons[name] = element

        -- Dedicated neutral-grey inactive variant. This avoids color
        -- contamination from the original green/blue/amber textures.
        local inactiveOverlay = Overlay.new(
            Utils.getFilename("resources/inactive_" .. name .. ".dds", self.modDirectory),
            0, 0, elementWidth, elementHeight
        )
        inactiveOverlay:setColor(1.0, 1.0, 1.0, 0.50)
        local inactiveElement = HUDElement.new(inactiveOverlay)
        inactiveElement:setVisible(false)
        self.inactiveIcons[name] = inactiveElement
    end

    local blinkWidth, blinkHeight =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.BLINKER_ICON_SIZE)

    self.blinkerIcons = {}

    local blinkerFiles = {
        left = "resources/blink_left.dds",
        right = "resources/blink_right.dds",
        hazard = "resources/blink_hazard.dds"
    }

    for state, filename in pairs(blinkerFiles) do
        local iconWidth = blinkWidth
        local iconHeight = blinkHeight

        -- Only the left/right indicator symbols are reduced by 30%.
        -- Hazard remains at its existing size.
        if state == "left" or state == "right" then
            -- Left/right blinkers use the same size as the other light symbols.
            iconWidth = blinkWidth
            iconHeight = blinkHeight
        end

        local overlay = Overlay.new(
            Utils.getFilename(filename, self.modDirectory),
            0, 0, iconWidth, iconHeight
        )

        self.blinkerIcons[state] = HUDElement.new(overlay)
        self.blinkerIcons[state]:setVisible(false)
    end

    -- Tire-condition indicator: dedicated tire-condition artwork.
    -- One state is rendered at a time.
    self.tireConditionIcons = {}
    local tireConditionFiles = {
        green = "resources/tire_condition_green.dds",
        yellow = "resources/tire_condition_yellow.dds",
        red = "resources/tire_condition_red.dds",
        dynamic = "resources/tire_condition_white.dds"
    }
    for state, filename in pairs(tireConditionFiles) do
        local overlay = Overlay.new(
            Utils.getFilename(filename, self.modDirectory),
            0, 0, self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.TIRE_CONDITION_ICON_SIZE)
        )
        local element = HUDElement.new(overlay)
        element:setVisible(false)
        self.tireConditionIcons[state] = element
    end
    self.tireConditionState = "dynamic"

    -- B1.1.0.139: mixed running gear + normal wheels need two simultaneous
    -- vehicle symbols. This dedicated tire overlay is used only on mixed
    -- vehicles; the established normal tire icon remains untouched.
    do
        local overlay = Overlay.new(
            Utils.getFilename("resources/tire_condition_white.dds", self.modDirectory),
            0, 0, self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.TIRE_CONDITION_ICON_SIZE)
        )
        self.mixedVehicleTireIcon = HUDElement.new(overlay)
        self.mixedVehicleTireIcon:setVisible(false)
    end

    -- B1.1.0.132: crawler/steel-track running-gear symbol.
    -- Two independent white-mask overlays share the existing tire slot:
    -- outer band/chain = track OWN-WEAR, inner points = roller OWN-WEAR.
    -- Rubber crawler uses 3 points in a pyramid arrangement; steel track
    -- uses 2 horizontal points inside a parallel capsule/chain outline.
    self.runningGearIcons = {}
    local runningGearFiles = {
        rubberOuter = "resources/runninggear_rubber_outer_white.dds",
        rubberRollers = "resources/runninggear_rubber_rollers_white.dds",
        steelOuter = "resources/runninggear_steel_outer_white.dds",
        steelRollers = "resources/runninggear_steel_rollers_white.dds"
    }
    for name, filename in pairs(runningGearFiles) do
        local overlay = Overlay.new(
            Utils.getFilename(filename, self.modDirectory),
            0, 0, self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.RUNNING_GEAR_ICON_SIZE)
        )
        local element = HUDElement.new(overlay)
        element:setVisible(false)
        self.runningGearIcons[name] = element
    end

    -- Separate instances for the existing attached/trailer tire slot.
    self.runningGearAttachedIcons = {}
    for name, filename in pairs(runningGearFiles) do
        local overlay = Overlay.new(
            Utils.getFilename(filename, self.modDirectory),
            0, 0, self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.RUNNING_GEAR_ICON_SIZE)
        )
        local element = HUDElement.new(overlay)
        element:setVisible(false)
        self.runningGearAttachedIcons[name] = element
    end

    -- Attached trailer/implement tire-condition indicator.
    -- The dynamic tire itself uses the same neutral white tire mask as the
    -- vehicle symbol. The original integrated white "2" artwork is rendered
    -- separately underneath, so the wear gradient colors only the tire while
    -- the trailer marker remains permanently white.
    self.tireConditionAttachedIcons = {}
    local tireConditionAttachedFiles = {
        green = "resources/tire_condition_green_2.dds",
        yellow = "resources/tire_condition_yellow_2.dds",
        red = "resources/tire_condition_red_2.dds",
        dynamic = "resources/tire_condition_white.dds"
    }
    for state, filename in pairs(tireConditionAttachedFiles) do
        local overlay = Overlay.new(
            Utils.getFilename(filename, self.modDirectory),
            0, 0, self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.TIRE_CONDITION_ICON_SIZE)
        )
        local element = HUDElement.new(overlay)
        element:setVisible(false)
        self.tireConditionAttachedIcons[state] = element
    end
    self.tireConditionAttachedState = "dynamic"

    -- White trailer marker overlay. This texture contains ONLY the white "2".
    -- It is rendered after the colored tire so the marker always stays clearly
    -- visible on top and never inherits the dynamic wear tint.
    local attachedMarkerOverlay = Overlay.new(
        Utils.getFilename("resources/tire_condition_marker_2.dds", self.modDirectory),
        0, 0, self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.TIRE_CONDITION_ICON_SIZE)
    )
    attachedMarkerOverlay:setColor(0.0, 0.0, 0.0, 1.0)
    self.tireConditionAttachedMarker = HUDElement.new(attachedMarkerOverlay)
    self.tireConditionAttachedMarker:setVisible(false)

    -- Electronic immobilizer (EWFS): integrated EB symbol.
    -- Red = EWFS active/blocked, gray = EWFS known but inactive.
    local ewfsW, ewfsH =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.WFS_ICON_SIZE)

    self.wfsIcon = HUDElement.new(
        Overlay.new(
            Utils.getFilename("resources/ewfs_active.dds", self.modDirectory),
            0, 0, ewfsW, ewfsH
        )
    )
    self.wfsInactiveIcon = HUDElement.new(
        Overlay.new(
            Utils.getFilename("resources/ewfs_inactive.dds", self.modDirectory),
            0, 0, ewfsW, ewfsH
        )
    )
    self.wfsIcon:setVisible(false)
    self.wfsInactiveIcon:setVisible(false)
    self.wfsActive = false
    self.wfsAvailable = false

    local slipWidth, slipHeight =
        self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.SLIP_ICON_SIZE)

    -- NEW INDEPENDENT SLIP RENDERER
    -- No HUDElement/slipIcon renderer from the previous implementation.
    -- Private slip renderer: each overlay is wrapped in a HUDElement, exactly
    -- like the proven light-symbol renderer. No old slip renderer is reused.
    self.slipRender = {
        axle = {},
        wheel = {},
        states = {},
        wheelStates = {},
        size = {slipWidth, slipHeight}
    }

    for axleIndex = 1, 6 do
        local overlay = Overlay.new(
            Utils.getFilename("resources/wheel_slip_gray.dds", self.modDirectory),
            0, 0, slipWidth, slipHeight
        )
        local element = HUDElement.new(overlay)
        element:setVisible(false)
        self.slipRender.axle[axleIndex] = element
    end

    for wheelIndex = 1, LightsSymbolHUD.WHEEL_DISPLAY_MAX do
        local overlay = Overlay.new(
            Utils.getFilename("resources/wheel_slip_gray.dds", self.modDirectory),
            0, 0, slipWidth, slipHeight
        )
        local element = HUDElement.new(overlay)
        element:setVisible(false)
        self.slipRender.wheel[wheelIndex] = element
    end

    self.slipIconSize = {slipWidth, slipHeight}

    self.iconSizes = {
        blinkers = {blinkWidth, blinkHeight},
        low = {width, height},
        high = {width, height},
        workFront = {workFrontWidth, workFrontHeight},
        workBack = {workBackWidth, workBackHeight},
        beacon = {width, height}
    }

    self.slotHeight = self.speedMeter:scalePixelToScreenHeight(
        LightsSymbolHUD.SLOT_HEIGHT
    )

    self.gap = self.speedMeter:scalePixelToScreenHeight(
        LightsSymbolHUD.ICON_GAP
    )

    -- The distance to the vanilla speedometer scales with the speedometer.
    _, self.leftGap = self.speedMeter:scalePixelToScreenVector({
        LightsSymbolHUD.LEFT_GAP, 0
    })

    -- AutoDrive-style background:
    -- one single GIANTS base-UI overlay, using the same native background UVs
    -- as AutoDrive. No composed corners/side pieces and no custom background DDS.
    self.background = Overlay.new(g_baseUIFilename, 0, 0, 0, 0)
    self.background:setUVs(g_colorBgUVs)
    self.background:setColor(0, 0, 0, 0.55)

    self.isCalculated = false
end

function LightsSymbolHUD:delete()
    if self.minimalSeparatorOverlay ~= nil then
        self.minimalSeparatorOverlay:delete()
        self.minimalSeparatorOverlay = nil
    end

    if self.minimalSphereOverlays ~= nil then
        for _, overlay in pairs(self.minimalSphereOverlays) do
            if overlay ~= nil then
                overlay:delete()
            end
        end
        self.minimalSphereOverlays = nil
    end
    if self.minimalSphereOverlay ~= nil then
        self.minimalSphereOverlay:delete()
        self.minimalSphereOverlay = nil
    end
    for _, element in pairs(self.icons) do
        if element ~= nil then
            element:delete()
        end
    end

    for _, element in pairs(self.inactiveIcons) do
        if element ~= nil then
            element:delete()
        end
    end

    for _, element in pairs(self.blinkerIcons) do
        if element ~= nil then
            element:delete()
        end
    end

    for _, element in pairs(self.tireConditionIcons or {}) do
        if element ~= nil then element:delete() end
    end
    self.tireConditionIcons = {}
    self.tireConditionState = nil
    if self.mixedVehicleTireIcon ~= nil then
        self.mixedVehicleTireIcon:delete()
        self.mixedVehicleTireIcon = nil
    end
    for _, element in pairs(self.runningGearIcons or {}) do
        if element ~= nil then element:delete() end
    end
    self.runningGearIcons = {}
    for _, element in pairs(self.runningGearAttachedIcons or {}) do
        if element ~= nil then element:delete() end
    end
    self.runningGearAttachedIcons = {}
    for _, element in pairs(self.tireConditionAttachedIcons or {}) do
        if element ~= nil then element:delete() end
    end
    self.tireConditionAttachedIcons = {}
    self.tireConditionAttachedState = nil
    if self.tireConditionAttachedMarker ~= nil then
        self.tireConditionAttachedMarker:delete()
        self.tireConditionAttachedMarker = nil
    end
    self._tireConditionAttachedLastCount = nil
    self._tireConditionAttachedLastState = nil
    if self.wfsIcon ~= nil then self.wfsIcon:delete() end
    if self.wfsInactiveIcon ~= nil then self.wfsInactiveIcon:delete() end
    self.wfsIcon = nil
    self.wfsInactiveIcon = nil
    self.wfsActive = false
    self.wfsAvailable = false

    if self.slipRender ~= nil then
        for _, element in pairs(self.slipRender.axle or {}) do
            if element ~= nil then element:delete() end
        end
        for _, element in pairs(self.slipRender.wheel or {}) do
            if element ~= nil then element:delete() end
        end
    end

    self.icons = {}
    self.inactiveIcons = {}
    self.blinkerIcons = {}
    self.slipRender = nil
    self.positions = {}
    self.slipPositions = {}

    if self.minimalLightBarBackground ~= nil then
        self.minimalLightBarBackground:delete()
        self.minimalLightBarBackground = nil
    end

    if self.background ~= nil then
        self.background:delete()
        self.background = nil
    end
end

function LightsSymbolHUD:setVehicle(vehicle)
    self.vehicle = vehicle
    self.torqueGaugeTargetNm = 0
    self.torqueGaugeDisplayNm = 0

    -- Do not move/recalculate slots based on which lights are active.
    -- The five HUD slots are always fixed relative to the speedometer.
    self.isCalculated = false

    for _, element in pairs(self.icons) do
        element:setVisible(false)
    end

    for _, element in pairs(self.inactiveIcons) do
        element:setVisible(false)
    end

    for _, element in pairs(self.blinkerIcons) do
        element:setVisible(false)
    end
    for _, element in pairs(self.tireConditionIcons or {}) do
        element:setVisible(false)
    end
    self.tireConditionState = "dynamic"
    for _, element in pairs(self.runningGearIcons or {}) do
        element:setVisible(false)
    end
    if self.mixedVehicleTireIcon ~= nil then
        self.mixedVehicleTireIcon:setVisible(false)
    end
    for _, element in pairs(self.runningGearAttachedIcons or {}) do
        element:setVisible(false)
    end
    for _, element in pairs(self.tireConditionAttachedIcons or {}) do
        element:setVisible(false)
    end
    self.tireConditionAttachedState = "dynamic"
    if self.tireConditionAttachedMarker ~= nil then
        self.tireConditionAttachedMarker:setVisible(false)
    end
    self._tireConditionAttachedLastCount = nil
    self._tireConditionAttachedLastState = nil
    if self.wfsIcon ~= nil then self.wfsIcon:setVisible(false) end
    if self.wfsInactiveIcon ~= nil then self.wfsInactiveIcon:setVisible(false) end
    self.wfsActive = false
    self.wfsAvailable = false

    self.blinkerState = 0
    self.slipFrontPercent = 0
    self.slipRearPercent = 0
    self.slipFrontTarget = 0
    self.slipRearTarget = 0
    self.slipFilteredTargetFront = 0
    self.slipFilteredTargetRear = 0
    self.slipAxleTarget = {0, 0, 0, 0, 0, 0}
    self.slipAxleFilteredTarget = {0, 0, 0, 0}
    self.slipAxlePercent = {0, 0, 0, 0, 0, 0}
    self.slipAxleZeroSince = {nil, nil, nil, nil}
    self.slipLastSmoothTime = 0
    self.slipWheelRotationDetected = false
    -- Reset the physics-validity latch on vehicle/tab change.
    self.slipVehiclePhysicsReady = false
    self.slipZeroSince = nil
    if self.slipRender ~= nil then
        self.slipRender.states = {}
        self.slipRender.wheelStates = {}
        for _, element in pairs(self.slipRender.axle or {}) do element:setVisible(false) end
        for _, element in pairs(self.slipRender.wheel or {}) do element:setVisible(false) end
    end
    self.slipWheelPercent = {}
    self.slipWheelTarget = {}
    self.slipWheelLabels = {}
    self.slipColorState = {}
    self.slipColorCandidate = {}
    self.slipColorCandidateSince = {}
    self.slipColorLastChange = {}
    self.slipWheelEntries = {}
    self.slipWheelCount = 0
    self.slipLabelAxleCount = nil
    self.slipChassisInfo = nil
    self.slipLayoutAxleCount = nil
    if self.slipRender ~= nil then
        for _, element in pairs(self.slipRender.axle or {}) do element:setVisible(false) end
        for _, element in pairs(self.slipRender.wheel or {}) do element:setVisible(false) end
    end
end

local function getSlipDisplayMode()
    if LightsSymbolHUDSettings ~= nil and LightsSymbolHUDSettings.getDisplayMode ~= nil then
        return LightsSymbolHUDSettings:getDisplayMode()
    end
    return 0
end

function LightsSymbolHUD:calculatePosition()
    if self.speedMeter == nil or self.speedMeter.speedBg == nil then
        return false
    end

    local bg = self.speedMeter.speedBg
    local viewScale = (tonumber(self.hudViewMode) == 1) and 0.70 or 1.0
    local slotHeight = self.slotHeight * viewScale
    local gap = self.gap * viewScale

    -- Anchor the complete HUD to the vanilla speedometer.
    -- This keeps the relationship correct at 1080p, 1440p, 4K, etc.
    local rightEdge = bg.x - self.leftGap

    local totalHeight =
        slotHeight * #LightsSymbolHUD.SLOT_ORDER
        + gap * (#LightsSymbolHUD.SLOT_ORDER - 1)

    local firstSlotTop =
        bg.y + (bg.height + totalHeight) * 0.5

    -- Compact view only: move the COMPLETE HUD block downward until its
    -- lower edge matches the lower edge of the full-view HUD. The full-view
    -- geometry remains the reference; no fixed pixel guess is used, so the
    -- alignment stays resolution-independent.
    if viewScale < 1.0 then
        local fullTotalHeight =
            self.slotHeight * #LightsSymbolHUD.SLOT_ORDER
            + self.gap * (#LightsSymbolHUD.SLOT_ORDER - 1)
        local fullLowerEdge =
            bg.y + (bg.height - fullTotalHeight) * 0.5
        local compactLowerEdge =
            bg.y + (bg.height - totalHeight) * 0.5
        local compactDownOffset = fullLowerEdge - compactLowerEdge
        firstSlotTop = firstSlotTop + compactDownOffset
    end

    self.positions = {}

    local bgPadding = self.speedMeter:scalePixelToScreenHeight(2) * viewScale
    local hudWidth = 0
    for _, name in ipairs(LightsSymbolHUD.SLOT_ORDER) do
        hudWidth = math.max(hudWidth, self.iconSizes[name][1] * viewScale)
    end

    local hudHeight =
        slotHeight * #LightsSymbolHUD.SLOT_ORDER
        + gap * (#LightsSymbolHUD.SLOT_ORDER - 1)

    local hudX = rightEdge - hudWidth - bgPadding
    local hudBottom = firstSlotTop - hudHeight
    local hudBgWidth = hudWidth + bgPadding * 2
    -- Background starts at the upper edge of the blinker slot.
    local hudBgHeight = hudHeight + bgPadding * 2

    -- In minimal view, move only the complete light-symbol column left to
    -- match the horizontal alignment of the full view and keep it clear of
    -- the tachometer/other HUDs. The sphere/slip renderer has its own anchor
    -- and is deliberately not moved by this correction.
    local minimalHudXOffset = 0
    if tonumber(self.hudViewMode) == 2 then
        minimalHudXOffset = self.speedMeter:scalePixelToScreenWidth(
            LightsSymbolHUD.MINIMAL_LIGHT_HUD_X_OFFSET
        )
        hudX = hudX + minimalHudXOffset
    end

    -- Keep the original single light-symbol column geometry separately.
    -- Later display modes may extend hudX/hudWidth for slip columns, but the
    -- minimal view uses only this one vertical light-symbol background column.
    self.baseHudX = hudX
    self.baseHudWidth = hudBgWidth
    self.baseHudHeight = hudBgHeight

    -- Preserve the pre-correction blinker anchor for the minimal sphere bar.
    -- Its column-2/3 anchor must remain exactly where TEST3/TEST4 established it.
    self.minimalSphereAnchorX = (hudX - minimalHudXOffset) + (hudWidth - (self.iconSizes.blinkers[1] * viewScale)) * 0.5

    for index, name in ipairs(LightsSymbolHUD.SLOT_ORDER) do
        local slotTop =
            firstSlotTop
            - (index - 1) * (slotHeight + gap)

        local size = self.iconSizes[name]
        local scaledW = size[1] * viewScale
        local scaledH = size[2] * viewScale
        local opticalX = (LightsSymbolHUD.ICON_OPTICAL_X_OFFSET[name] or 0) * viewScale
        local iconX = hudX + (hudWidth - scaledW) * 0.5
            + self.speedMeter:scalePixelToScreenWidth(opticalX)

        local iconY =
            slotTop - (slotHeight + scaledH) * 0.5

        self.positions[name] = {iconX, iconY}

        if self.icons[name] ~= nil and self.icons[name].overlay ~= nil then
            self.icons[name].overlay:setDimension(scaledW, scaledH)
        end
        if self.inactiveIcons[name] ~= nil and self.inactiveIcons[name].overlay ~= nil then
            self.inactiveIcons[name].overlay:setDimension(scaledW, scaledH)
        end
    end

    local rightHudX = hudX
    local rightHudWidth = hudWidth

    local firstPos = self.positions.blinkers
    if firstPos ~= nil then
        local textSize = self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.SLIP_TEXT_SIZE) * viewScale
        local probeText = "H 100%"
        local textWidth = getTextWidth(textSize, probeText)
        local textRight = firstPos[1]
        local textLeft = textRight - textWidth
        local scaledSlipW = self.slipIconSize[1] * viewScale
        local scaledSlipH = self.slipIconSize[2] * viewScale
        local slipX = textLeft + (textWidth - scaledSlipW) * 0.5

        local function getCenteredSlipY(lightName)
            local lightPos = self.positions[lightName]
            local lightSize = self.iconSizes[lightName]
            if lightPos == nil or lightSize == nil then
                return nil
            end
            local centerOffset = (lightSize[2] * viewScale - scaledSlipH) * 0.5
            return lightPos[2] + centerOffset
        end

        local slipIconYFront = getCenteredSlipY("workFront")
        local slipIconYRear = getCenteredSlipY("workBack")
        local slipIconYAxle1 = getCenteredSlipY("high")
        local slipIconYAxle2 = getCenteredSlipY("beacon")
        local slipIconYAxle3 = slipIconYFront
        local slipIconYAxle4 = slipIconYRear

        self.slipPositions.front = {slipX, slipIconYFront}
        self.slipPositions.rear = {slipX, slipIconYRear}
        self.slipPositions.axle1 = {slipX, slipIconYAxle1}
        self.slipPositions.axle2 = {slipX, slipIconYAxle2}
        self.slipPositions.axle3 = {slipX, slipIconYAxle3}
        self.slipPositions.axle4 = {slipX, slipIconYAxle4}
        -- Six-axis mode uses two additional rows above the former first
        -- slip row: blinkers, low, high, beacon, front work, rear work.
        self.slipPositions.axle6 = {slipX, self.positions.workBack[2] + 0}
        -- Six-axis PAIR view uses the same one-slot vertical shift as the
        -- individual-wheel view. This keeps A1 clear of the blinker slot.
        local sixAxleY = {}
        for row = 1, 6 do
            local lightSlotIndex = row + 1
            local lightName = LightsSymbolHUD.SLOT_ORDER[lightSlotIndex]
            local lightPos = lightName ~= nil and self.positions[lightName] or nil
            local lightSize = lightName ~= nil and self.iconSizes[lightName] or nil
            if lightPos ~= nil and lightSize ~= nil then
                sixAxleY[row] = lightPos[2] + (lightSize[2] - self.slipIconSize[2]) * 0.5
            elseif row > 1 and sixAxleY[row - 1] ~= nil then
                sixAxleY[row] = sixAxleY[row - 1] - (slotHeight + gap)
            end
        end

        -- Six-axis PAIR view: move the complete axle-pair column one
        -- horizontal slot to the left. The vertical placement stays exactly
        -- as resolved above. Individual-wheel view is not changed.
        local sixAxleX = slipX - textWidth
            - self.speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.WHEEL_COLUMN_GAP) * viewScale

        self.slipPositions.sixAxle = {}
        for row = 1, 6 do
            self.slipPositions.sixAxle[row] = {
                sixAxleX,
                sixAxleY[row] or (self.positions.workBack[2] - (row - 5) * (slotHeight + gap))
            }
        end

        self.blinkerPositions = self.blinkerPositions or {}

        -- Minimal/Kugel view: keep the original light-symbol column as the
        -- reference column, place the second symbol column exactly one full
        -- background-column width to its left, and center every symbol in that
        -- second column. Full view keeps the proven historic placement.
        local scaledBlinkW = self.iconSizes.blinkers[1] * viewScale
        local scaledBlinkH = self.iconSizes.blinkers[2] * viewScale
        local secondSymbolColumnLeft = nil
        local secondSymbolColumnWidth = self.baseHudWidth or hudBgWidth
        local leftBlinkerX = slipX
        if tonumber(self.hudViewMode) == 2 then
            secondSymbolColumnLeft = (self.baseHudX or hudX) - secondSymbolColumnWidth
            leftBlinkerX = secondSymbolColumnLeft
                + (secondSymbolColumnWidth - scaledBlinkW) * 0.5
        end
        self.blinkerPositions.left = {leftBlinkerX, self.positions.blinkers[2]}

        -- Tire-condition indicator uses the proven permanent-test position:
        -- same X as the LEFT blinker, one light slot lower (LOW).
        if self.tireConditionIcons ~= nil then
            local tireW, tireH = self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.TIRE_CONDITION_ICON_SIZE)
            tireW = tireW * viewScale
            tireH = tireH * viewScale
            local tireX = self.blinkerPositions.left[1]
            if tonumber(self.hudViewMode) == 2 and secondSymbolColumnLeft ~= nil then
                tireX = secondSymbolColumnLeft
                    + (secondSymbolColumnWidth - tireW) * 0.5
            end
            local tireY = self.positions.low[2] + (self.iconSizes.low[2] * viewScale - tireH) * 0.5
            for _, element in pairs(self.tireConditionIcons) do
                element.overlay:setDimension(tireW, tireH)
                element:setPosition(tireX, tireY)
            end
            -- B1.1.0.133: running-gear symbol fills the complete symbol slot.
            local rgW, rgH = self.speedMeter:scalePixelToScreenVector(LightsSymbolHUD.RUNNING_GEAR_ICON_SIZE)
            rgW = rgW * viewScale
            rgH = rgH * viewScale
            local rgX = self.blinkerPositions.left[1] - (rgW - tireW) * 0.5
            if tonumber(self.hudViewMode) == 2 and secondSymbolColumnLeft ~= nil then
                rgX = secondSymbolColumnLeft + (secondSymbolColumnWidth - rgW) * 0.5
            end
            local rgY = self.positions.low[2] + (self.iconSizes.low[2] * viewScale - rgH) * 0.5
            for _, element in pairs(self.runningGearIcons or {}) do
                element.overlay:setDimension(rgW, rgH)
                element:setPosition(rgX, rgY)
            end
            -- Attached trailer/implement symbol is exactly one full light slot
            -- below the vehicle tire symbol, aligned to the HIGH-beam slot.
            -- This keeps both columns on the same HUD row regardless of the
            -- different transparent margins of the tire artwork.
            local attachedY = self.positions.high[2]
                + (self.iconSizes.high[2] * viewScale - tireH) * 0.5

            -- Store exact wear-column geometry for dynamic mixed-vehicle
            -- placement during render. One slot lower means subtracting one
            -- scaled SLOT_HEIGHT, matching the established EWFS placement.
            local wearSlotStep = self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.SLOT_HEIGHT)
            self._rvWearLayout = {
                tireX=tireX, tireY=tireY, tireW=tireW, tireH=tireH,
                rgX=rgX, rgY=rgY, rgW=rgW, rgH=rgH,
                attachedY=attachedY, slotStep=wearSlotStep
            }
            if self.mixedVehicleTireIcon ~= nil and self.mixedVehicleTireIcon.overlay ~= nil then
                self.mixedVehicleTireIcon.overlay:setDimension(tireW,tireH)
                self.mixedVehicleTireIcon:setPosition(tireX,attachedY)
            end

            for _, element in pairs(self.tireConditionAttachedIcons or {}) do
                element.overlay:setDimension(tireW, tireH)
                element:setPosition(tireX, attachedY)
            end
            local attachedRgY = self.positions.high[2]
                + (self.iconSizes.high[2] * viewScale - rgH) * 0.5
            for _, element in pairs(self.runningGearAttachedIcons or {}) do
                element.overlay:setDimension(rgW, rgH)
                element:setPosition(rgX, attachedRgY)
            end
            -- B1.1.0.140: trailer marker "2" is intentionally disabled.
            if self.tireConditionAttachedMarker ~= nil then
                self.tireConditionAttachedMarker:setVisible(false)
            end

            -- Minimal/Kugel view now has two real symbol columns: the original
            -- light column on the right and the left blinker/tire/EWFS column.
            -- Store a dedicated background span for exactly those two columns;
            -- the sphere/slip background stays separate and is not included.
            local minimalLeft = secondSymbolColumnLeft or (tireX - bgPadding)
            local minimalRight = (self.baseHudX or hudX) + (self.baseHudWidth or hudBgWidth)
            self.minimalSymbolHudX = math.min(self.baseHudX or hudX, minimalLeft)
            self.minimalSymbolHudWidth = math.max(0, minimalRight - self.minimalSymbolHudX)

            -- EWFS EB symbol: two full slots below the vehicle tire symbol.
            -- Same position is used for red and gray states.
            local wfsY = tireY - 2 * self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.SLOT_HEIGHT)
            if self.wfsIcon ~= nil then
                self.wfsIcon.overlay:setDimension(tireW, tireH)
                self.wfsIcon:setPosition(tireX, wfsY)
            end
            if self.wfsInactiveIcon ~= nil then
                self.wfsInactiveIcon.overlay:setDimension(tireW, tireH)
                self.wfsInactiveIcon:setPosition(tireX, wfsY)
            end
        end

        for _, element in pairs(self.blinkerIcons or {}) do
            if element ~= nil and element.overlay ~= nil then
                element.overlay:setDimension(scaledBlinkW, scaledBlinkH)
            end
        end
        for _, element in ipairs((self.slipRender and self.slipRender.axle) or {}) do
            if element ~= nil and element.overlay ~= nil then
                element.overlay:setDimension(scaledSlipW, scaledSlipH)
            end
        end
        for _, element in ipairs((self.slipRender and self.slipRender.wheel) or {}) do
            if element ~= nil and element.overlay ~= nil then
                element.overlay:setDimension(scaledSlipW, scaledSlipH)
            end
        end

        -- In "Alle Räder" mode the light-symbol column remains completely
        -- untouched. It is the rightmost (logical column 1). The two wheel
        -- columns are placed to its left (logical columns 2 and 3).
        -- Each ROW represents one physical axle/unit: R1+R2, R3+R4, ...
        -- This prevents wheel entries from drifting into the light column and
        -- keeps the two wheels belonging to the same axle on one horizontal line.
        self.wheelPositions = {}
        self.wheelPositionsSixAxle = {}
        self.wheelColumnX = {}
        local wheelColumnGap = self.speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.WHEEL_COLUMN_GAP) * viewScale
        local wheelColumnWidth = textWidth

        -- Logical column 2 is immediately left of the light/slip reference
        -- area; logical column 3 is one complete text block further left.
        local wheelColumn2X = slipX - wheelColumnWidth - wheelColumnGap
        local wheelColumn3X = wheelColumn2X - wheelColumnWidth - wheelColumnGap
        self.wheelColumnX[2] = wheelColumn2X
        self.wheelColumnX[3] = wheelColumn3X

        -- Build six possible row anchors. Rows 1..6 are aligned to the
        -- existing light rows 2..6 and then continue below the light HUD for
        -- configurations that expose more than four axles.
        local wheelRowY = {}
        for row = 1, 6 do
            local lightSlotIndex = row + 2
            local lightName = LightsSymbolHUD.SLOT_ORDER[lightSlotIndex]
            local lightPos = lightName ~= nil and self.positions[lightName] or nil
            local lightSize = lightName ~= nil and self.iconSizes[lightName] or nil
            if lightPos ~= nil and lightSize ~= nil then
                wheelRowY[row] = lightPos[2] + (lightSize[2] - self.slipIconSize[2]) * 0.5
            elseif row > 4 then
                local previousY = wheelRowY[row - 1]
                if previousY ~= nil then
                    wheelRowY[row] = previousY - (slotHeight + gap)
                end
            end
        end

        -- The actual number of rows is determined later from the confirmed
        -- wheel entries. Pre-create positions for all 12 possible wheels.
        for wheelIndex = 1, LightsSymbolHUD.WHEEL_DISPLAY_MAX do
            local row = math.floor((wheelIndex - 1) / 2) + 1
            local column = ((wheelIndex - 1) % 2 == 0) and 3 or 2
            self.wheelPositions["wheel" .. tostring(wheelIndex)] = {
                self.wheelColumnX[column] + (wheelColumnWidth - scaledSlipW) * 0.5,
                wheelRowY[row] or self.positions.blinkers[2]
            }
        end
        -- Six-axis wheel mode shifts the complete six-row block two slots up.
        local wheelRowYSix = {}
        for row = 1, 6 do
            local lightName = LightsSymbolHUD.SLOT_ORDER[row]
            local lightPos = lightName ~= nil and self.positions[lightName] or nil
            local lightSize = lightName ~= nil and self.iconSizes[lightName] or nil
            if lightPos ~= nil and lightSize ~= nil then
                wheelRowYSix[row] = lightPos[2] + (lightSize[2] - self.slipIconSize[2]) * 0.5
            end
        end
        for wheelIndex = 1, LightsSymbolHUD.WHEEL_DISPLAY_MAX do
            local row = math.floor((wheelIndex - 1) / 2) + 1
            local column = ((wheelIndex - 1) % 2 == 0) and 3 or 2
            self.wheelPositionsSixAxle["wheel" .. tostring(wheelIndex)] = {
                self.wheelColumnX[column] + (wheelColumnWidth - scaledSlipW) * 0.5,
                wheelRowYSix[row] or self.positions.blinkers[2]
            }
        end

        local slipLeft = textLeft
        local slipRight = textRight
        local oldLeft = rightHudX
        local newLeft = math.min(oldLeft, slipLeft - bgPadding)
        local newRight = math.max(rightHudX + rightHudWidth, slipRight + bgPadding)

        if getSlipDisplayMode() == 1 then
            -- Individual-wheel mode already owns the two wheel columns.
            newLeft = math.min(newLeft, wheelColumn3X - bgPadding)
        elseif tonumber(self.slipConfiguredAxleLimit) == 6 then
            -- Six-axis PAIR mode uses one additional logical slot column to
            -- the left. Extend the background exactly to that column.
            -- Do not enlarge the background for 2/4-axis pair mode.
            local sixAxleLeft = sixAxleX - textWidth * 0.5
            newLeft = math.min(newLeft, sixAxleLeft - bgPadding)
        end

        hudX = newLeft
        hudBgWidth = newRight - newLeft
    end

    self.hudX = hudX
    self.hudBottom = hudBottom
    self.hudWidth = hudBgWidth
    self.hudHeight = hudBgHeight

    -- AutoDrive-style single-overlay positioning.
    -- The native GIANTS background texture is stretched to our fixed HUD box.
    if self.background ~= nil then
        self.background:setPosition(hudX, hudBottom - bgPadding)
        self.background:setDimension(hudBgWidth, hudBgHeight)
    end

    self.isCalculated = true
    return true
end

local function isMaskActive(mask, lightType)
    if mask == nil or lightType == nil then
        return false
    end

    return bit32.band(mask, 2 ^ lightType) ~= 0
end

local function getWheelSlipPercent(wheel, vehicle)
    if wheel == nil or wheel.node == nil or wheel.physics == nil then
        return 0
    end

    local wheelShape = wheel.physics.wheelShape
    local radius = wheel.physics.radius or 0
    if wheelShape == nil or radius <= 0 then
        return 0
    end

    local okSpeed, axleSpeed = pcall(getWheelShapeAxleSpeed, wheel.node, wheelShape)
    if not okSpeed or axleSpeed == nil then
        return 0
    end

    local wheelLinearSpeed = math.abs(axleSpeed * radius)

    -- lastSpeedReal is m/ms in FS25.
    local vehicleSpeed = 0
    if vehicle ~= nil and vehicle.lastSpeedReal ~= nil then
        vehicleSpeed = math.abs(vehicle.lastSpeedReal * 1000)
    end

    local hasGroundContact = wheel.physics.hasGroundContact == true

    -- Airborne wheel:
    -- At low/zero vehicle speed we still want to show a genuinely spinning
    -- free wheel. A small rotation threshold suppresses suspension/physics
    -- twitch. The display is deliberately not 1:1 with wheel speed.
    if not hasGroundContact then
        if vehicleSpeed < 1.0 then
            -- No artificial 0.75 m/s wheel-speed threshold. A genuinely
            -- rotating airborne driven wheel must remain eligible for slip.
            if wheelLinearSpeed <= 0 then
                return 0
            end

            return math.clamp(wheelLinearSpeed * 100, 0, 100)
        end

        if wheelLinearSpeed <= 0 then
            return 0
        end

        local airborneRatio = (wheelLinearSpeed - vehicleSpeed) / math.max(vehicleSpeed, 1.0)
        if airborneRatio <= 0.01 then
            return 0
        end

        return math.clamp(airborneRatio * 100, 0, 100)
    end

    -- Stationary vehicle with a wheel against an obstacle:
    -- lastSpeedReal is near zero, so a pure wheel-speed/vehicle-speed ratio
    -- cannot work. FS25 exposes the actual wheel longitudinal slip through
    -- getWheelShapeSlip(); use that first for grounded wheels.
    if vehicleSpeed < 0.75 then
        local okSlip, longitudinalSlip = pcall(getWheelShapeSlip, wheel.node, wheelShape)

        if okSlip and longitudinalSlip ~= nil then
            local slip = math.abs(longitudinalSlip)
            if slip > 0.01 then
                return math.clamp(slip * 100, 0, 100)
            end
        end

        -- Fallback if the engine does not report useful slip for this
        -- contact. Do not impose an artificial wheel-speed threshold here.
        if wheelLinearSpeed <= 0 then
            return 0
        end

        return math.clamp(wheelLinearSpeed * 100, 0, 100)
    end

    -- Normal moving, grounded wheel:
    -- Keep the previously working behavior unchanged.
    if wheelLinearSpeed <= vehicleSpeed then
        return 0
    end

    local referenceSpeed = math.max(vehicleSpeed, 1.0)
    local slipRatio = (wheelLinearSpeed - vehicleSpeed) / referenceSpeed

    if slipRatio < 0.01 then
        return 0
    end

    return math.clamp(slipRatio * 100, 0, 100)
end

-- Build an authoritative set of traction wheels from GIANTS' drivetrain.
-- Motorized differentials are recursive: a differential can point to wheels
-- or to other differentials. Crawler speed-reference wheels are added for
-- crawler vehicles because the Crawlers specialization explicitly defines
-- those wheels as the crawler's speed references.
local function getTractionWheels(vehicle)
    local traction = {}
    local specMotorized = vehicle ~= nil and vehicle.spec_motorized or nil

    if specMotorized ~= nil and specMotorized.differentials ~= nil then
        local diffs = specMotorized.differentials
        local visited = {}

        local function visitDiff(index)
            if index == nil or visited[index] then
                return
            end
            visited[index] = true

            local diff = diffs[index]
            if diff == nil then
                return
            end

            if diff.diffIndex1IsWheel then
                traction[diff.diffIndex1] = true
            else
                visitDiff(diff.diffIndex1)
            end

            if diff.diffIndex2IsWheel then
                traction[diff.diffIndex2] = true
            else
                visitDiff(diff.diffIndex2)
            end
        end

        for index, _ in pairs(diffs) do
            visitDiff(index)
        end
    end

    -- crawler.wheels/wheelIndices are GIANTS crawler speed-reference data,
    -- not proof of independent drivetrain membership. Do not promote them
    -- into the drivetrain truth set. Actual drive membership comes from the
    -- motorized differential graph above.
    return traction
end

local macDonDiagnosticDumped = setmetatable({}, {__mode = "k"})

local function dumpMacDonDriveDiagnostic(vehicle, manifest, traction)
    if LightsSymbolHUD.DEBUG_ENABLED ~= true then return end
    if vehicle == nil or macDonDiagnosticDumped[vehicle] then
        return
    end

    local wheels = vehicle.spec_wheels ~= nil and vehicle.spec_wheels.wheels or nil
    if wheels == nil then
        return
    end

    local wheelCount = 0
    for _, wheel in pairs(wheels) do
        if wheel ~= nil then wheelCount = wheelCount + 1 end
    end

    local wheelAxles = vehicle.wheelAxles
    if wheelAxles == nil and vehicle.spec_wheels ~= nil then
        wheelAxles = vehicle.spec_wheels.wheelAxles
    end

    local axleCount = 0
    if wheelAxles ~= nil then
        for _, _ in pairs(wheelAxles) do axleCount = axleCount + 1 end
    end

    -- Diagnostic target: the MacDon configuration currently seen by the HUD
    -- as four normal wheels on two WheelAxles. No vehicle-specific behavior
    -- is changed; this only records the runtime data once.
    if wheelCount ~= 4 or axleCount ~= 2 then
        return
    end

    macDonDiagnosticDumped[vehicle] = true

    print("[LightsSymbolHUD][MACDON_DIAG] ===== DRIVE / AXLE RUNTIME DATA =====")
    print(string.format("[LightsSymbolHUD][MACDON_DIAG] config=%s wheels=%d wheelAxles=%d",
        tostring(vehicle.configFileName or "?"), wheelCount, axleCount))

    for index, wheel in pairs(wheels) do
        if wheel ~= nil then
            local key = getWheelIndexKey(wheel, index)
            local ok, x, _, z = false, nil, nil, nil
            if wheel.repr ~= nil and vehicle.rootNode ~= nil then
                ok, x, _, z = pcall(localToLocal, wheel.repr, vehicle.rootNode, 0, 0, 0)
            end
            print(string.format(
                "[LightsSymbolHUD][MACDON_DIAG] WHEEL index=%s key=%s driveMode=%s wheelAxle=%s x=%s z=%s traction=%s",
                tostring(index), tostring(key), tostring(wheel.driveMode), tostring(wheel.wheelAxle),
                ok and string.format("%.3f", x or 0) or "?",
                ok and string.format("%.3f", z or 0) or "?",
                key ~= nil and tostring(traction[key] == true) or "false"))
        end
    end

    if wheelAxles ~= nil then
        local ai = 0
        for _, axle in pairs(wheelAxles) do
            ai = ai + 1
            local w1, w2 = axle.wheel1, axle.wheel2
            print(string.format(
                "[LightsSymbolHUD][MACDON_DIAG] WHEELAXLE %d: W1=%s W2=%s",
                ai, tostring(getWheelIndexKey(w1, nil)), tostring(getWheelIndexKey(w2, nil))))
        end
    end

    local diffs = vehicle.spec_motorized ~= nil and vehicle.spec_motorized.differentials or nil
    if diffs ~= nil then
        for di, diff in pairs(diffs) do
            print(string.format(
                "[LightsSymbolHUD][MACDON_DIAG] DIFF %s: wheel1=%s isWheel1=%s wheel2=%s isWheel2=%s",
                tostring(di), tostring(diff.diffIndex1), tostring(diff.diffIndex1IsWheel),
                tostring(diff.diffIndex2), tostring(diff.diffIndex2IsWheel)))
        end
    end

    if manifest ~= nil then
        for ai, axle in ipairs(manifest.axleUnits or {}) do
            local keys = {}
            for _, wheel in ipairs(axle.wheels or {}) do
                keys[#keys + 1] = tostring(getWheelIndexKey(wheel, nil) or "?")
            end
            print(string.format(
                "[LightsSymbolHUD][MACDON_DIAG] RESOLVED_AXLE %d: kind=%s driven=%s wheels=%s",
                ai, tostring(axle.kind), tostring(axle.driven), table.concat(keys, ",")))
        end
    end

    print("[LightsSymbolHUD][MACDON_DIAG] =====================================")
end

local function getWheelIndexKey(wheel, fallbackIndex)
    if wheel ~= nil and wheel.wheelIndex ~= nil then
        return wheel.wheelIndex
    end
    return fallbackIndex
end

-- Live wheel-slip state.
-- A missing/invalid physics result is NOT a real 0 % slip value.
-- Per-wheel state allows short physics gaps to be bridged without changing
-- the A/B wheel/axle recognition.
local wheelSlipState = setmetatable({}, {__mode = "k"})

local WHEEL_SLIP_HOLD_MS = 1000
local WHEEL_SLIP_COUNTERPART_MS = 2000

local function getSlipNow()
    return g_currentMission ~= nil and g_currentMission.time or 0
end

local function getWheelAngularSpeed(wheel)
    if wheel == nil or wheel.physics == nil
        or wheel.physics.wheelShape == nil or wheel.node == nil then
        return nil
    end

    local ok, axleSpeed =
        pcall(getWheelShapeAxleSpeed, wheel.node, wheel.physics.wheelShape)

    if ok and type(axleSpeed) == "number" and math.abs(axleSpeed) < math.huge then
        return math.abs(axleSpeed)
    end

    return nil
end

local function readWheelSlipRaw(wheel, vehicle)
    if wheel == nil or wheel.physics == nil
        or wheel.physics.wheelShape == nil or wheel.node == nil then
        return nil
    end

    local radius = tonumber(wheel.physics.radius) or 0
    local axleSpeed = getWheelAngularSpeed(wheel)

    -- Do not classify a non-rotating wheel as 0 % once a ready vehicle is
    -- actually moving on the ground. A stopped/locked wheel while the vehicle
    -- continues to move is valid longitudinal relative motion (braking,
    -- steering inertia, heavy load, etc.) and must remain eligible for slip.
    local vehicleSpeed = 0
    if vehicle ~= nil and vehicle.lastSpeedReal ~= nil then
        vehicleSpeed = math.abs(vehicle.lastSpeedReal * 1000)
    end

    -- True standstill filter:
    -- A stale GIANTS longitudinal-slip sample (commonly ~20 %) is not a
    -- physical slip event when the vehicle is effectively stopped AND the
    -- wheel itself is not rotating. Do this BEFORE reading/accepting the
    -- engine-slip value so the raw value can never become the HUD target.
    -- If the wheel is physically rotating, even at vehicle standstill, the
    -- calculation continues below and real stationary-wheel slip remains
    -- possible. If the vehicle is still rolling, the calculation also
    -- continues so inertia/braking slip is preserved.
    local STANDSTILL_SPEED_KMH = 0.05
    local STANDSTILL_ROTATION = 0.01
    if vehicleSpeed <= STANDSTILL_SPEED_KMH
        and axleSpeed ~= nil
        and axleSpeed <= STANDSTILL_ROTATION then
        return 0
    end

    -- Read the engine's longitudinal slip independently of ground contact.
    -- A contact with terrain, a wall or another obstacle must not select a
    -- different validity path by itself.
    local okSlip, longitudinalSlip =
        pcall(getWheelShapeSlip, wheel.node, wheel.physics.wheelShape)

    if okSlip and type(longitudinalSlip) == "number"
        and math.abs(longitudinalSlip) < math.huge then

        local engineSlip = math.abs(longitudinalSlip) * 100

        -- If the engine reports meaningful slip, use it directly. This is
        -- especially important for a wheel pushing against an obstacle while
        -- vehicle speed is near zero.
        if engineSlip > 0.01 then
            return math.clamp(engineSlip, 0, 100)
        end

        -- A genuine zero is valid only when there is no relative motion to
        -- evaluate. If the vehicle is moving and this grounded wheel is not
        -- rotating, the fallback below must be allowed to report high slip.
        if axleSpeed == nil then
            if vehicleSpeed < 0.75 or wheel.physics.hasGroundContact ~= true then
                return 0
            end
            return 100
        end

        -- The engine can report 0 while a driven wheel is visibly spinning,
        -- e.g. airborne or against an obstacle. Fall back to wheel speed
        -- versus vehicle speed, without using hasGroundContact as a switch.
        if radius > 0 then
            local wheelLinearSpeed = axleSpeed * radius

            if vehicleSpeed < 0.01 then
                return math.clamp(wheelLinearSpeed * 100, 0, 100)
            end

            if wheelLinearSpeed <= vehicleSpeed then
                return 0
            end

            local slipRatio =
                (wheelLinearSpeed - vehicleSpeed) / math.max(vehicleSpeed, 1.0)

            if slipRatio <= 0.01 then
                return 0
            end

            return math.clamp(slipRatio * 100, 0, 100)
        end

        return 0
    end

    -- No engine slip sample. A stationary wheel on a moving grounded vehicle
    -- is not automatically 0 %: it represents strong relative motion.
    if axleSpeed ~= nil and math.abs(axleSpeed) < 0.01 then
        if vehicleSpeed >= 0.75 and wheel.physics.hasGroundContact == true then
            return 100
        end
        return 0
    end

    if axleSpeed ~= nil and radius > 0 then
        local wheelLinearSpeed = axleSpeed * radius

        if vehicleSpeed < 0.01 then
            return math.clamp(wheelLinearSpeed * 100, 0, 100)
        end

        if wheelLinearSpeed <= vehicleSpeed then
            return 0
        end

        local slipRatio =
            (wheelLinearSpeed - vehicleSpeed) / math.max(vehicleSpeed, 1.0)

        if slipRatio <= 0.01 then
            return 0
        end

        return math.clamp(slipRatio * 100, 0, 100)
    end

    return nil
end


local function getWheelSlipValue(wheel, vehicle, counterpartValue, rawValue)
    if wheel == nil then
        return nil
    end

    local now = getSlipNow()
    local state = wheelSlipState[wheel]

    if state == nil then
        state = {
            lastValid = nil,
            lastValidTime = nil,
            invalidSince = now
        }
        wheelSlipState[wheel] = state
    end

    -- Use the single raw sample from this update cycle. Do not sample the
    -- physics a second time, otherwise a short state change can be interpreted
    -- as an INVALID transition within the same 10-ms update.
    local raw = rawValue

    if raw ~= nil then
        state.lastValid = raw
        state.lastValidTime = now
        state.invalidSince = nil
        return raw
    end

    if state.invalidSince == nil then
        state.invalidSince = now
    end

    local invalidDuration = now - state.invalidSince

    if state.lastValid ~= nil
        and state.lastValidTime ~= nil
        and invalidDuration < WHEEL_SLIP_HOLD_MS then
        return state.lastValid
    end

    if invalidDuration < WHEEL_SLIP_COUNTERPART_MS
        and counterpartValue ~= nil then
        return counterpartValue
    end

    return nil
end

local function getAverageWheelSlip(wheels, vehicle)
    local wheelList = {}
    for _, wheel in ipairs(wheels or {}) do
        if wheel ~= nil then
            wheelList[#wheelList + 1] = wheel
        end
    end

    if #wheelList == 0 then
        return nil, 0, {}
    end

    -- One physics sample per wheel for the complete aggregation pass.
    local rawValues = {}
    for _, wheel in ipairs(wheelList) do
        rawValues[wheel] = readWheelSlipRaw(wheel, vehicle)
    end

    local sum, count = 0, 0
    local resolvedValues = {}

    for _, wheel in ipairs(wheelList) do
        local counterpartValue = nil
        local counterpartSum, counterpartCount = 0, 0

        for _, otherWheel in ipairs(wheelList) do
            if otherWheel ~= wheel and rawValues[otherWheel] ~= nil then
                counterpartSum = counterpartSum + rawValues[otherWheel]
                counterpartCount = counterpartCount + 1
            end
        end

        if counterpartCount > 0 then
            counterpartValue = counterpartSum / counterpartCount
        end

        local value = getWheelSlipValue(
            wheel,
            vehicle,
            counterpartValue,
            rawValues[wheel]
        )

        resolvedValues[wheel] = value

        -- INVALID values are excluded completely. A measured 0 % is valid.
        if value ~= nil then
            sum = sum + value
            count = count + 1
        end
    end

    if count == 0 then
        return nil, 0, resolvedValues
    end

    return sum / count, count, resolvedValues
end


local function refreshManifestDriveSlip(manifest, vehicle)
    if manifest == nil then
        return
    end

    for _, axle in ipairs(manifest.axleUnits or {}) do
        axle.displaySlipByWheel = axle.displaySlipByWheel or {}

        -- Normal wheels and crawler contact wheels use the same validity
        -- pipeline. A missing value is never converted to 0 here.
        local axleWheels = axle.wheels or {}
        local axleAverage, axleValidCount, axleResolved =
            getAverageWheelSlip(axleWheels, vehicle)

        axle.displaySlipAverage = axleAverage
        axle.displaySlipWheelCount = axleValidCount

        for _, wheel in ipairs(axleWheels) do
            if wheel ~= nil then
                axle.displaySlipByWheel[wheel] = axleResolved[wheel]
            end
        end

        for _, crawlerDriveUnit in ipairs(axle.crawlerDriveUnits or {}) do
            -- Preserve the crawler-side grouping, but use exactly the same
            -- live wheel values and INVALID filtering as conventional axles.
            local slipWheels = crawlerDriveUnit.contactDriveWheels or {}
            local average, validCount, resolved =
                getAverageWheelSlip(slipWheels, vehicle)

            crawlerDriveUnit.driveSlipAverage = average
            crawlerDriveUnit.contactSlipWheelCount = validCount

            local representative = crawlerDriveUnit.representativeDriveWheel
            if representative ~= nil then
                -- Prefer the resolved representative value when it is part of
                -- the contact group; otherwise use the group's valid average.
                local representativeValue = resolved[representative]
                axle.displaySlipByWheel[representative] = representativeValue
                    ~= nil and representativeValue or average
            end
        end
    end
end


local function collectPhysicalAxles(vehicle, tractionOnly)
    local result = {}

    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return result
    end

    local traction = getTractionWheels(vehicle)
    local entries = {}

    for index, wheel in pairs(vehicle.spec_wheels.wheels) do
        if wheel ~= nil and wheel.repr ~= nil then
            local wheelKey = getWheelIndexKey(wheel, index)
            if not tractionOnly or traction[wheelKey] then
                local ok, _, _, z = pcall(getTranslation, wheel.repr)
                if ok and z ~= nil then
                    table.insert(entries, {
                        wheel = wheel,
                        wheelIndex = wheelKey,
                        z = z
                    })
                end
            end
        end
    end

    -- A physical axle is a left/right pair at the same longitudinal position.
    -- GIANTS' WheelAxle explicitly connects two wheels of an axle. Where the
    -- runtime exposes wheelAxles we use those authoritative pairs first.
    local used = {}

    local wheelAxles = vehicle.wheelAxles
    if wheelAxles == nil and vehicle.spec_wheels ~= nil then
        wheelAxles = vehicle.spec_wheels.wheelAxles
    end

    -- Crawler reference wheels may also be present in GIANTS wheelAxles.
    -- They are already represented by the crawler structure and must not
    -- become an additional conventional HUD axle.
    local crawlerWheelKeys = {}
    local crawlerSpec = vehicle.spec_crawlers
    if crawlerSpec ~= nil and crawlerSpec.crawlers ~= nil then
        for _, crawler in ipairs(crawlerSpec.crawlers) do
            for _, entry in ipairs(crawler.wheels or {}) do
                local wheel = entry ~= nil and entry.wheel or nil
                local key = getWheelIndexKey(wheel, nil)
                if key ~= nil then
                    crawlerWheelKeys[key] = true
                end
            end
        end
    end

    if wheelAxles ~= nil then
        for _, axle in pairs(wheelAxles) do
            local w1 = axle.wheel1
            local w2 = axle.wheel2
            if w1 ~= nil and w2 ~= nil then
                local k1 = getWheelIndexKey(w1, nil)
                local k2 = getWheelIndexKey(w2, nil)
                local containsCrawlerWheel =
                    (k1 ~= nil and crawlerWheelKeys[k1] == true)
                    or (k2 ~= nil and crawlerWheelKeys[k2] == true)

                local include = not containsCrawlerWheel
                if include and tractionOnly then
                    include = traction[k1] or traction[k2] or false
                end

                if include then
                    table.insert(result, {wheels = {w1, w2}, z = 0})
                    if k1 ~= nil then
                        used[k1] = true
                    end
                    if k2 ~= nil then
                        used[k2] = true
                    end
                end
            end
        end
    end

    -- Fallback/extension for wheels without an explicit WheelAxle object.
    for _, entry in ipairs(entries) do
        if not used[entry.wheelIndex] then
            local group = nil
            for _, axle in ipairs(result) do
                if math.abs(entry.z - axle.z) <= 0.05 then
                    group = axle
                    break
                end
            end

            if group == nil then
                group = {wheels = {}, z = entry.z}
                table.insert(result, group)
            end

            table.insert(group.wheels, entry.wheel)
            local sumZ = 0
            for _, w in ipairs(group.wheels) do
                local ok, _, _, wz = pcall(getTranslation, w.repr)
                if ok and wz ~= nil then
                    sumZ = sumZ + wz
                end
            end
            if #group.wheels > 0 then
                group.z = sumZ / #group.wheels
            end
        end
    end

    table.sort(result, function(a, b)
        return a.z > b.z
    end)

    return result
end

local function getSlipStartupEndTime(vehicle)
    if vehicle == nil then
        return nil
    end

    local spec = vehicle.spec_motorized
    if spec == nil then
        return nil
    end

    -- motorStartDuration is the vehicle-specific startup duration. GIANTS
    -- converts that duration into the absolute motorStartTime when the motor
    -- start begins. Therefore motorStartTime is the END of that duration.
    -- Keep the duration concept in the startup gate, but never add it to the
    -- already absolute motorStartTime.
    local duration = tonumber(spec.motorStartDuration) or 0
    local motorStartTime = tonumber(spec.motorStartTime)

    if motorStartTime ~= nil and motorStartTime > 0 then
        -- Sanity check: if duration is available, the implied start timestamp
        -- is motorStartTime - duration. The end timestamp itself remains
        -- motorStartTime. This preserves the complete vehicle-specific
        -- initialization/startup window without double-counting it.
        if duration > 0 then
            local startTimestamp = motorStartTime - duration
            if startTimestamp >= 0 then
                return startTimestamp + duration
            end
        end
        return motorStartTime
    end

    return nil
end

local function isSlipStartupBlocked(vehicle)
    if vehicle == nil then
        return true
    end

    local startupEndTime = getSlipStartupEndTime(vehicle)
    if startupEndTime ~= nil then
        local now = g_currentMission ~= nil and g_currentMission.time or 0
        return now < startupEndTime
    end

    return false
end

local collectSlipAxleUnits
local resolvePhysicalAxlesFromManifest
local getCachedChassisManifest

local function buildCrawlerAxleGroups(vehicle, crawlerUnits, tractionOnly)
    local result = {}
    local units = crawlerUnits or {}
    if #units == 0 then
        return result
    end

    local traction = getTractionWheels(vehicle)

    local function collectWheels(unit)
        local wheels, seen = {}, {}
        for _, entry in ipairs(unit.wheels or {}) do
            local w = entry.wheel or entry
            if w ~= nil and not seen[w] then
                seen[w] = true
                wheels[#wheels + 1] = w
            end
        end
        return wheels
    end

    local function normalizeCrawlerUnit(unit)
        local sourceWheels = collectWheels(unit)
        local driveWheels = {}

        for _, wheel in ipairs(sourceWheels) do
            local key = getWheelIndexKey(wheel, nil)
            if key ~= nil and traction[key] == true then
                driveWheels[#driveWheels + 1] = wheel
            end
        end

        local contactDriveWheels = {}
        for _, wheel in ipairs(driveWheels) do
            local hasContact = false
            if wheel ~= nil and wheel.physics ~= nil then
                local contact = wheel.physics.contact
                if contact ~= nil then
                    if WheelContactType ~= nil and WheelContactType.NONE ~= nil then
                        hasContact = contact ~= WheelContactType.NONE
                    else
                        hasContact = contact ~= 0
                    end
                end
            end

            if hasContact then
                contactDriveWheels[#contactDriveWheels + 1] = wheel
            end
        end

        local representativeDriveWheel = driveWheels[1]
        return {
            sourceWheels = sourceWheels,
            driveWheels = driveWheels,
            contactDriveWheels = contactDriveWheels,
            representativeDriveWheel = representativeDriveWheel,
            wheelCount = #sourceWheels,
            driveWheelCount = #driveWheels,
            contactDriveWheelCount = #contactDriveWheels
        }
    end

    local function makeAxle(unitA, unitB, kind)
        local a = unitA ~= nil and normalizeCrawlerUnit(unitA) or
            {sourceWheels={}, driveWheels={}, representativeDriveWheel=nil}
        local b = unitB ~= nil and normalizeCrawlerUnit(unitB) or
            {sourceWheels={}, driveWheels={}, representativeDriveWheel=nil}

        local axle = {
            kind = kind or "CRAWLER_PAIR",
            z = ((tonumber(unitA and unitA.z) or 0) + (tonumber(unitB and unitB.z) or 0)) * 0.5,
            crawlerUnits = {},
            crawlerDriveUnits = {},
            sourceWheels = {},
            driveWheels = {},
            contactDriveWheels = {},
            representativeDriveWheels = {},
            wheels = {},
            displaySlipByWheel = {},
            driven = false
        }

        local function append(unit, normalized)
            if unit ~= nil then
                axle.crawlerUnits[#axle.crawlerUnits + 1] = unit
            end
            axle.crawlerDriveUnits[#axle.crawlerDriveUnits + 1] = normalized

            for _, wheel in ipairs(normalized.sourceWheels or {}) do
                axle.sourceWheels[#axle.sourceWheels + 1] = wheel
            end

            for _, wheel in ipairs(normalized.contactDriveWheels or {}) do
                axle.contactDriveWheels[#axle.contactDriveWheels + 1] = wheel
            end

            -- Exactly ONE visible L/R representative per physical crawler/track.
            local representative = normalized.representativeDriveWheel
            if representative ~= nil then
                axle.representativeDriveWheels[#axle.representativeDriveWheels + 1] = representative
                axle.driveWheels[#axle.driveWheels + 1] = representative
                axle.wheels[#axle.wheels + 1] = representative
            end
        end

        append(unitA, a)
        append(unitB, b)

        axle.driven = #axle.representativeDriveWheels > 0
        if tractionOnly and not axle.driven then
            return nil
        end
        return axle
    end

    -- Crawler units are physical running-gear sides, not individual axles.
    -- Pair opposite sides by their longitudinal position. This means:
    --   2 crawler units at one position -> 1 physical crawler axle (L/R)
    --   4 crawler units at two positions -> 2 physical crawler axles
    -- Internal crawler wheels remain fully stored in each paired unit.
    local left, right = {}, {}
    for _, unit in ipairs(units) do
        if unit.side == "LEFT" then left[#left + 1] = unit
        else right[#right + 1] = unit end
    end

    local function byZ(a,b)
        local az, bz = tonumber(a.z) or 0, tonumber(b.z) or 0
        if math.abs(az-bz) > 0.0001 then return az > bz end
        return tostring(a.id or "") < tostring(b.id or "")
    end
    table.sort(left,byZ)
    table.sort(right,byZ)

    local usedRight = {}
    for _, l in ipairs(left) do
        local best,bestD=nil,math.huge
        for j,r in ipairs(right) do
            if not usedRight[j] then
                local d=math.abs((tonumber(l.z) or 0)-(tonumber(r.z) or 0))
                if d < bestD then bestD=d; best=j end
            end
        end
        if best ~= nil then
            local r=right[best]
            usedRight[best]=true
            local axle=makeAxle(l,r,"CRAWLER_PAIR")
            if axle ~= nil then result[#result+1]=axle end
        end
    end

    for j,r in ipairs(right) do
        if not usedRight[j] then
            local axle=makeAxle(r,nil,"CRAWLER_SINGLE")
            if axle ~= nil then result[#result+1]=axle end
        end
    end

    table.sort(result,function(a,b)
        return (tonumber(a.z) or 0) > (tonumber(b.z) or 0)
    end)
    return result
end

local function calculateAxleSlip(vehicle, resolvedAxles)
    local result = {front = 0, rear = 0, axles = {}, axleCount = 0}
    if vehicle == nil or vehicle.spec_wheels == nil then
        return result
    end

    -- Consume only the already resolved physical-axle snapshot.
    local axles = resolvedAxles or {}
    local axleCount = math.min(#axles, 6)
    result.axleCount = axleCount

    for axleIndex = 1, axleCount do
        local axle = axles[axleIndex]
        local slipWheels = axle.representativeDriveWheels or axle.wheels or {}
        local average = getAverageWheelSlip(slipWheels, vehicle)
        result.axles[axleIndex] = average
    end

    result.front = result.axles[1]
    result.rear = axleCount > 1 and result.axles[axleCount] or result.front
    return result
end

-- Recognition is kept separate from the displayed labels. This records all
-- physical wheel/crawler/axle information first; the label decision is made
-- only afterwards.

local function getCrawlerWheelSet(vehicle)
    local crawlerWheelSet = {}
    local crawlerWheelRefs = {}
    local crawlerWheelNodeRefs = {}
    local crawlerSpec = vehicle ~= nil and vehicle.spec_crawlers or nil

    if crawlerSpec == nil or crawlerSpec.crawlers == nil then
        return crawlerWheelSet, crawlerWheelRefs, crawlerWheelNodeRefs
    end

    for crawlerIndex, crawler in ipairs(crawlerSpec.crawlers) do
        -- GIANTS may expose resolved wheel objects in crawler.wheels.
        if crawler.wheels ~= nil then
            for _, wheelData in pairs(crawler.wheels) do
                -- GIANTS stores crawler.wheels as entries containing the
                -- actual wheel in entry.wheel. crawler.wheel is only the
                -- single reference wheel and must never represent the whole
                -- crawler as an axle by itself.
                local wheel = wheelData ~= nil and wheelData.wheel or nil
                if wheel ~= nil then
                    crawlerWheelSet[wheel] = true

                    if wheel.wheelIndex ~= nil then
                        crawlerWheelSet[wheel.wheelIndex] = true
                    end

                    if wheel.repr ~= nil then
                        crawlerWheelRefs[wheel.repr] = true
                    end

                    if wheel.driveNode ~= nil then
                        crawlerWheelRefs[wheel.driveNode] = true
                    end

                    if wheel.linkNode ~= nil then
                        crawlerWheelRefs[wheel.linkNode] = true
                    end
                end
            end
        end

        if crawler.wheelIndices ~= nil then
            for _, wheelIndex in pairs(crawler.wheelIndices) do
                crawlerWheelSet[wheelIndex] = true
            end
        end

        -- Preserve the original crawler wheel-node references as a second
        -- source of truth for crawler membership.
        if crawler.wheelNodes ~= nil then
            for _, node in pairs(crawler.wheelNodes) do
                if node ~= nil then
                    crawlerWheelNodeRefs[node] = true
                end
            end
        end
    end

    return crawlerWheelSet, crawlerWheelRefs, crawlerWheelNodeRefs
end

local function wheelMatchesCrawlerReference(wheel, crawlerWheelSet, crawlerWheelRefs, crawlerWheelNodeRefs)
    if wheel == nil then
        return false
    end

    if crawlerWheelSet[wheel]
        or (wheel.wheelIndex ~= nil and crawlerWheelSet[wheel.wheelIndex]) then
        return true
    end

    if wheel.repr ~= nil and (crawlerWheelRefs[wheel.repr] or crawlerWheelNodeRefs[wheel.repr]) then
        return true
    end

    if wheel.driveNode ~= nil and (crawlerWheelRefs[wheel.driveNode] or crawlerWheelNodeRefs[wheel.driveNode]) then
        return true
    end

    if wheel.linkNode ~= nil and (crawlerWheelRefs[wheel.linkNode] or crawlerWheelNodeRefs[wheel.linkNode]) then
        return true
    end

    return false
end

local function isWheelCrawlerType(wheel)
    if wheel == nil or WheelsUtil == nil or WheelsUtil.getTireType == nil then
        return false
    end

    local crawlerTireType = WheelsUtil.getTireType("crawler")
    return crawlerTireType ~= nil and wheel.tireType == crawlerTireType
end

local function getCrawlerWheelMembers(vehicle, crawler, allWheels)
    local members = {}
    local seen = {}

    local function addWheel(wheel)
        if wheel ~= nil and not seen[wheel] then
            seen[wheel] = true
            members[#members + 1] = wheel
        end
    end

    -- 1) Use all crawler wheel objects explicitly exposed by GIANTS.
    if crawler ~= nil and crawler.wheels ~= nil then
        for _, wheelData in pairs(crawler.wheels) do
            local wheel = wheelData ~= nil and wheelData.wheel or nil
            if wheel ~= nil then
                addWheel(wheel)
            end
        end
    end

    -- 2) Use explicit wheelNodes when the runtime exposes them.
    if crawler ~= nil and crawler.wheelNodes ~= nil then
        for _, node in pairs(crawler.wheelNodes) do
            if node ~= nil then
                for _, wheel in pairs(allWheels or {}) do
                    if wheel ~= nil
                        and (wheel.repr == node
                            or wheel.driveNode == node
                            or wheel.linkNode == node) then
                        addWheel(wheel)
                    end
                end
            end
        end
    end

    -- 3) If GIANTS exposes only a single reference wheel and no wheelNodes/
    -- wheelIndices, recover the remaining physical crawler wheels from the
    -- wheel-index sequence belonging to that crawler side.
    --
    -- This is structural: it uses the runtime crawler reference wheel,
    -- crawler.isLeft and the contiguous wheel-index block. No vehicle name,
    -- filename or model-specific assignment is used.
    local explicitMemberCount = #members
    local hasExplicitNodeMap = crawler ~= nil
        and (crawler.wheelNodes ~= nil or crawler.wheelIndices ~= nil)

    if explicitMemberCount == 1 and not hasExplicitNodeMap then
        local referenceWheel = members[1]
        local referenceIndex = referenceWheel ~= nil and referenceWheel.wheelIndex or nil

        if referenceIndex ~= nil then
            local sideSign = nil
            if crawler ~= nil and crawler.linkNode ~= nil
                and vehicle ~= nil and vehicle.rootNode ~= nil then
                local ok, x = pcall(localToLocal, crawler.linkNode, vehicle.rootNode, 0, 0, 0)
                if ok and x ~= nil and math.abs(x) > 0.02 then
                    sideSign = x < 0 and -1 or 1
                end
            end

            if sideSign == nil then
                -- Only a defensive fallback; resolveCrawlerSide remains the
                -- authoritative semantic side when geometry is unavailable.
                local semanticSide = crawler ~= nil and crawler.isLeft == true
                    and "LEFT" or "RIGHT"
                sideSign = semanticSide == "LEFT" and -1 or 1
            end

            local function isSameCrawlerSide(wheel)
                if wheel == nil or wheel.repr == nil then
                    return false
                end

                local ok, x = pcall(function()
                    local rootNode = vehicle ~= nil and vehicle.rootNode or nil
                    if rootNode == nil then
                        return nil
                    end
                    local lx = localToLocal(wheel.repr, rootNode, 0, 0, 0)
                    return lx
                end)

                return ok and x ~= nil and x * sideSign > 0.02
            end

            -- GIANTS wheel indices are stable within the loaded vehicle
            -- wheel table. Start at the crawler reference and continue
            -- through the contiguous wheel block on the same physical side.
            local nextIndex = referenceIndex + 1
            while allWheels[nextIndex] ~= nil do
                local candidate = allWheels[nextIndex]

                if not isSameCrawlerSide(candidate) then
                    break
                end

                addWheel(candidate)
                nextIndex = nextIndex + 1
            end
        end
    end

    -- 4) Last-resort geometric supplement for runtimes where the crawler
    -- object exposes no usable wheel sequence at all. This is intentionally
    -- only entered when no structural recovery above added anything.
    if #members == explicitMemberCount and explicitMemberCount == 0 then
        local sideIsLeft = crawler ~= nil and crawler.isLeft == true
        local sideSign = sideIsLeft and -1 or 1
        local candidates = {}

        for _, wheel in pairs(allWheels or {}) do
            if wheel ~= nil and wheel.repr ~= nil and isWheelCrawlerType(wheel) then
                local ok, x, _, z = pcall(getTranslation, wheel.repr)
                if ok and x ~= nil and z ~= nil and x * sideSign > 0.02 then
                    candidates[#candidates + 1] = {wheel=wheel, z=z}
                end
            end
        end

        table.sort(candidates, function(a,b)
            return (tonumber(a.z) or 0) > (tonumber(b.z) or 0)
        end)

        for _, candidate in ipairs(candidates) do
            addWheel(candidate.wheel)
        end
    end

    return members
end

local function resolveCrawlerSide(crawler, members, vehicle)
    -- GIANTS exposes crawler.isLeft specifically as the crawler side. This is
    -- the authoritative source and must not be overwritten by wheel geometry.
    if crawler ~= nil and crawler.isLeft ~= nil then
        return crawler.isLeft == true and "LEFT" or "RIGHT"
    end

    -- Defensive fallback only for a malformed/custom runtime object that does
    -- not expose isLeft at all.
    local rootNode = vehicle ~= nil and vehicle.rootNode or nil
    local negativeX, positiveX = 0, 0
    if rootNode ~= nil then
        for _, wheel in ipairs(members or {}) do
            local node = wheel ~= nil and (wheel.repr or wheel.driveNode or wheel.linkNode) or nil
            if node ~= nil then
                local ok, x = pcall(localToLocal, node, rootNode, 0, 0, 0)
                if ok and x ~= nil then
                    if x < -0.02 then negativeX = negativeX + 1
                    elseif x > 0.02 then positiveX = positiveX + 1 end
                end
            end
        end
    end
    if negativeX > positiveX and negativeX > 0 then return "LEFT" end
    if positiveX > negativeX and positiveX > 0 then return "RIGHT" end
    return "RIGHT"
end


local function collectAllChassisUnits(vehicle)
    local manifest = {
        units = {},
        crawlerUnits = {},
        wheelUnits = {},
        totalUnits = 0,
        crawlerCount = 0,
        wheelUnitCount = 0,
        normalWheelCount = 0
    }

    if vehicle == nil
        or vehicle.spec_wheels == nil
        or vehicle.spec_wheels.wheels == nil then
        return manifest
    end

    local allWheels = vehicle.spec_wheels.wheels
    local crawlerSpec = vehicle.spec_crawlers
    local crawlerWheelSet, crawlerWheelRefs, crawlerWheelNodeRefs =
        getCrawlerWheelSet(vehicle)

    local assignedCrawlerWheels = {}

    -- ================================================================
    -- PHASE 1A: DECLARE ALL CRAWLER UNITS AND RESOLVE ALL OF THEIR
    -- INTERNAL WHEELS BEFORE LOOKING FOR NORMAL WHEEL UNITS.
    -- ================================================================
    if crawlerSpec ~= nil and crawlerSpec.crawlers ~= nil then
        for crawlerIndex, crawler in ipairs(crawlerSpec.crawlers) do
            local members = getCrawlerWheelMembers(vehicle, crawler, allWheels)

            local crawlerZSum = 0
            local crawlerZCount = 0
            for _, wheel in ipairs(members) do
                if wheel ~= nil and wheel.repr ~= nil then
                    local ok, _, _, z = pcall(getTranslation, wheel.repr)
                    if ok and z ~= nil then
                        crawlerZSum = crawlerZSum + z
                        crawlerZCount = crawlerZCount + 1
                    end
                end
            end

            -- Use the GIANTS crawler object itself as the geometry source.
            -- linkNode is the position of the crawler unit; internal crawler
            -- wheels are never used to decide whether the two side units form
            -- one physical axle.
            local crawlerX, crawlerZ = nil, nil
            if crawler ~= nil and crawler.linkNode ~= nil and vehicle.rootNode ~= nil then
                local ok, x, _, z = pcall(localToLocal, crawler.linkNode, vehicle.rootNode, 0, 0, 0)
                if ok and x ~= nil and z ~= nil then
                    crawlerX, crawlerZ = x, z
                end
            end

            local side
            if crawlerX ~= nil and math.abs(crawlerX) > 0.02 then
                side = crawlerX < 0 and "LEFT" or "RIGHT"
            else
                side = resolveCrawlerSide(crawler, members, vehicle)
            end

            local unit = {
                id = "CRAWLER_" .. tostring(crawlerIndex),
                kind = "CRAWLER",
                index = crawlerIndex,
                side = side,
                crawler = crawler,
                wheels = members,
                wheelCount = #members,
                z = crawlerZ ~= nil and crawlerZ
                    or (crawlerZCount > 0 and (crawlerZSum / crawlerZCount) or 0)
            }

            for _, wheel in ipairs(members) do
                assignedCrawlerWheels[wheel] = true

                if wheel.wheelIndex ~= nil then
                    assignedCrawlerWheels[wheel.wheelIndex] = true
                end
            end

            table.insert(manifest.crawlerUnits, unit)
            table.insert(manifest.units, unit)
        end

        -- crawler.isLeft remains authoritative for every runtime crawler.
        -- No post-processing may rewrite the side from wheel geometry.
end

    -- ================================================================
    -- PHASE 1B: ONLY AFTER EVERY CRAWLER UNIT IS COMPLETE, scan all
    -- remaining spec_wheels.wheels for genuine normal wheel units.
    -- ================================================================
    local normalEntries = {}

    for index, wheel in pairs(allWheels) do
        local isCrawlerWheel = assignedCrawlerWheels[wheel]
            or assignedCrawlerWheels[index]

        if not isCrawlerWheel and wheel ~= nil and wheel.wheelIndex ~= nil then
            isCrawlerWheel = assignedCrawlerWheels[wheel.wheelIndex]
        end

        -- Existing crawler tireType remains a fallback, but only for a
        -- wheel not already assigned to a crawler by explicit membership.
        if not isCrawlerWheel and isWheelCrawlerType(wheel) then
            isCrawlerWheel = true
        end

        if not isCrawlerWheel and wheel ~= nil and wheel.repr ~= nil then
            local ok, _, _, z = pcall(getTranslation, wheel.repr)

            if ok and z ~= nil then
                table.insert(normalEntries, {
                    wheel = wheel,
                    index = index,
                    z = z
                })
            end
        end
    end

    -- Group genuine normal wheels by physical longitudinal position.
    table.sort(normalEntries, function(a, b)
        return a.z > b.z
    end)

    for _, entry in ipairs(normalEntries) do
        local unit = nil

        for _, candidate in ipairs(manifest.wheelUnits) do
            if math.abs(entry.z - candidate.z) <= 0.05 then
                unit = candidate
                break
            end
        end

        if unit == nil then
            unit = {
                id = "WHEEL_" .. tostring(#manifest.wheelUnits + 1),
                kind = "WHEEL",
                wheels = {},
                wheelCount = 0,
                z = entry.z
            }

            table.insert(manifest.wheelUnits, unit)
            table.insert(manifest.units, unit)
        end

        table.insert(unit.wheels, entry.wheel)
        unit.wheelCount = #unit.wheels

        local sum, count = 0, 0
        for _, wheel in ipairs(unit.wheels) do
            local ok, _, _, z = pcall(getTranslation, wheel.repr)

            if ok and z ~= nil then
                sum = sum + z
                count = count + 1
            end
        end

        if count > 0 then
            unit.z = sum / count
        end
    end

    -- ================================================================
    -- PHASE 1C: COMPLETE MANIFEST COUNTS. Nothing above this point
    -- makes an L/R or V/H decision.
    -- ================================================================
    manifest.totalUnits = #manifest.units
    manifest.crawlerCount = #manifest.crawlerUnits
    manifest.wheelUnitCount = #manifest.wheelUnits

    for _, unit in ipairs(manifest.wheelUnits) do
        manifest.normalWheelCount =
            manifest.normalWheelCount + unit.wheelCount
    end

    return manifest
end

-- Cache the static running-gear structure. A new vehicle must produce the
-- same complete manifest four consecutive times before it is accepted as
-- stable. After that, the manifest is reused until the vehicle object changes.
local chassisStructureCache = setmetatable({}, {__mode = "k"})
local tractionStructureCache = setmetatable({}, {__mode = "k"})

local function buildChassisManifestSignature(manifest)
    local units = {}

    for _, unit in ipairs(manifest.units or {}) do
        local wheels = {}
        for _, wheel in ipairs(unit.wheels or {}) do
            local index = wheel ~= nil and wheel.wheelIndex or nil
            local repr = wheel ~= nil and wheel.repr or nil
            local driveNode = wheel ~= nil and wheel.driveNode or nil
            local linkNode = wheel ~= nil and wheel.linkNode or nil
            table.insert(wheels, table.concat({
                tostring(index or "-"),
                tostring(repr or "-"),
                tostring(driveNode or "-"),
                tostring(linkNode or "-")
            }, ":"))
        end
        table.sort(wheels)

        table.insert(units, table.concat({
            tostring(unit.kind or "-"),
            tostring(unit.side or "-"),
            string.format("%.4f", tonumber(unit.z or 0)),
            table.concat(wheels, ",")
        }, "|"))
    end

    table.sort(units)
    local axleSignature = {}
    for _, axle in ipairs(manifest.axleUnits or {}) do
        local wheelKeys = {}
        for _, wheel in ipairs(axle.wheels or {}) do
            table.insert(wheelKeys, tostring(getWheelIndexKey(wheel, nil) or "?"))
        end
        table.sort(wheelKeys)
        table.insert(axleSignature, table.concat({
            tostring(axle.kind or "?"),
            string.format("%.5f", tonumber(axle.z) or 0),
            table.concat(wheelKeys, ",")
        }, ":"))
    end

    return table.concat({
        tostring(manifest.totalUnits or 0),
        tostring(manifest.crawlerCount or 0),
        tostring(manifest.wheelUnitCount or 0),
        tostring(manifest.normalWheelCount or 0),
        tostring(manifest.axleCount or 0),
        table.concat(units, ";"),
        table.concat(axleSignature, ";")
    }, "#")
end

getCachedChassisManifest = function(vehicle)
    local cache = chassisStructureCache[vehicle]
    if cache ~= nil and cache.stable then
        return cache.manifest
    end

    local manifest = collectAllChassisUnits(vehicle)

    -- The manifest contains two deliberately separate layers:
    --   units     = technical chassis sub-units (e.g. crawler LEFT/RIGHT)
    --   axleUnits = normalized physical axles used by the HUD
    -- The second layer is resolved once from the first and becomes the
    -- authoritative axle structure for all later HUD stages.
    manifest.axleUnits = resolvePhysicalAxlesFromManifest(vehicle, manifest, true)

    -- Final normalization boundary: remove empty axles and duplicate wheel
    -- membership. From here onward this is the only physical-axle structure.
    local normalizedAxles, seenWheels, seenPhysicalWheels = {}, {}, {}

    local function getPhysicalWheelIdentity(wheel)
        if wheel == nil then
            return nil
        end

        -- wheelIndex is GIANTS' physical wheel identifier and is preferred
        -- over Lua table identity. Some special vehicles expose two runtime
        -- wheel table entries/wheelAxle references for the same physical
        -- driven wheel. Those aliases must produce exactly one HUD wheel.
        local wheelIndex = getWheelIndexKey(wheel, nil)
        if wheelIndex ~= nil then
            return "INDEX:" .. tostring(wheelIndex)
        end

        local physics = wheel.physics
        if physics ~= nil and physics.wheelShape ~= nil then
            return "SHAPE:" .. tostring(physics.wheelShape)
        end

        if wheel.repr ~= nil then
            return "REPR:" .. tostring(wheel.repr)
        end

        return nil
    end

    for _, axle in ipairs(manifest.axleUnits or {}) do
        local uniqueWheels = {}
        for _, wheel in ipairs(axle.wheels or {}) do
            local physicalKey = getPhysicalWheelIdentity(wheel)
            local alreadySeen = wheel ~= nil and seenWheels[wheel] == true
            if not alreadySeen and physicalKey ~= nil then
                alreadySeen = seenPhysicalWheels[physicalKey] == true
            end

            if wheel ~= nil and not alreadySeen then
                seenWheels[wheel] = true
                if physicalKey ~= nil then
                    seenPhysicalWheels[physicalKey] = true
                end
                uniqueWheels[#uniqueWheels + 1] = wheel
            end
        end
        if #uniqueWheels > 0 then
            axle.wheels = uniqueWheels
            normalizedAxles[#normalizedAxles + 1] = axle
        end
    end
    table.sort(normalizedAxles, function(a,b)
        return (tonumber(a.z) or 0) > (tonumber(b.z) or 0)
    end)
    manifest.axleUnits = normalizedAxles
    manifest.axleCount = #normalizedAxles

    -- Diagnostic only: inspect the four-wheel/two-WheelAxle runtime case.
    dumpMacDonDriveDiagnostic(vehicle, manifest, getTractionWheels(vehicle))

    -- ================================================================
    -- VERSION B: PHYSICAL FAHRWERK REFERENCE
    --
    -- A1.1.0.1 remains the complete and authoritative recognition.
    -- B only groups the already resolved A axle units into one physical
    -- running-gear reference. No wheel/crawler detection is repeated.
    -- ================================================================
    manifest.referenceUnits = {}

    local reference = {
        index = 1,
        id = "REF_FAHWERK_1",
        kind = "PHYSICAL_FAHWERK",
        sourceAxles = {},
        wheels = {},
        representativeDriveWheels = {},
        displaySlipByWheel = {},
        componentCount = 0
    }

    local seenAll = {}
    local seenDrive = {}

    for _, axle in ipairs(manifest.axleUnits or {}) do
        reference.sourceAxles[#reference.sourceAxles + 1] = axle

        for _, wheel in ipairs(axle.wheels or {}) do
            if wheel ~= nil and not seenAll[wheel] then
                seenAll[wheel] = true
                reference.wheels[#reference.wheels + 1] = wheel
            end
        end

        local driveWheels = axle.representativeDriveWheels
            or axle.wheels
            or {}

        for _, wheel in ipairs(driveWheels) do
            if wheel ~= nil and not seenDrive[wheel] then
                seenDrive[wheel] = true
                reference.representativeDriveWheels[#reference.representativeDriveWheels + 1] = wheel
            end
        end

        for wheel, value in pairs(axle.displaySlipByWheel or {}) do
            if wheel ~= nil then
                reference.displaySlipByWheel[wheel] = value
            end
        end
    end

    reference.componentCount = #reference.wheels
    manifest.referenceUnits[1] = reference
    manifest.referenceCount = 1

    -- B display references are derived exclusively from the completed A
    -- axleUnits. The normal case stays one-to-one. The structural Leitwolf
    -- pattern (two WHEEL_PLANE units followed by one CRAWLER_PAIR) is the
    -- only case where the two wheel planes represent one physical running
    -- gear for presentation. No vehicle name is inspected.
    local displayReferenceUnits = {}
    local axleUnits = manifest.axleUnits or {}
    local isTwoWheelPlanesPlusCrawler = #axleUnits == 3
        and axleUnits[1] ~= nil and axleUnits[1].kind == "WHEEL_PLANE"
        and axleUnits[2] ~= nil and axleUnits[2].kind == "WHEEL_PLANE"
        and axleUnits[3] ~= nil and axleUnits[3].kind == "CRAWLER_PAIR"

    if isTwoWheelPlanesPlusCrawler then
        local combined = {
            index = 1,
            id = "REF_FAHWERK_1",
            kind = "WHEEL_PLANE_PAIR",
            sourceAxles = {axleUnits[1], axleUnits[2]},
            wheels = {},
            representativeDriveWheels = {},
            displaySlipByWheel = {},
            componentCount = 0
        }
        local seen = {}
        local leftCandidate, rightCandidate
        for sourceIndex = 1, 2 do
            local axle = axleUnits[sourceIndex]
            for _, wheel in ipairs(axle.wheels or {}) do
                if wheel ~= nil and not seen[wheel] then
                    seen[wheel] = true
                    combined.wheels[#combined.wheels + 1] = wheel
                    if wheel.repr ~= nil then
                        local ok, x = pcall(getTranslation, wheel.repr)
                        if ok and x ~= nil then
                            if x < 0 and leftCandidate == nil then
                                leftCandidate = wheel
                            elseif x > 0 and rightCandidate == nil then
                                rightCandidate = wheel
                            end
                        end
                    end
                end
            end
            for wheel, value in pairs(axle.displaySlipByWheel or {}) do
                combined.displaySlipByWheel[wheel] = value
            end
        end
        combined.componentCount = #combined.wheels
        if leftCandidate ~= nil then
            combined.representativeDriveWheels[#combined.representativeDriveWheels + 1] = leftCandidate
        end
        if rightCandidate ~= nil then
            combined.representativeDriveWheels[#combined.representativeDriveWheels + 1] = rightCandidate
        end
        displayReferenceUnits[#displayReferenceUnits + 1] = combined

        local crawler = axleUnits[3]
        displayReferenceUnits[#displayReferenceUnits + 1] = {
            index = 2,
            id = "REF_FAHWERK_2",
            kind = crawler.kind,
            sourceAxles = {crawler},
            wheels = crawler.wheels or {},
            representativeDriveWheels = crawler.representativeDriveWheels or crawler.wheels or {},
            displaySlipByWheel = crawler.displaySlipByWheel or {},
            componentCount = #(crawler.wheels or {})
        }
    else
        -- Generic B behavior: preserve every A physical axle as one display
        -- reference. This keeps 2-wheel tractors, multi-axle vehicles and
        -- four-crawler vehicles aligned with the working A recognition.
        for index, axle in ipairs(axleUnits) do
            displayReferenceUnits[#displayReferenceUnits + 1] = {
                index = index,
                id = "REF_FAHWERK_" .. tostring(index),
                kind = axle.kind,
                sourceAxles = {axle},
                wheels = axle.wheels or {},
                representativeDriveWheels = axle.representativeDriveWheels or axle.wheels or {},
                displaySlipByWheel = axle.displaySlipByWheel or {},
                componentCount = #(axle.wheels or {})
            }
        end
    end

    manifest.displayReferenceUnits = displayReferenceUnits
    manifest.displayReferenceCount = #displayReferenceUnits

    local signature = buildChassisManifestSignature(manifest)

    if cache == nil then
        cache = {stable = false, signature = signature, confirmations = 1, manifest = manifest}
        chassisStructureCache[vehicle] = cache
    elseif cache.signature == signature then
        cache.confirmations = cache.confirmations + 1
        cache.manifest = manifest
    else
        cache.signature = signature
        cache.confirmations = 1
        cache.manifest = manifest
    end

    if cache.confirmations >= LightsSymbolHUD.STRUCTURE_CONFIRMATIONS then
        cache.stable = true
    end

    return cache.manifest
end

local function buildTractionSignature(traction)
    local keys = {}
    for key, value in pairs(traction or {}) do
        if value == true then
            table.insert(keys, tostring(key))
        end
    end
    table.sort(keys)
    return table.concat(keys, ",")
end

local function getCachedTractionWheels(vehicle)
    local cache = tractionStructureCache[vehicle]
    if cache ~= nil and cache.stable then
        return cache.traction
    end

    local traction = getTractionWheels(vehicle)
    local signature = buildTractionSignature(traction)

    if cache == nil then
        cache = {stable = false, signature = signature, confirmations = 1, traction = traction}
        tractionStructureCache[vehicle] = cache
    elseif cache.signature == signature then
        cache.confirmations = cache.confirmations + 1
        cache.traction = traction
    else
        cache.signature = signature
        cache.confirmations = 1
        cache.traction = traction
    end

    if cache.confirmations >= LightsSymbolHUD.STRUCTURE_CONFIRMATIONS then
        cache.stable = true
    end

    return cache.traction
end

-- Build the physical running-gear units used specifically by the displayed
-- slip calculation. The manifest above is authoritative: crawler wheels are
-- already removed from the normal wheel pool. Two side-specific crawler
-- objects at the same longitudinal position form ONE running-gear/axle unit.
resolvePhysicalAxlesFromManifest = function(vehicle, manifest, tractionOnly)
    local result = {}
    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return result
    end

    manifest = manifest or {}
    local crawlerUnits = manifest.crawlerUnits or {}
    local hasCrawler = #crawlerUnits > 0

    -- ================================================================
    -- STEP 1: resolve crawler units once.
    -- GIANTS: one crawler object is one left/right running-gear side.
    -- Its linkNode is the crawler's longitudinal reference. The internal
    -- crawler.wheels are members, not separate physical axles.
    -- ================================================================
    local crawlerObjects, crawlerKeys = {}, {}
    if hasCrawler then
        for _, unit in ipairs(crawlerUnits) do
            for _, entry in ipairs(unit.wheels or {}) do
                local w = entry.wheel or entry
                if w ~= nil then
                    crawlerObjects[w] = true
                    local k = getWheelIndexKey(w, nil)
                    if k ~= nil then crawlerKeys[k] = true end
                end
            end
        end

        local crawlerAxles = buildCrawlerAxleGroups(vehicle, crawlerUnits, tractionOnly)
        for _, axle in ipairs(crawlerAxles) do
            table.insert(result, axle)
        end
    end

    -- ================================================================
    -- STEP 2: collect genuine non-crawler wheels.
    -- A wheel is either a crawler member or a normal wheel. Never both.
    -- ================================================================
    local normal = {}
    for index, wheel in pairs(vehicle.spec_wheels.wheels) do
        if wheel ~= nil and wheel.repr ~= nil then
            local key = getWheelIndexKey(wheel, index)
            local isCrawler = crawlerObjects[wheel]
                or (key ~= nil and crawlerKeys[key])
                or isWheelCrawlerType(wheel)

            if not isCrawler then
                local driven = true
                if tractionOnly then
                    local traction = getTractionWheels(vehicle)
                    driven = key ~= nil and traction[key] == true
                end

                if driven then
                    local ok, x, _, z = pcall(localToLocal, wheel.repr, vehicle.rootNode, 0, 0, 0)
                    if ok and x ~= nil and z ~= nil then
                        table.insert(normal, {
                            wheel = wheel,
                            key = key,
                            x = x,
                            z = z
                        })
                    end
                end
            end
        end
    end

    if #normal == 0 then
        table.sort(result,function(a,b) return (tonumber(a.z) or 0) > (tonumber(b.z) or 0) end)
        return result
    end

    -- ================================================================
    -- STEP 3: use GIANTS WheelAxle as authoritative evidence when it
    -- explicitly connects two non-crawler wheels. WheelAxle itself is
    -- documented by GIANTS as a connection of two wheels.
    -- ================================================================
    local consumed = {}
    local normalByObject = {}
    local normalByKey = {}
    for _, entry in ipairs(normal) do
        normalByObject[entry.wheel] = entry
        if entry.key ~= nil then normalByKey[entry.key] = entry end
    end

    local wheelAxles = vehicle.wheelAxles
    if wheelAxles == nil and vehicle.spec_wheels ~= nil then
        wheelAxles = vehicle.spec_wheels.wheelAxles
    end

    if wheelAxles ~= nil then
        for _, axle in pairs(wheelAxles) do
            local w1, w2 = axle.wheel1, axle.wheel2
            local e1 = normalByObject[w1]
            local e2 = normalByObject[w2]

            if e1 ~= nil and e2 ~= nil then
                local z = (e1.z + e2.z) * 0.5
                table.insert(result, {
                    wheels = {w1, w2},
                    z = z,
                    kind = "WHEEL_AXLE",
                    driven = true
                })
                consumed[e1] = true
                consumed[e2] = true
            end
        end
    end

    -- ================================================================
    -- STEP 4: resolve all remaining normal wheels into physical planes.
    --
    -- No vehicle-specific names are used. We form longitudinal planes
    -- from the actual wheel positions. The tolerance is derived from the
    -- wheel size, not from a JD-specific constant:
    --   tolerance = max(0.08m, 25% of mean wheel radius)
    --
    -- Wheels on the same axle plane are therefore merged; separate
    -- tandem axles remain separate because their longitudinal separation
    -- is normally much larger than the wheel-size-derived tolerance.
    -- ================================================================
    local remaining = {}
    for _, entry in ipairs(normal) do
        if not consumed[entry] then
            table.insert(remaining, entry)
        end
    end

    table.sort(remaining, function(a,b)
        return a.z > b.z
    end)

    local planes = {}
    for _, entry in ipairs(remaining) do
        local best = nil
        local bestDistance = math.huge

        for _, plane in ipairs(planes) do
            local tolerance = math.max(
                0.08,
                0.25 * ((plane.meanRadius or 0.4) + (entry.wheel.physics ~= nil and entry.wheel.physics.radius or plane.meanRadius or 0.4)) * 0.5
            )
            local distance = math.abs(entry.z - plane.z)

            if distance <= tolerance and distance < bestDistance then
                best = plane
                bestDistance = distance
            end
        end

        if best == nil then
            local radius = entry.wheel.physics ~= nil and entry.wheel.physics.radius or 0.4
            best = {
                z = entry.z,
                meanRadius = radius,
                wheels = {}
            }
            table.insert(planes, best)
        end

        table.insert(best.wheels, entry.wheel)
        local count = #best.wheels
        best.z = best.z + (entry.z - best.z) / count
        best.meanRadius = best.meanRadius + (entry.wheel.physics ~= nil and entry.wheel.physics.radius or best.meanRadius) / count
    end

    -- ================================================================
    -- STEP 5: each resolved longitudinal plane is one physical axle.
    -- This is the final normalization boundary: nothing below this point
    -- can create another axle from the same wheel.
    -- ================================================================
    for _, plane in ipairs(planes) do
        table.insert(result, {
            wheels = plane.wheels,
            z = plane.z,
            kind = "WHEEL_PLANE",
            driven = true
        })
    end

    table.sort(result,function(a,b)
        return (tonumber(a.z) or 0) > (tonumber(b.z) or 0)
    end)

    return result
end

collectSlipAxleUnits = function(vehicle, tractionOnly)
    if vehicle == nil then
        return {}
    end

    local manifest = getCachedChassisManifest(vehicle)

    -- The manifest's normalized axleUnits are authoritative. If the caller
    -- requests the same traction-only view used by the HUD, return exactly
    -- that frozen structure. No second grouping is permitted.
    if manifest ~= nil and manifest.axleUnits ~= nil then
        local result = {}
        for _, axle in ipairs(manifest.axleUnits) do
            local wheels = {}
            if not tractionOnly or axle.driven ~= false then
                for _, wheel in ipairs(axle.wheels or {}) do
                    wheels[#wheels + 1] = wheel
                end
                if #wheels > 0 then
                    result[#result + 1] = {
                        wheels = wheels,
                        z = axle.z,
                        kind = axle.kind
                    }
                end
            end
        end
        return result
    end

    return {}
end


local function getSlipWheelEntries(vehicle, axleLimit, resolvedAxles)
    local result = {}
    if vehicle == nil then
        return result
    end

    -- Final renderer-side guard: one physical GIANTS wheel may never create
    -- two slip icons, even if a special vehicle exposes duplicate Lua aliases.
    local displayedPhysicalWheels = {}
    local function getDisplayPhysicalKey(wheel)
        if wheel == nil then return nil end
        local wheelIndex = getWheelIndexKey(wheel, nil)
        if wheelIndex ~= nil then return "INDEX:" .. tostring(wheelIndex) end
        if wheel.physics ~= nil and wheel.physics.wheelShape ~= nil then
            return "SHAPE:" .. tostring(wheel.physics.wheelShape)
        end
        if wheel.repr ~= nil then return "REPR:" .. tostring(wheel.repr) end
        return "OBJECT:" .. tostring(wheel)
    end

    -- When resolvedAxles is supplied, it is the single authoritative snapshot
    -- for this HUD frame. The renderer must never re-run axle detection and
    -- receive a different structure later in the same frame.
    local axles = resolvedAxles or collectSlipAxleUnits(vehicle, true)
    local wheelIndex = 0
    local maxAxles = math.min(tonumber(axleLimit) or 0, #axles)

    for axleIndex = 1, maxAxles do
        local axle = axles[axleIndex]
        local wheels = {}

        for _, wheel in ipairs(axle.wheels or {}) do
            if wheel ~= nil then
                table.insert(wheels, wheel)
            end
        end

        -- Stable left/right ordering: negative local X is left, positive is
        -- right. If X cannot be read, preserve the axle's existing order.
        table.sort(wheels, function(a, b)
            local ax = 0
            local bx = 0
            if a ~= nil and a.repr ~= nil then
                local ok, x = pcall(getTranslation, a.repr)
                if ok and x ~= nil then ax = x end
            end
            if b ~= nil and b.repr ~= nil then
                local ok, x = pcall(getTranslation, b.repr)
                if ok and x ~= nil then bx = x end
            end
            if math.abs(ax - bx) > 0.001 then
                return ax < bx
            end
            return tostring(getWheelIndexKey(a, 0)) < tostring(getWheelIndexKey(b, 0))
        end)

        -- Some narrow single-track vehicles (motorcycles, certain trikes)
        -- model ONE physical centre wheel with TWO GIANTS physics wheels, one
        -- slightly left and one slightly right of the centre line.  Those two
        -- proxies intentionally share the load/drive behaviour of one visible
        -- tyre and must therefore produce only one wheel icon.
        --
        -- Detect that structure geometrically instead of by vehicle name:
        --  * exactly two wheel proxies on this axle
        --  * both very close to the vehicle centre line
        --  * their mean lateral position is centred
        --  * small lateral separation, compatible with one narrow tyre
        --  * essentially identical radius
        local collapseCenterProxyPair = false
        if #wheels == 2 and axle.kind ~= "CRAWLER_PAIR" then
            local w1, w2 = wheels[1], wheels[2]
            local ok1, x1, _, z1 = pcall(localToLocal, w1.repr, vehicle.rootNode, 0, 0, 0)
            local ok2, x2, _, z2 = pcall(localToLocal, w2.repr, vehicle.rootNode, 0, 0, 0)
            if ok1 and ok2 and x1 ~= nil and x2 ~= nil and z1 ~= nil and z2 ~= nil then
                local width1 = (w1.physics ~= nil and tonumber(w1.physics.width)) or 0.15
                local width2 = (w2.physics ~= nil and tonumber(w2.physics.width)) or 0.15
                local radius1 = (w1.physics ~= nil and tonumber(w1.physics.radius)) or 0
                local radius2 = (w2.physics ~= nil and tonumber(w2.physics.radius)) or 0
                local separation = math.abs(x1 - x2)
                local meanX = math.abs((x1 + x2) * 0.5)
                local maxSingleTyreSpan = math.max(0.30, 1.6 * (width1 + width2))

                collapseCenterProxyPair =
                    math.abs(z1 - z2) <= 0.05
                    and math.abs(x1) <= 0.25
                    and math.abs(x2) <= 0.25
                    and meanX <= 0.05
                    and separation <= maxSingleTyreSpan
                    and math.abs(radius1 - radius2) <= 0.05
            end
        end

        if collapseCenterProxyPair then
            local representative = wheels[1]
            local physicalKey1 = getDisplayPhysicalKey(wheels[1])
            local physicalKey2 = getDisplayPhysicalKey(wheels[2])
            if physicalKey1 ~= nil then displayedPhysicalWheels[physicalKey1] = true end
            if physicalKey2 ~= nil then displayedPhysicalWheels[physicalKey2] = true end

            if wheelIndex < LightsSymbolHUD.WHEEL_DISPLAY_MAX then
                wheelIndex = wheelIndex + 1
                local displayPercent = nil
                if axle.displaySlipByWheel ~= nil then
                    local p1 = axle.displaySlipByWheel[wheels[1]]
                    local p2 = axle.displaySlipByWheel[wheels[2]]
                    if p1 ~= nil and p2 ~= nil then
                        displayPercent = (p1 + p2) * 0.5
                    else
                        displayPercent = p1 or p2
                    end
                end

                table.insert(result, {
                    wheel = representative,
                    index = wheelIndex,
                    axleIndex = axleIndex,
                    sideIndex = 1,
                    label = "R" .. tostring(wheelIndex),
                    percent = displayPercent,
                    centerProxyPair = true
                })
            end
        else
            local visibleSideIndex = 0
            for _, wheel in ipairs(wheels) do
                local physicalKey = getDisplayPhysicalKey(wheel)
                if physicalKey == nil or displayedPhysicalWheels[physicalKey] ~= true then
                    if physicalKey ~= nil then
                        displayedPhysicalWheels[physicalKey] = true
                    end
                    visibleSideIndex = visibleSideIndex + 1
                    local sideIndex = visibleSideIndex

                    if wheelIndex < LightsSymbolHUD.WHEEL_DISPLAY_MAX then
                        wheelIndex = wheelIndex + 1
                        local displayPercent = nil
                        if axle.displaySlipByWheel ~= nil then
                            displayPercent = axle.displaySlipByWheel[wheel]
                        end
                        table.insert(result, {
                            wheel = wheel,
                            index = wheelIndex,
                            axleIndex = axleIndex,
                            sideIndex = sideIndex,
                            label = (axle.kind == "CRAWLER_PAIR")
                                and ((sideIndex == 1) and "L" or "R")
                                or ("R" .. tostring(wheelIndex)),
                            percent = displayPercent
                        })
                    end
                end
            end
        end
    end

    return result
end

-- PHASE 2:
-- Evaluate the completed manifest. Still no HUD decision.
local function evaluateChassisManifest(manifest)
    local evaluation = {
        totalUnits = manifest.totalUnits,
        crawlerCount = manifest.crawlerCount,
        wheelUnitCount = manifest.wheelUnitCount,
        normalWheelCount = manifest.normalWheelCount,
        crawlerLeft = 0,
        crawlerRight = 0,
        isPureTwoSidedCrawler = false,
        isMixedCrawlerWheel = false,
        isMultiCrawler = false
    }

    for _, unit in ipairs(manifest.crawlerUnits) do
        if unit.side == "LEFT" then
            evaluation.crawlerLeft = evaluation.crawlerLeft + 1
        else
            evaluation.crawlerRight = evaluation.crawlerRight + 1
        end
    end

    evaluation.isPureTwoSidedCrawler =
        evaluation.totalUnits == 2
        and evaluation.crawlerCount == 2
        and evaluation.crawlerLeft == 1
        and evaluation.crawlerRight == 1
        and evaluation.wheelUnitCount == 0

    evaluation.isMixedCrawlerWheel =
        evaluation.crawlerCount > 0
        and evaluation.wheelUnitCount > 0

    evaluation.isMultiCrawler =
        evaluation.crawlerCount > 2

    return evaluation
end

local function analyzeChassis(vehicle)
    local info = {
        type = "WHEEL",
        layoutType = "WHEEL_ONLY",

        wheelCount = 0,
        tractionWheelCount = 0,

        -- Raw/future multi-axle fields. They are not used for the
        -- basic L/R vs V/H decision.
        axleCount = 0,
        conventionalAxleCount = 0,

        crawlerCount = 0,
        crawlerLeft = 0,
        crawlerRight = 0,

        chassisUnitCount = 0,
        crawlerUnitCount = 0,
        wheelUnitCount = 0,
        normalWheelCount = 0,

        chassisUnits = {},
        chassisEvaluation = nil,

        displayMode = "FRONT_REAR",
        frontLabel = "V",
        rearLabel = "H"
    }

    if vehicle == nil
        or vehicle.spec_wheels == nil
        or vehicle.spec_wheels.wheels == nil then
        return info
    end

    -- ================================================================
    -- PHASE 1: COMPLETE MANIFEST
    -- EVERYTHING belonging to the vehicle's running gear is collected
    -- and declared before ANY classification/decision is made.
    -- ================================================================
    local manifest = getCachedChassisManifest(vehicle)

    info.chassisUnits = manifest.units
    info.chassisUnitCount = manifest.totalUnits
    info.crawlerUnitCount = manifest.crawlerCount
    info.wheelUnitCount = manifest.wheelUnitCount
    info.normalWheelCount = manifest.normalWheelCount

    -- ================================================================
    -- PHASE 2: EVALUATE THE COMPLETED MANIFEST
    -- Count/classify only after the complete vehicle has been scanned.
    -- ================================================================
    local evaluation = evaluateChassisManifest(manifest)
    info.chassisEvaluation = evaluation

    info.crawlerCount = evaluation.crawlerCount
    info.crawlerLeft = evaluation.crawlerLeft
    info.crawlerRight = evaluation.crawlerRight

    -- Keep raw/future axle values separate from the display decision.
    info.conventionalAxleCount = manifest.axleCount or 0
    info.axleCount = manifest.axleCount or 0

    for _, wheel in pairs(vehicle.spec_wheels.wheels) do
        info.wheelCount = info.wheelCount + 1
    end

    local traction = getCachedTractionWheels(vehicle)
    for index, wheel in pairs(vehicle.spec_wheels.wheels) do
        local key = getWheelIndexKey(wheel, index)

        if traction[key] then
            info.tractionWheelCount = info.tractionWheelCount + 1
        end
    end

    -- ================================================================
    -- PHASE 3: FINAL DECISION
    -- Only the COMPLETED manifest/evaluation is allowed here.
    -- ================================================================
    if evaluation.isPureTwoSidedCrawler then
        info.type = "CRAWLER"
        info.layoutType = "CRAWLER_ONLY"
        info.displayMode = "LEFT_RIGHT"
        info.frontLabel = "L"
        info.rearLabel = "R"

    elseif evaluation.isMixedCrawlerWheel then
        info.type = "CRAWLER"
        info.layoutType = "MIXED_CRAWLER_WHEEL"
        info.displayMode = "FRONT_REAR"
        info.frontLabel = "V"
        info.rearLabel = "H"

    elseif evaluation.isMultiCrawler then
        info.type = "CRAWLER"
        info.layoutType = "MULTI_CRAWLER"
        info.displayMode = "FRONT_REAR"
        info.frontLabel = "V"
        info.rearLabel = "H"

    else
        info.type = "WHEEL"
        info.layoutType = "WHEEL_ONLY"
        info.displayMode = "FRONT_REAR"
        info.frontLabel = "V"
        info.rearLabel = "H"
    end

    return info
end

local function updateSlipDisplayLabels(self, vehicle, axleCount)
    local count = math.min(math.max(tonumber(axleCount) or 0, 0), 6)
    if self.slipLabelAxleCount == count and self.slipChassisInfo ~= nil then
        return
    end

    self.slipChassisInfo = analyzeChassis(vehicle)
    self.slipLabelAxleCount = count
    self.slipDisplayLabels = {
        front = self.slipChassisInfo.frontLabel,
        rear = self.slipChassisInfo.rearLabel
    }

    if count > 0 then
        self.slipDisplayLabels.axle1 = count > 2 and "A1" or self.slipChassisInfo.frontLabel
    end
    if count > 1 then
        self.slipDisplayLabels.axle2 = count > 2 and "A2" or self.slipChassisInfo.rearLabel
    end
    for index = 3, count do
        self.slipDisplayLabels["axle" .. tostring(index)] = "A" .. tostring(index)
    end

end


-- ============================================================================
function LightsSymbolHUD:updateStates()
    local vehicle = self.vehicle

    if vehicle == nil or vehicle.spec_lights == nil then
        for _, element in pairs(self.icons) do
            element:setVisible(false)
        end
        for _, element in pairs(self.inactiveIcons) do
            element:setVisible(false)
        end
        return
    end

    local spec = vehicle.spec_lights
    local mask = spec.lightsTypesMask or 0

    local highActive = isMaskActive(mask, Lights.LIGHT_TYPE_HIGHBEAM)
    local lowActive = isMaskActive(mask, Lights.LIGHT_TYPE_DEFAULT)
        and not highActive

    self.active = self.active or {}
    self.active.low = lowActive
    self.active.high = highActive
    -- Work-light state is read directly from the engine light-type bit mask.
    -- This is the authoritative FS25 state for front/rear work lights.
    self.active.workFront =
        bit32.band(mask, 2 ^ Lights.LIGHT_TYPE_WORK_FRONT) ~= 0
    self.active.workBack =
        bit32.band(mask, 2 ^ Lights.LIGHT_TYPE_WORK_BACK) ~= 0
    self.active.beacon = spec.beaconLightsActive == true

    -- Vanilla FS25 turnLightState, as used by the supplied Turn Signal HUD:
    -- 0 = off, 1 = left, 2 = right, 3 = hazard.
    self.blinkerState = spec.turnLightState or 0

    local now = g_currentMission ~= nil and g_currentMission.time or 0
    -- Read the current wheel-slip physics every HUD draw. The GIANTS engine
    -- function getWheelShapeSlip() already returns the current wheel-shape
    -- slip value; an additional 100 ms polling interval would add visible
    -- latency to a symbol that is intended to react immediately.
    -- One authoritative running-gear snapshot for the complete HUD frame.
    -- Every downstream stage consumes this exact physical-axle structure.
    local chassisManifest = getCachedChassisManifest(vehicle)
    refreshManifestDriveSlip(chassisManifest, vehicle)
    local resolvedDrivenAxles = chassisManifest ~= nil and chassisManifest.axleUnits or {}
    self.slipResolvedAxles = resolvedDrivenAxles

    -- Wheel rotation is the INITIALIZATION signal only. It is checked before
    -- accepting the current slip result so raw/inertia slip during startup can
    -- never become the first valid displayed value.
    local wheelRotationDetected = false
    local drivetrainAxles = resolvedDrivenAxles
    for _, axle in ipairs(drivetrainAxles) do
        for _, wheel in ipairs(axle.wheels) do
            if wheel.node ~= nil and wheel.physics ~= nil and wheel.physics.wheelShape ~= nil then
                local ok, value = pcall(
                    getWheelShapeAxleSpeed,
                    wheel.node,
                    wheel.physics.wheelShape
                )
                if ok and value ~= nil
                    and math.abs(value) > LightsSymbolHUD.STARTUP_AXLE_SPEED_THRESHOLD then
                    wheelRotationDetected = true
                    break
                end
            end
        end
        if wheelRotationDetected then
            break
        end
    end

    self.slipWheelRotationDetected = wheelRotationDetected

    local startupBlocked = isSlipStartupBlocked(vehicle)

    -- This latch is deliberately one-way after startup: before the first
    -- valid post-start rotation, rawSlip may already contain values, but those
    -- values are initialization noise and are not evaluated/displayed.
    -- Once rotation has occurred, rotation is no longer required; inertia,
    -- braking and steering slip remain fully valid afterwards.
    if startupBlocked then
        self.slipVehiclePhysicsReady = false
    elseif wheelRotationDetected then
        self.slipVehiclePhysicsReady = true
    end

    local slip = calculateAxleSlip(vehicle, resolvedDrivenAxles)

    if startupBlocked or not self.slipVehiclePhysicsReady then
        for axleIndex = 1, 4 do
            slip.axles[axleIndex] = 0
        end
        slip.front = 0
        slip.rear = 0
    end

    local configuredAxleLimit = 4
    if LightsSymbolHUDSettings ~= nil and LightsSymbolHUDSettings.getDisplayAxleLimit ~= nil then
        configuredAxleLimit = tonumber(LightsSymbolHUDSettings:getDisplayAxleLimit()) or 4
    end
    if configuredAxleLimit ~= 0 and configuredAxleLimit ~= 2 and configuredAxleLimit ~= 4 and configuredAxleLimit ~= 6 then
        configuredAxleLimit = 4
    end

    local configuredDisplayMode = tonumber(getSlipDisplayMode()) or 0
    local configuredHudViewMode = 0
    if LightsSymbolHUDSettings ~= nil and LightsSymbolHUDSettings.getHudViewMode ~= nil then
        configuredHudViewMode = tonumber(LightsSymbolHUDSettings:getHudViewMode()) or 0
    end
    self.hudViewMode = math.max(0, math.min(3, configuredHudViewMode))
    if configuredDisplayMode ~= 0 and configuredDisplayMode ~= 1 then
        configuredDisplayMode = 0
    end

    local configuredMinimalSphereOrientation = 0
    if LightsSymbolHUDSettings ~= nil and LightsSymbolHUDSettings.getMinimalSphereOrientation ~= nil then
        configuredMinimalSphereOrientation = tonumber(LightsSymbolHUDSettings:getMinimalSphereOrientation()) or 0
    end
    if configuredMinimalSphereOrientation ~= 0 and configuredMinimalSphereOrientation ~= 1 then
        configuredMinimalSphereOrientation = 0
    end

    self.minimalSphereOrientation = configuredMinimalSphereOrientation
    self.slipConfiguredAxleLimit = configuredAxleLimit
    self.slipConfiguredDisplayMode = configuredDisplayMode

    -- The vehicle's real axle count comes only from the resolved running-gear
    -- snapshot. The option is a CAP, never an axle count generator.
    local displaySourceAxles = chassisManifest ~= nil and chassisManifest.displayReferenceUnits
        or resolvedDrivenAxles
    local detectedAxleCount = #resolvedDrivenAxles
    local displayAxleSourceCount = #displaySourceAxles
    local displayAxleCount = configuredAxleLimit <= 0
        and 0
        or math.min(displayAxleSourceCount, configuredAxleLimit)
    self.slipDetectedAxleCount = detectedAxleCount
    self.slipDisplayAxleCount = displayAxleCount
    updateSlipDisplayLabels(self, vehicle, displayAxleCount)
    if self.slipDisplayMode ~= configuredDisplayMode then
        self.slipDisplayMode = configuredDisplayMode
        self.isCalculated = false
    end

    local wheelEntries = getSlipWheelEntries(vehicle, displayAxleCount, displaySourceAxles)
    self.slipWheelCount = configuredAxleLimit <= 0 and 0 or #wheelEntries
    self.slipWheelTarget = {}
    self.slipWheelLabels = {}
    self.slipWheelEntries = wheelEntries
    for _, entry in ipairs(wheelEntries) do
        -- nil is a real INVALID state and must never become 0 %.
        if entry.percent == nil then
            local axle = displaySourceAxles[entry.axleIndex]
            local normalizedPercent = axle ~= nil and axle.displaySlipByWheel ~= nil
                and axle.displaySlipByWheel[entry.wheel] or nil

            if normalizedPercent ~= nil then
                entry.percent = normalizedPercent
            else
                -- Some manifests intentionally expose only the representative
                -- wheel at B-stage. Do not lose the display for the other
                -- physical wheel: resolve it through the same validity-aware
                -- live reader. This does not alter wheel/axle recognition.
                entry.percent = getWheelSlipValue(entry.wheel, vehicle, nil)
            end
        end
        -- Same initialization gate for individual-wheel display.
        if startupBlocked or not self.slipVehiclePhysicsReady then
            entry.percent = 0
        end
        self.slipWheelTarget[entry.index] = entry.percent
        self.slipWheelLabels[entry.index] = entry.label
        self.slipWheelInvalid = self.slipWheelInvalid or {}
        self.slipWheelInvalid[entry.index] = entry.percent == nil
        if entry.percent ~= nil then
            self.slipWheelPercent[entry.index] = entry.percent
        end
    end

    -- Independent presentation snapshot. It is built only from the same
    -- resolved axle structure used above. The renderer cannot invent an axle.
    self.slipRenderAxleCount = displayAxleCount
    self.slipAxleCount = displayAxleCount

    -- Extend only multi-axle HUDs. Reposition the background only when the
    -- confirmed axle count changes; do not rewrite the same geometry every HUD frame.
    local layoutKey = tostring(self.slipDisplayMode or 0) .. ":" .. tostring(self.slipAxleCount or 0) .. ":" .. tostring(self.slipWheelCount or 0)
    if self.slipLayoutAxleCount ~= layoutKey then
        self.slipLayoutAxleCount = layoutKey
        local extraRows = 0
        if self.slipDisplayMode == 0 then
            extraRows = math.max(0, self.slipAxleCount - 2)
        elseif self.slipWheelCount > 0 then
            -- Two wheel entries share one row: R1+R2, R3+R4, ...
            -- Therefore the required wheel-row count is half the number of
            -- displayed wheels, rounded up. The base HUD already contains two
            -- rows, so only rows beyond those two need additional height.
            local wheelRows = math.ceil(self.slipWheelCount / 2)
            extraRows = math.max(0, wheelRows - 2)
        end
        local extraHeight =
            extraRows * self.speedMeter:scalePixelToScreenHeight(self.slotHeight + self.gap)

        if self.background ~= nil then
            local baseHeight = self.hudHeight or 0
            self.background:setDimension(self.hudWidth, baseHeight + extraHeight)
            self.background:setPosition(
                self.hudX,
                (self.hudBottom or 0) - extraHeight - self.speedMeter:scalePixelToScreenHeight(6)
            )
        end
    end

    -- Percentage smoothing: fixed 50 ms simulation steps, without a zero-hold.
    -- Each step limits how far the target may move, then the displayed value
    -- follows the limited target with separate rise/fall coefficients.
    local now = g_currentMission ~= nil and g_currentMission.time or 0
    local dtMs = now - (self.slipLastSmoothTime or now)
    if dtMs < 0 or dtMs > 500 then
        dtMs = 0
    end
    self.slipSmoothAccumulator = (self.slipSmoothAccumulator or 0) + dtMs / 1000

    local responseMode = 1
    if LightsSymbolHUDSettings ~= nil and LightsSymbolHUDSettings.getSlipResponseMode ~= nil then
        responseMode = tonumber(LightsSymbolHUDSettings:getSlipResponseMode()) or 1
    end

    -- Direct mode evaluates the presentation at 5 ms; Normal and Calm keep
    -- the established 10-ms presentation cadence.
    local presentationStep = responseMode == 0 and 0.005 or LightsSymbolHUD.SLIP_SMOOTH_STEP

    while self.slipSmoothAccumulator >= presentationStep do
        self.slipSmoothAccumulator = self.slipSmoothAccumulator - presentationStep

        local function stepSmooth(current, target)
            -- Mode 0: direct display, no visual smoothing.
            if responseMode == 0 then
                return target
            end

            local limitedTarget = target
            local maxStep = 8.0
            if responseMode == 2 then
                maxStep = 3.0
            end

            local delta = target - current
            if delta > maxStep then
                limitedTarget = current + maxStep
            elseif delta < -maxStep then
                limitedTarget = current - maxStep
            end
            -- Use the red threshold as a response boundary. Once the
            -- displayed/target state is in the critical range, follow it
            -- more aggressively; below it, keep the visual curve calmer.
            local critical = math.max(current, limitedTarget) >= LightsSymbolHUD.SLIP_RED_THRESHOLD_PERCENT
            local alpha
            if limitedTarget > current then
                alpha = critical
                    and LightsSymbolHUD.SLIP_SMOOTH_UP_HIGH
                    or LightsSymbolHUD.SLIP_SMOOTH_UP
            else
                alpha = critical
                    and LightsSymbolHUD.SLIP_SMOOTH_DOWN_HIGH
                    or LightsSymbolHUD.SLIP_SMOOTH_DOWN
            end

            if responseMode == 2 then
                -- Calm mode: same 10-ms measurement cadence, with a moderately slower
                -- displayed curve and a 3 percentage-point visual step. The
                -- measured target remains unchanged.
                alpha = alpha * 0.75
                if critical and limitedTarget > current then
                    -- Above 40 %, deliberately flatten the upper calm curve.
                    alpha = alpha * 0.40
                end
                local calmMaxStep = 3.0
                if delta > calmMaxStep then
                    limitedTarget = current + calmMaxStep
                elseif delta < -calmMaxStep then
                    limitedTarget = current - calmMaxStep
                end
            end
            return current + (limitedTarget - current) * alpha
        end

        for axleIndex = 1, 4 do
            local target = self.slipAxleTarget[axleIndex] or 0
            local current = self.slipAxlePercent[axleIndex] or 0
            self.slipAxlePercent[axleIndex] = stepSmooth(current, target)
            if target <= LightsSymbolHUD.SLIP_THRESHOLD_PERCENT
                and self.slipAxlePercent[axleIndex] < 0.05 then
                self.slipAxlePercent[axleIndex] = 0
            end
        end

        for index, target in pairs(self.slipWheelTarget) do
            if target ~= nil then
                local current = self.slipWheelPercent[index] or 0
                self.slipWheelPercent[index] = stepSmooth(current, target)
                if target <= LightsSymbolHUD.SLIP_THRESHOLD_PERCENT
                    and self.slipWheelPercent[index] < 0.05 then
                    self.slipWheelPercent[index] = 0
                end
            end
        end
    end

    self.slipLastSmoothTime = now

    self.slipFrontPercent = self.slipAxlePercent[1]
    self.slipRearPercent = self.slipAxlePercent[2]
    self.slipFilteredTargetFront = self.slipAxleTarget[1]
    self.slipFilteredTargetRear = self.slipAxleTarget[2]
    self.slipLastSmoothTime = now

    -- All five light symbols remain visible.
    -- Active = original colored artwork.
    -- Inactive = dedicated neutral-grey artwork at 50% alpha.
    for name, element in pairs(self.icons) do
        local inactiveElement = self.inactiveIcons[name]

        if self.active[name] == true then
            element:setVisible(true)
            if inactiveElement ~= nil then
                inactiveElement:setVisible(false)
            end

            if name == "low" then
                element.overlay:setColor(0.2, 1.0, 0.2, 1.0)
            else
                element.overlay:setColor(1.0, 1.0, 1.0, 1.0)
            end
        else
            element:setVisible(false)
            if inactiveElement ~= nil then
                -- The inactive DDS is already neutral gray. Keep the overlay
                -- neutral as well so no source-icon hue can bleed through.
                inactiveElement.overlay:setColor(1.0, 1.0, 1.0, 1.0)
                inactiveElement:setVisible(true)
            end
        end
    end

    -- Blinker overlays are deliberately kept outside self.icons.
    for _, element in pairs(self.blinkerIcons) do
        element:setVisible(false)
    end

    if self.blinkerState == 1 then
        self.blinkerIcons.left:setVisible(true)
    elseif self.blinkerState == 2 then
        self.blinkerIcons.right:setVisible(true)
    elseif self.blinkerState == 3 then
        -- Hazard warning uses both directional arrows instead of the
        -- dedicated hazard symbol.
        self.blinkerIcons.left:setVisible(true)
        self.blinkerIcons.right:setVisible(true)
        self.blinkerIcons.hazard:setVisible(false)
    end
end

local function stabilizeSlipColorState(stateTable, pendingTable, pendingSinceTable, key, desiredState, nowMs)
    local currentState = stateTable[key]

    -- Initial state: accept immediately. GRAY is never delayed.
    if currentState == nil then
        stateTable[key] = desiredState
        pendingTable[key] = nil
        pendingSinceTable[key] = nil
        return desiredState
    end

    if desiredState == "GRAY" then
        stateTable[key] = "GRAY"
        pendingTable[key] = nil
        pendingSinceTable[key] = nil
        return "GRAY"
    end

    if currentState == "GRAY" then
        stateTable[key] = desiredState
        pendingTable[key] = nil
        pendingSinceTable[key] = nil
        return desiredState
    end

    -- Same state: the opposite-state timer is cancelled.
    if desiredState == currentState then
        pendingTable[key] = nil
        pendingSinceTable[key] = nil
        return currentState
    end

    -- A GREEN <-> RED transition must remain requested continuously for
    -- the full hold time. Any excursion back to the current state above
    -- cancels this timer.
    if pendingTable[key] ~= desiredState then
        pendingTable[key] = desiredState
        pendingSinceTable[key] = nowMs
        return currentState
    end

    local pendingSince = pendingSinceTable[key] or nowMs
    if nowMs - pendingSince >= LightsSymbolHUD.SLIP_COLOR_HOLD_MS then
        stateTable[key] = desiredState
        pendingTable[key] = nil
        pendingSinceTable[key] = nil
        return desiredState
    end

    return currentState
end

local function applyHudScale(element, pos, size, scale)
    if element == nil or pos == nil then return end
    -- B1.1.0.7-safe HUD API: only reposition existing HUD elements.
    element:setPosition(pos[1], pos[2])
end

function LightsSymbolHUD:drawMotorTorqueGauge()
    if self.vehicle == nil or self.speedMeter == nil then
        return
    end

    local configuredHudViewMode = 0
    if LightsSymbolHUDSettings ~= nil and LightsSymbolHUDSettings.getHudViewMode ~= nil then
        configuredHudViewMode = tonumber(LightsSymbolHUDSettings:getHudViewMode()) or 0
    end
    if configuredHudViewMode == 3 then
        return
    end

    local torqueNm = getCurrentAppliedMotorTorqueNm(self.vehicle)
    if torqueNm == nil then
        return
    end

    self.torqueGaugeTargetNm = math.max(0, torqueNm)

    local dtMs = math.max(0, tonumber(g_currentDt) or 0)
    local smoothTimeMs = math.max(1, LightsSymbolHUD.TORQUE_GAUGE_SMOOTH_TIME_MS)
    local alpha = dtMs > 0 and (1 - math.exp(-dtMs / smoothTimeMs)) or 1
    self.torqueGaugeDisplayNm = (tonumber(self.torqueGaugeDisplayNm) or 0)
        + (self.torqueGaugeTargetNm - (tonumber(self.torqueGaugeDisplayNm) or 0)) * alpha

    if math.abs(self.torqueGaugeTargetNm - self.torqueGaugeDisplayNm) < 0.5 then
        self.torqueGaugeDisplayNm = self.torqueGaugeTargetNm
    end

    local speedBg = self.speedMeter.speedBg
    if speedBg == nil
        or self.speedMeter.speedGaugeCenterOffsetX == nil
        or self.speedMeter.speedGaugeCenterOffsetY == nil then
        return
    end

    local activeColor = HUD ~= nil and HUD.COLOR ~= nil and HUD.COLOR.ACTIVE or nil
    if activeColor == nil then
        return
    end

    local centerX = speedBg.x + self.speedMeter.speedGaugeCenterOffsetX
    local centerY = speedBg.y + self.speedMeter.speedGaugeCenterOffsetY
    local radiusX = self.speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.TORQUE_GAUGE_ARC_RADIUS_PX)
    local radiusY = self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_ARC_RADIUS_PX)
    local baseWidth = self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_BASE_WIDTH_PX)
    local activeWidth = self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.TORQUE_GAUGE_ACTIVE_WIDTH_PX)

    -- Cover the original accent segment with a calm dark guide first, then
    -- paint only the live torque portion in the user's currently selected
    -- HUD accent color. No green/yellow/red load gradient is used.
    local baseColor = HUD.COLOR.BACKGROUND_DARK or {0, 0, 0, 0.85}
    local baseArcColor = {
        baseColor[1] or 0,
        baseColor[2] or 0,
        baseColor[3] or 0,
        0.50
    }
    drawTorqueGaugeScale(centerX, centerY, self.speedMeter, activeColor)
    drawTorqueGaugeEndpoints(centerX, centerY, self.speedMeter, activeColor)
    drawTorqueGaugeFactorLabel(centerX, centerY, self.speedMeter, activeColor)

    drawTorqueArc(
        centerX,
        centerY,
        radiusX,
        radiusY,
        LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG,
        LightsSymbolHUD.TORQUE_GAUGE_ARC_END_DEG,
        1,
        baseWidth,
        baseArcColor,
        LightsSymbolHUD.TORQUE_GAUGE_SEGMENTS
    )

    local torqueFraction = math.max(0, math.min(
        1,
        self.torqueGaugeDisplayNm / LightsSymbolHUD.TORQUE_GAUGE_MAX_NM
    ))
    drawTorqueArc(
        centerX,
        centerY,
        radiusX,
        radiusY,
        LightsSymbolHUD.TORQUE_GAUGE_ARC_START_DEG,
        LightsSymbolHUD.TORQUE_GAUGE_ARC_END_DEG,
        torqueFraction,
        activeWidth,
        activeColor,
        LightsSymbolHUD.TORQUE_GAUGE_SEGMENTS
    )
end

function LightsSymbolHUD:drawHUD()
    -- GIANTS' authoritative current vehicle is g_localPlayer:getCurrentVehicle().
    -- Re-sync only when the reference changed. This covers entering and TAB
    -- switching even if the vanilla HUD callback order skips our setVehicle hook.
    local currentVehicle = nil
    if g_localPlayer ~= nil and type(g_localPlayer.getCurrentVehicle) == "function" then
        currentVehicle = g_localPlayer:getCurrentVehicle()
    end

    if currentVehicle ~= self.vehicle then
        self:setVehicle(currentVehicle)

        local wfs = rawget(_G, "ReifenVerschleissWegfahrsperre")
        if currentVehicle ~= nil and wfs ~= nil and type(wfs.refreshVehicleState) == "function" then
            local okRefresh, refreshErr = pcall(wfs.refreshVehicleState, currentVehicle)
            if not okRefresh then
                print(string.format("[LightsSymbolHUD] EWFS refresh error: %s", tostring(refreshErr)))
            end
        end
    end

    if self.vehicle == nil
        or self.speedMeter == nil
        or not self.speedMeter.isVehicleDrawSafe
        or g_dedicatedServerInfo ~= nil then
        return
    end

    -- The torque gauge belongs to the vanilla motor/speedometer area and is
    -- intentionally independent of whether a vehicle has light specialization.
    local torqueGaugeEnabled = true
    if LightsSymbolHUDSettings ~= nil and LightsSymbolHUDSettings.getMotorTorqueGaugeEnabled ~= nil then
        torqueGaugeEnabled = LightsSymbolHUDSettings:getMotorTorqueGaugeEnabled()
    end
    if torqueGaugeEnabled then
        self:drawMotorTorqueGauge()
    end

    if self.vehicle.spec_lights == nil then
        return
    end

    local configuredHudViewMode = 0
    if LightsSymbolHUDSettings ~= nil and LightsSymbolHUDSettings.getHudViewMode ~= nil then
        configuredHudViewMode = tonumber(LightsSymbolHUDSettings:getHudViewMode()) or 0
    end
    configuredHudViewMode = math.max(0, math.min(3, configuredHudViewMode))
    if self.hudViewMode ~= configuredHudViewMode then
        self.hudViewMode = configuredHudViewMode
        self.isCalculated = false
    end

    if not self.isCalculated then
        if not self:calculatePosition() then
            return
        end
    end

    self:updateStates()

    local hudViewMode = tonumber(self.hudViewMode) or 0
    if hudViewMode == 3 then return end

    -- The HUD background is permanently visible.
    -- In minimal/Kugel view it spans exactly the two symbol columns now used
    -- by the HUD: left blinker/tire/EWFS plus the original light column.
    -- The sphere/slip bar keeps its own separate black background, so axle/
    -- wheel columns never enlarge this main symbol panel.
    local hudScale = 1.0
    if self.background ~= nil then
        if hudViewMode == 2 then
            self.background:setPosition(
                self.minimalSymbolHudX or self.baseHudX or self.hudX,
                self.hudBottom - self.speedMeter:scalePixelToScreenHeight(6)
            )
            self.background:setDimension(
                self.minimalSymbolHudWidth or self.baseHudWidth or self.hudWidth,
                self.baseHudHeight or self.hudHeight
            )
        else
            self.background:setPosition(
                self.hudX,
                self.hudBottom - self.speedMeter:scalePixelToScreenHeight(6)
            )
            self.background:setDimension(self.hudWidth, self.hudHeight)
        end
        self.background:render()
    end

    -- First fixed slot: blinker symbol only.
    -- The blinking phase is calculated locally for this HUD. It does not
    -- change turnLightState, vehicle lights, or any other HUD.
    if self.blinkerState ~= nil and self.blinkerState ~= 0 then
        -- FS25 time is in milliseconds. Keep the phase local to this HUD.
        -- 500 ms ON / 500 ms OFF gives a normal indicator rhythm.
        local gameTime = g_currentMission ~= nil and g_currentMission.time or nil
        local blinkOn = true

        if gameTime ~= nil then
            blinkOn = (gameTime % 1000) < 500
        end

        if blinkOn then
            local function renderBlinker(element, pos)
                if element ~= nil and pos ~= nil then
                    applyHudScale(element, pos, self.iconSizes.blinkers, hudScale)
                    element:setVisible(true)
                    element.overlay:render()
                end
            end

            local rightPos = self.positions.blinkers
            local leftPos = nil

            if self.blinkerPositions ~= nil then
                leftPos = self.blinkerPositions.left
            end
            if leftPos == nil then
                leftPos = rightPos
            end

            if self.blinkerState == 1 then
                -- In wheel mode the two wheel columns use the full six light
                -- rows. Keep the left indicator in the original slip column
                -- position only for axle-pair mode; in wheel mode place it
                -- just to the left of the first wheel column.
                -- The left indicator stays in the dedicated blinker slot.
                -- Wheel columns 2/3 are placed to the LEFT of this slot, so
                -- using wheelColumnX[1] here is unnecessary and could yield a
                -- nil X position. Keeping the original leftPos guarantees the
                -- wheel display cannot overlap or suppress the left blinker.
                renderBlinker(self.blinkerIcons.left, leftPos)
            elseif self.blinkerState == 2 then
                -- RIGHT remains in the original light-symbol blinker slot.
                renderBlinker(self.blinkerIcons.right, rightPos)
            elseif self.blinkerState == 3 then
                -- HAZARD: show both directional arrows simultaneously.
                -- Both hazard arrows use their dedicated blinker positions.
                -- The wheel columns are strictly left of this area and cannot
                -- occupy the blinker slot.
                renderBlinker(self.blinkerIcons.left, leftPos)
                renderBlinker(self.blinkerIcons.right, rightPos)
            end
        end
    end

    -- Remaining five fixed slots: always render their current state.
    -- Inactive symbols have already been greyed/translucent in updateStates().
    for index = 2, #LightsSymbolHUD.SLOT_ORDER do
        local name = LightsSymbolHUD.SLOT_ORDER[index]
        local element = self.icons[name]

        local inactiveElement = self.inactiveIcons[name]
        local elementToRender = element

        if self.active ~= nil and self.active[name] ~= true and inactiveElement ~= nil then
            elementToRender = inactiveElement
        end

        if elementToRender ~= nil then
            local pos = self.positions[name]
            applyHudScale(elementToRender, pos, self.iconSizes[name], hudScale)
            elementToRender.overlay:render()
        end
    end

    -- Tire-condition indicator: proven OWN-WEAR source/visibility retained.
    -- B1.1.0.127 uses a dedicated white mask overlay and tints only that
    -- overlay with a continuous piecewise-linear wear color gradient.
    local function rvReadPublished(target, field)
        if target == nil then return nil end
        local value = target[field]
        if value ~= nil then return value end
        local root = nil
        if type(target.getRootVehicle) == "function" then
            local ok, v = pcall(target.getRootVehicle, target)
            if ok then root = v end
        elseif target.rootVehicle ~= nil then
            root = target.rootVehicle
        end
        if root ~= nil and root ~= target then
            return root[field]
        end
        return nil
    end

    -- Wear 0..1. Continuous transitions:
    -- 0-50% green family, 51-75% yellow->orange,
    -- 76-90% orange->red, 90-100% red->wine red.
    local tireColorStops = {
        {0.00, 0.05, 0.95, 0.08}, -- strong green
        {0.30, 0.35, 1.00, 0.20}, -- light green
        {0.50, 0.72, 1.00, 0.10}, -- yellow-green transition
        {0.60, 1.00, 0.92, 0.00}, -- strong yellow
        {0.75, 1.00, 0.48, 0.00}, -- strong orange
        {0.83, 1.00, 0.22, 0.00}, -- orange-red
        {0.90, 0.95, 0.03, 0.02}, -- red
        {1.00, 0.42, 0.00, 0.08}  -- wine red
    }

    local function getTireWearColor(wear01)
        wear01 = math.max(0, math.min(1, tonumber(wear01) or 0))
        for i = 1, #tireColorStops - 1 do
            local a = tireColorStops[i]
            local b = tireColorStops[i + 1]
            if wear01 <= b[1] then
                local span = b[1] - a[1]
                local t = span > 0 and (wear01 - a[1]) / span or 0
                return
                    a[2] + (b[2] - a[2]) * t,
                    a[3] + (b[3] - a[3]) * t,
                    a[4] + (b[4] - a[4]) * t
            end
        end
        local c = tireColorStops[#tireColorStops]
        return c[2], c[3], c[4]
    end

    if self.tireConditionIcons ~= nil then
        local valid = rvReadPublished(self.vehicle, "_FS25_RV_OWN_WEAR_VALID") == true
        local wear01 = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_OWN_WEAR01"))
        if wear01 == nil or wear01 ~= wear01 then wear01 = 0 end
        wear01 = math.max(0, math.min(1, wear01))

        local runningKind = tostring(rvReadPublished(self.vehicle, "_FS25_RV_RUNNING_GEAR_KIND") or "TIRE")
        local isTracked = runningKind == "RUBBER_TRACK" or runningKind == "STEEL_TRACK"
        local wheelWearValid = rvReadPublished(self.vehicle, "_FS25_RV_WHEEL_WEAR_VALID") == true
        local wheelWear01 = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_WHEEL_WEAR01")) or 0
        local wheelCount = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_WHEEL_COUNT")) or 0
        wheelWear01 = math.max(0,math.min(1,wheelWear01))
        wheelCount = math.max(0,math.floor(wheelCount))
        -- B1.1.0.142: A tracked vehicle is only mixed when the HUD's own
        -- chassis manifest finds genuine conventional wheels. Published wheel
        -- counts can also contain internal crawler wheels on articulated
        -- one-piece vehicles (e.g. OXBO), which previously created a false
        -- second tire symbol.
        local chassisInfo = analyzeChassis(self.vehicle)
        local genuineNormalWheelCount = tonumber(chassisInfo and chassisInfo.normalWheelCount) or 0
        local crawlerUnitCount = tonumber(chassisInfo and chassisInfo.crawlerUnitCount) or 0
        -- B1.1.0.144: wear display follows the same aggregation principle as
        -- normal tires: one vehicle-level symbol represents all running gear
        -- of the same family. Four-crawler articulated machines (e.g. OXBO,
        -- T9) therefore remain one RUBBER_TRACK wear symbol even when GIANTS
        -- exposes auxiliary conventional wheel entries internally. Genuine
        -- crawler+tire harvesters with only one crawler pair remain mixed.
        local isMixedRunningGear = isTracked
            and wheelWearValid
            and genuineNormalWheelCount > 0
            and crawlerUnitCount < 4

        -- Always hide both families first. Exactly one symbol family owns the
        -- first vehicle slot; mixed vehicles additionally use the dedicated
        -- second-slot tire overlay.
        for _, element in pairs(self.tireConditionIcons) do
            if element ~= nil then element:setVisible(false) end
        end
        for _, element in pairs(self.runningGearIcons or {}) do
            if element ~= nil then element:setVisible(false) end
        end
        if self.mixedVehicleTireIcon ~= nil then
            self.mixedVehicleTireIcon:setVisible(false)
        end

        if isTracked and self.runningGearIcons ~= nil then
            local trackValid = rvReadPublished(self.vehicle, "_FS25_RV_TRACK_WEAR_VALID") == true
            local trackWear01 = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_TRACK_WEAR01")) or 0
            local rollerValid = rvReadPublished(self.vehicle, "_FS25_RV_ROLLER_WEAR_VALID") == true
            local rollerWear01 = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_ROLLER_WEAR01")) or 0
            trackWear01 = math.max(0, math.min(1, trackWear01))
            rollerWear01 = math.max(0, math.min(1, rollerWear01))

            local tr,tg,tb = getTireWearColor(trackWear01)
            local rr,rg,rb
            if rollerValid then
                rr,rg,rb = getTireWearColor(rollerWear01)
            else
                -- Data unavailable: neutral gray points rather than inventing a wear state.
                rr,rg,rb = 0.45,0.45,0.45
            end

            local outerName = runningKind == "STEEL_TRACK" and "steelOuter" or "rubberOuter"
            local rollerName = runningKind == "STEEL_TRACK" and "steelRollers" or "rubberRollers"
            local outer = self.runningGearIcons[outerName]
            local rollers = self.runningGearIcons[rollerName]

            if outer ~= nil and outer.overlay ~= nil then
                outer:setVisible(trackValid)
                if trackValid then
                    outer.overlay:setColor(tr,tg,tb,1.0)
                    outer.overlay:render()
                end
            end
            if rollers ~= nil and rollers.overlay ~= nil then
                rollers:setVisible(true)
                rollers.overlay:setColor(rr,rg,rb,1.0)
                rollers.overlay:render()
            end

            self.tireConditionWear = trackWear01 * 100
            local sig = string.format("%s|%.3f|%s|%.3f", runningKind,trackWear01,tostring(rollerValid),rollerWear01)
            if self._runningGearLastSignature ~= sig then
                if LightsSymbolHUD.DEBUG_ENABLED == true then
                    print(string.format(
                    "[LightsSymbolHUD][RUNNING-GEAR132] kind=%s track=%.2f%% rollerValid=%s roller=%.2f%%",
                    runningKind, trackWear01*100, tostring(rollerValid), rollerWear01*100
                ))
                end
                self._runningGearLastSignature=sig
            end

            -- Mixed vehicle: running gear stays in slot 1, normal wheels get
            -- their own tire symbol in slot 2 using wheel-only OWN-WEAR.
            if isMixedRunningGear and self.mixedVehicleTireIcon ~= nil
                and self.mixedVehicleTireIcon.overlay ~= nil then
                local wr,wg,wb = getTireWearColor(wheelWear01)
                local layout = self._rvWearLayout
                if layout ~= nil then
                    self.mixedVehicleTireIcon.overlay:setDimension(layout.tireW,layout.tireH)
                    self.mixedVehicleTireIcon:setPosition(
                        layout.tireX,
                        layout.tireY - layout.slotStep
                    )
                end
                self.mixedVehicleTireIcon:setVisible(true)
                self.mixedVehicleTireIcon.overlay:setColor(wr,wg,wb,1.0)
                self.mixedVehicleTireIcon.overlay:render()
            end
        else
            local r,g,b = getTireWearColor(wear01)
            self.tireConditionState = "dynamic"
            self.tireConditionWear = wear01 * 100
            local element = self.tireConditionIcons.dynamic
            if element ~= nil and element.overlay ~= nil then
                element:setVisible(true)
                element.overlay:setColor(r,g,b,1.0)
                element.overlay:render()
            end

            if self._tireConditionLastPublishedValid ~= valid or self._tireConditionLastWear ~= self.tireConditionWear then
                if LightsSymbolHUD.DEBUG_ENABLED == true then
                    print(string.format(
                    "[LightsSymbolHUD][TIRE] source=OWN-WEAR-PUBLISHED valid=%s wear=%.2f%% color=(%.3f,%.3f,%.3f)",
                    tostring(valid), self.tireConditionWear, r,g,b
                ))
                end
                self._tireConditionLastPublishedValid=valid
                self._tireConditionLastWear=self.tireConditionWear
            end
        end
    end

    -- Attached symbol: use the same proven count/worst-wear source and
    -- visibility rule. Only the dedicated white "2" mask receives the tint.
    if self.tireConditionAttachedIcons ~= nil then
        local attachedCount = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_ATTACHED_WEAR_COUNT")) or 0
        attachedCount = math.max(0, math.floor(attachedCount))
        local attachedWear01 = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_ATTACHED_WEAR01")) or 0
        if attachedWear01 ~= attachedWear01 then attachedWear01 = 0 end
        attachedWear01 = math.max(0, math.min(1, attachedWear01))
        local attachedVisible = attachedCount > 0

        local vehicleRunningKind = tostring(rvReadPublished(self.vehicle, "_FS25_RV_RUNNING_GEAR_KIND") or "TIRE")
        local vehicleTracked = vehicleRunningKind == "RUBBER_TRACK" or vehicleRunningKind == "STEEL_TRACK"
        local vehicleWheelValid = rvReadPublished(self.vehicle, "_FS25_RV_WHEEL_WEAR_VALID") == true
        local vehicleWheelCount = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_WHEEL_COUNT")) or 0
        -- Same classification as the vehicle slot above: only genuine
        -- conventional wheels make a tracked vehicle mixed.
        local attachedChassisInfo = analyzeChassis(self.vehicle)
        local vehicleNormalWheelCount = tonumber(attachedChassisInfo and attachedChassisInfo.normalWheelCount) or 0
        local vehicleCrawlerUnitCount = tonumber(attachedChassisInfo and attachedChassisInfo.crawlerUnitCount) or 0
        local vehicleMixed = vehicleTracked
            and vehicleWheelValid
            and vehicleNormalWheelCount > 0
            and vehicleCrawlerUnitCount < 4

        -- For mixed vehicles, slot 2 is occupied by the vehicle tire symbol.
        -- Move any attached wear symbol exactly one more slot down to slot 3.
        local layout = self._rvWearLayout
        if attachedVisible and layout ~= nil then
            local attachedTireY = layout.tireY - layout.slotStep * (vehicleMixed and 2 or 1)
            local attachedRgY = layout.rgY - layout.slotStep * (vehicleMixed and 2 or 1)
            for _, element in pairs(self.tireConditionAttachedIcons or {}) do
                element.overlay:setDimension(layout.tireW,layout.tireH)
                element:setPosition(layout.tireX,attachedTireY)
            end
            for _, element in pairs(self.runningGearAttachedIcons or {}) do
                element.overlay:setDimension(layout.rgW,layout.rgH)
                element:setPosition(layout.rgX,attachedRgY)
            end
            if self.tireConditionAttachedMarker ~= nil then
                self.tireConditionAttachedMarker:setVisible(false)
            end
        end

        local runningKind = tostring(rvReadPublished(self.vehicle, "_FS25_RV_ATTACHED_RUNNING_GEAR_KIND") or "TIRE")
        local isTracked = runningKind == "RUBBER_TRACK" or runningKind == "STEEL_TRACK"

        for _, element in pairs(self.tireConditionAttachedIcons or {}) do
            if element ~= nil then element:setVisible(false) end
        end
        for _, element in pairs(self.runningGearAttachedIcons or {}) do
            if element ~= nil then element:setVisible(false) end
        end

        if attachedVisible and isTracked and self.runningGearAttachedIcons ~= nil then
            local trackValid = rvReadPublished(self.vehicle, "_FS25_RV_ATTACHED_TRACK_WEAR_VALID") == true
            local trackWear01 = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_ATTACHED_TRACK_WEAR01")) or 0
            local rollerValid = rvReadPublished(self.vehicle, "_FS25_RV_ATTACHED_ROLLER_WEAR_VALID") == true
            local rollerWear01 = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_ATTACHED_ROLLER_WEAR01")) or 0
            trackWear01=math.max(0,math.min(1,trackWear01))
            rollerWear01=math.max(0,math.min(1,rollerWear01))
            local tr,tg,tb=getTireWearColor(trackWear01)
            local rr,rg,rb
            if rollerValid then rr,rg,rb=getTireWearColor(rollerWear01) else rr,rg,rb=0.45,0.45,0.45 end

            local outerName=runningKind=="STEEL_TRACK" and "steelOuter" or "rubberOuter"
            local rollerName=runningKind=="STEEL_TRACK" and "steelRollers" or "rubberRollers"
            local outer=self.runningGearAttachedIcons[outerName]
            local rollers=self.runningGearAttachedIcons[rollerName]
            if outer~=nil and outer.overlay~=nil then
                outer:setVisible(trackValid)
                if trackValid then outer.overlay:setColor(tr,tg,tb,1.0); outer.overlay:render() end
            end
            if rollers~=nil and rollers.overlay~=nil then
                rollers:setVisible(true)
                rollers.overlay:setColor(rr,rg,rb,1.0)
                rollers.overlay:render()
            end
        elseif attachedVisible then
            local r,g,b=getTireWearColor(attachedWear01)
            local element=self.tireConditionAttachedIcons.dynamic
            if element~=nil and element.overlay~=nil then
                element:setVisible(true)
                element.overlay:setColor(r,g,b,1.0)
                element.overlay:render()
            end
        end

        -- B1.1.0.140: no trailer number/marker.
        if self.tireConditionAttachedMarker ~= nil then
            self.tireConditionAttachedMarker:setVisible(false)
        end

        self.tireConditionAttachedWear=attachedWear01*100
        self.tireConditionAttachedCount=attachedCount
    end

    -- Electronic immobilizer (EWFS).
    -- HUD is read-only: it only consumes the state already decided by EWFS.
    if self.wfsIcon ~= nil then
        local state = nil

        if self.vehicle ~= nil then
            -- First: direct vehicle-instance field, the path that already
            -- proved functional on Raptor/S7.
            state = self.vehicle._FS25_EWFS_HUD_STATE

            -- Second: root alias of the same vehicle state.
            if state == nil and type(self.vehicle.getRootVehicle) == "function" then
                local ok, root = pcall(self.vehicle.getRootVehicle, self.vehicle)
                if ok and root ~= nil then
                    state = root._FS25_EWFS_HUD_STATE
                end
            elseif state == nil and self.vehicle.rootVehicle ~= nil then
                state = self.vehicle.rootVehicle._FS25_EWFS_HUD_STATE
            end

            -- Third: side-effect-free API fallback, if the namespace is visible.
            if state == nil then
                local wfs = rawget(_G, "ReifenVerschleissWegfahrsperre")
                if wfs ~= nil and type(wfs.getHUDState) == "function" then
                    local ok, value = pcall(wfs.getHUDState, self.vehicle)
                    if ok then
                        state = value
                    end
                end
            end
        end

        local available = state ~= nil
        local active = tonumber(state) == 1

        self.wfsAvailable = available
        self.wfsActive = active

        -- B1.1.0.139: only the mixed+attached case occupies three wear slots.
        -- Shift EWFS down by one additional slot in that case; all established
        -- non-mixed positions remain exactly unchanged.
        local layout = self._rvWearLayout
        if layout ~= nil then
            local vKind = tostring(rvReadPublished(self.vehicle, "_FS25_RV_RUNNING_GEAR_KIND") or "TIRE")
            local vTracked = vKind == "RUBBER_TRACK" or vKind == "STEEL_TRACK"
            local vWheelValid = rvReadPublished(self.vehicle, "_FS25_RV_WHEEL_WEAR_VALID") == true
            local vWheelCount = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_WHEEL_COUNT")) or 0
            local attachedCountNow = tonumber(rvReadPublished(self.vehicle, "_FS25_RV_ATTACHED_WEAR_COUNT")) or 0
            local threeWearSlots = vTracked and vWheelValid and vWheelCount > 0 and attachedCountNow > 0
            local wfsY = layout.tireY - layout.slotStep * (threeWearSlots and 3 or 2)
            if self.wfsIcon ~= nil then self.wfsIcon:setPosition(layout.tireX,wfsY) end
            if self.wfsInactiveIcon ~= nil then self.wfsInactiveIcon:setPosition(layout.tireX,wfsY) end
        end

        -- DEBUG TIMING ONLY: this is the exact HUD draw decision for the EB symbol.
        -- It records when the HUD first sees a changed state and therefore lets
        -- us compare screen-state timing against EWFS TIMER_RELEASE/STATE_CHANGE.
        if LightsSymbolHUD.DEBUG_ENABLED == true
            and (self._ewfsDebugLastVehicle ~= self.vehicle or self._ewfsDebugLastState ~= state) then
            local now = (g_currentMission ~= nil and tonumber(g_currentMission.time)) or 0
            local name = tostring(self.vehicle)
            if self.vehicle ~= nil and self.vehicle.getFullName ~= nil then
                local ok, n = pcall(self.vehicle.getFullName, self.vehicle)
                if ok and n ~= nil then name = tostring(n) end
            end
            print(string.format("[HUD-EWFS-TIMING] DRAW_STATE t=%d vehicle=%s state=%s available=%s active=%s",
                now, name, tostring(state), tostring(available), tostring(active)))
            self._ewfsDebugLastVehicle = self.vehicle
            self._ewfsDebugLastState = state
        end

        self.wfsIcon:setVisible(available and active)
        if self.wfsInactiveIcon ~= nil then
            self.wfsInactiveIcon:setVisible(available and not active)
        end

        if available and active then
            self.wfsIcon.overlay:render()
        elseif available and self.wfsInactiveIcon ~= nil then
            self.wfsInactiveIcon.overlay:render()
        end
    end

    -- ================================================================
    -- NEW INDEPENDENT SLIP RENDERER
    -- ================================================================
    -- The previous drawSlipRow/drawWheelRow code is intentionally gone.
    -- This renderer owns its overlays, state and text drawing.
    --
    -- Option:
    --   displayAxles = 0 -> no slip output
    --   displayAxles = 2 -> first two resolved display axles
    --   displayAxles = 4 -> first four resolved display axles
    --   displayAxles = 6 -> first six resolved display axles
    --   displayMode  = 0 -> axle display
    --   displayMode  = 1 -> individual wheels belonging to those axles
    --
    -- It never reads slip.axleCount.
    -- ================================================================
    local function getLockedSlipColor(stateKey, candidateState, now)
        self.slipColorState = self.slipColorState or {}
        self.slipColorCandidate = self.slipColorCandidate or {}
        self.slipColorCandidateSince = self.slipColorCandidateSince or {}
        self.slipColorLastChange = self.slipColorLastChange or {}

        local current = self.slipColorState[stateKey]
        if current == nil then
            -- Initial state follows the current valid measurement immediately.
            self.slipColorState[stateKey] = candidateState
            self.slipColorCandidate[stateKey] = nil
            self.slipColorCandidateSince[stateKey] = nil
            self.slipColorLastChange[stateKey] = now
            return candidateState
        end

        if candidateState == current then
            self.slipColorCandidate[stateKey] = nil
            self.slipColorCandidateSince[stateKey] = nil
            return current
        end

        -- Every actual color change is immediate once the previous 200 ms
        -- lock has expired. The lock applies after the change, not before it.
        local lastChange = self.slipColorLastChange[stateKey]
        if lastChange == nil
            or now - lastChange >= LightsSymbolHUD.SLIP_COLOR_LOCK_MS then
            self.slipColorState[stateKey] = candidateState
            self.slipColorCandidate[stateKey] = nil
            self.slipColorCandidateSince[stateKey] = nil
            self.slipColorLastChange[stateKey] = now
            return candidateState
        end

        -- A change is currently locked. Remember the latest candidate, but
        -- do not change the visible color until the lock has expired.
        self.slipColorCandidate[stateKey] = candidateState
        self.slipColorCandidateSince[stateKey] = now
        return current
    end

    local function newSlipOverlayState(value, started, rotating, stateKey, now)
        if not started then
            return "GRAY", 0
        end

        -- Once the vehicle is started, a stationary/non-rotating wheel is a
        -- valid 0 % slip state and therefore GREEN, never GRAY.
        local candidateState
        -- Rotation is no longer a presentation gate after startup. A ready,
        -- moving grounded vehicle may legitimately have high slip with a
        -- stationary/slow wheel (braking, steering inertia, heavy load).
        -- The measured value alone determines the warning color.
        if value > 35.0 then
            candidateState = "RED"
        elseif value > 20.0 then
            candidateState = "YELLOW"
        else
            candidateState = "GREEN"
        end

        local lockedState = getLockedSlipColor(
            stateKey or "default",
            candidateState,
            now or getSlipNow()
        )

        return lockedState, value
    end

    local function newSlipOverlayImage(state)
        if state == "RED" then
            return Utils.getFilename("resources/wheel_slip_red.dds", self.modDirectory)
        elseif state == "YELLOW" then
            return Utils.getFilename("resources/wheel_slip_yellow.dds", self.modDirectory)
        elseif state == "GREEN" then
            return Utils.getFilename("resources/wheel_slip_green.dds", self.modDirectory)
        end
        return Utils.getFilename("resources/wheel_slip_gray.dds", self.modDirectory)
    end

    local function newSlipRenderOverlay(element, state, x, y)
        if element == nil or element.overlay == nil then
            return false
        end

        element:setPosition(x, y)
        local image = newSlipOverlayImage(state)
        if element.overlay.filename ~= image then
            element.overlay:setImage(image)
        end
        element.overlay:setColor(1, 1, 1, 1)
        element:setVisible(true)
        element.overlay:render()
        return true
    end

    local function newSlipHideAll()
        if self.slipRender == nil then return end
        for _, element in ipairs(self.slipRender.axle or {}) do
            if element ~= nil then element:setVisible(false) end
        end
        for _, element in ipairs(self.slipRender.wheel or {}) do
            if element ~= nil then element:setVisible(false) end
        end
    end

    local function getMinimalSphereTexture(state)
        if state == "RED" then
            return Utils.getFilename("resources/minimal_sphere_red.dds", self.modDirectory)
        elseif state == "YELLOW" then
            return Utils.getFilename("resources/minimal_sphere_yellow.dds", self.modDirectory)
        elseif state == "GREEN" then
            return Utils.getFilename("resources/minimal_sphere_green.dds", self.modDirectory)
        end
        return Utils.getFilename("resources/minimal_sphere_gray.dds", self.modDirectory)
    end

    -- Hard safety boundary: the independent slip renderer is not allowed to
    -- interrupt the vanilla HUD or other appended HUD callbacks.
    local function runIndependentSlipRenderer()
        local configuredLimit = tonumber(self.slipConfiguredAxleLimit) or 0
        local renderMode = tonumber(self.slipConfiguredDisplayMode) or 0
        local hudViewMode = tonumber(self.hudViewMode) or 0
        if configuredLimit ~= 0 and configuredLimit ~= 2 and configuredLimit ~= 4 and configuredLimit ~= 6 then
            configuredLimit = 0
        end
        if renderMode ~= 0 and renderMode ~= 1 then
            renderMode = 0
        end
    newSlipHideAll()

    if hudViewMode == 3 then return end

    if configuredLimit > 0 and self.slipRender ~= nil then
        local started = false
        if self.vehicle.getIsMotorStarted ~= nil then
            started = self.vehicle:getIsMotorStarted()
        elseif self.vehicle.spec_motorized ~= nil then
            started = self.vehicle.spec_motorized.isMotorStarted == true
        end

        local motorStartTime = 0
        if self.vehicle.getMotorStartTime ~= nil then
            motorStartTime = tonumber(self.vehicle:getMotorStartTime()) or 0
        elseif self.vehicle.spec_motorized ~= nil then
            motorStartTime = tonumber(self.vehicle.spec_motorized.motorStartTime) or 0
        end

        local missionTime = g_currentMission ~= nil and g_currentMission.time or 0
        -- READY is the presentation gate. A ready stationary vehicle must
        -- show 0 % GREEN. The separate physics-validity latch prevents the
        -- first raw inertia value during startup from becoming a peak.
        local driveReady = started and motorStartTime <= missionTime
            and not isSlipStartupBlocked(self.vehicle)

        local rotating = self.slipWheelRotationDetected == true
        local textSize = self.speedMeter:scalePixelToScreenHeight(LightsSymbolHUD.SLIP_TEXT_SIZE * (hudViewMode == 1 and 0.70 or 1.0))
        local gap = self.speedMeter:scalePixelToScreenWidth(2)

        -- Build groups from the authoritative axle snapshot, not from a
        -- second wheel scan. This guarantees: one detected physical axle =
        -- one display group, and no renderer-side regrouping.
        local groups = {}
        local groupOrder = {}
        local maxGroups = math.min(configuredLimit, self.slipDisplayAxleCount or 0, 6)
        for axleIndex = 1, maxGroups do
            local axle = self.slipResolvedAxles[axleIndex]
            if axle ~= nil then
                groups[axleIndex] = {}
                for _, wheel in ipairs(axle.wheels or {}) do
                    local entry = nil
                    for _, candidate in ipairs(self.slipWheelEntries or {}) do
                        if candidate.wheel == wheel and candidate.axleIndex == axleIndex then
                            entry = candidate
                            break
                        end
                    end
                    if entry ~= nil then
                        table.insert(groups[axleIndex], entry)
                    end
                end
                if #groups[axleIndex] > 0 then
                    table.insert(groupOrder, axleIndex)
                end
            end
        end
        -- Hard render boundary. Even if the physical collector reports more
        -- units, the selected 0/2/4 setting alone determines how many groups
        -- may reach the drawing code.
        local shownGroups = 0
        if configuredLimit > 0 then
            shownGroups = math.min(self.slipDisplayAxleCount or 0, #groupOrder, 6)
        end

        if hudViewMode == 2 then
            -- Minimal view:
            --   * one physical axle = two wheel spheres vertically
            --   * axle columns follow the actual resolved front->rear axle
            --     positions (z), not an artificial equal grid
            --   * vertical separator between axle columns
            --   * A1/A2/... below each axle
            --   * no percentage text and no additional axle representative
            --
            -- The sphere texture is square. Screen width/height are converted
            -- independently so the rendered sphere stays geometrically round.
            local spherePixelSize = 16
            local sphereW =
                self.speedMeter:scalePixelToScreenWidth(spherePixelSize)
            local sphereH =
                self.speedMeter:scalePixelToScreenHeight(spherePixelSize)

            local sphereOverlays = self.minimalSphereOverlays
            if sphereOverlays == nil then
                sphereOverlays = {}
                self.minimalSphereOverlays = sphereOverlays
                for _, stateName in ipairs({"GRAY", "GREEN", "YELLOW", "RED"}) do
                    local overlay = Overlay.new(
                        getMinimalSphereTexture(stateName),
                        0, 0, sphereW, sphereH
                    )
                    overlay:setColor(1, 1, 1, 1.0)
                    sphereOverlays[stateName] = overlay
                end
            else
                for _, overlay in pairs(sphereOverlays) do
                    overlay:setDimension(sphereW, sphereH)
                end
            end

            local separatorOverlay = self.minimalSeparatorOverlay
            if separatorOverlay == nil then
                separatorOverlay = Overlay.new(
                    Utils.getFilename(
                        "resources/minimal_separator.dds",
                        self.modDirectory
                    ),
                    0, 0, 1, 1
                )
                self.minimalSeparatorOverlay = separatorOverlay
            end

            -- Compact wheel spacing.
            local wheelGapY =
                self.speedMeter:scalePixelToScreenHeight(3)

            -- Small gap around each axle's vertical pair.
            local axlePadding =
                self.speedMeter:scalePixelToScreenWidth(10)

            -- Position the complete block directly below the light bar,
            -- with the same left-shifted anchor already established in the
            -- previous positioning test.
            local lightLeft = self.positions.blinkers[1]
            local lightRight = self.positions.workBack[1]
            local lightCenterX =
                (lightLeft + lightRight) * 0.5
                - self.speedMeter:scalePixelToScreenWidth(32)

            -- Vertical anchor: lower edge of the COMPLETE light HUD.
            -- The A-label baseline sits on that lower boundary; the wheel
            -- spheres are built upward from the labels.
            local workBackSlotBottom =
                self.positions.workBack[2]
                - (self.slotHeight - self.iconSizes.workBack[2]) * 0.5

            local labelSize =
                self.speedMeter:scalePixelToScreenHeight(11)
            local labelGap =
                self.speedMeter:scalePixelToScreenHeight(2)

            local labelY =
                workBackSlotBottom
                + self.speedMeter:scalePixelToScreenHeight(1)

            local secondY =
                labelY
                + labelSize
                + labelGap

            local firstY =
                secondY + sphereH + wheelGapY

            -- Use the authoritative axle z positions to preserve the real
            -- front/rear spacing. Only the overall span is compacted.
            local minZ = nil
            local maxZ = nil
            for displayIndex = 1, shownGroups do
                local axleIndex = groupOrder[displayIndex]
                local axle = self.slipResolvedAxles[axleIndex]
                local z = axle ~= nil and tonumber(axle.z) or nil
                if z ~= nil then
                    if minZ == nil or z < minZ then minZ = z end
                    if maxZ == nil or z > maxZ then maxZ = z end
                end
            end

            local compactSpan =
                self.speedMeter:scalePixelToScreenWidth(
                    math.max(
                        0,
                        (shownGroups - 1) * 42
                    )
                )

            -- The first sphere starts exactly at the first light column.
            -- Keep the previously established Y position; only the horizontal
            -- anchor is changed here.
            -- The slot edge between light column 1 and 2 is the FIXED
            -- right edge of the complete minimal display.
            -- The whole axle layout grows from this edge towards the left.
            -- Horizontal anchor: center of light slot row 2 ("low").
            -- Leave a small gap so the rightmost sphere is not pressed
            -- directly against the light-symbol column.
            -- Horizontal anchor: move one complete HUD text/slot column
            -- further LEFT from the previous test anchor. The previous test
            -- stopped at the column 1/2 boundary. The required fixed edge is
            -- now the boundary between column 2 (left blinker) and column 3
            -- (the next column to the left). The complete sphere bar grows
            -- from this edge towards the HUD center.
            -- The previous test moves the sphere bar one complete text/slot
            -- column to the left of the blinker anchor. Recreate that column
            -- width locally; textWidth from calculatePosition() is local to
            -- that function and is not available in this scope.
            local textSize =
                self.speedMeter:scalePixelToScreenHeight(
                    LightsSymbolHUD.SLIP_TEXT_SIZE
                )
            local textColumnPitch =
                getTextWidth(textSize, "H 100%")

            -- The sphere/slip block belongs immediately to the LEFT of the
            -- complete two-column symbol HUD.  This single anchor is used by
            -- both minimal orientations, so vertical and horizontal sphere
            -- layouts move together whenever the symbol HUD grows.
            local sphereAnchorBlinkerX =
                self.minimalSphereAnchorX or self.positions.blinkers[1]
            local rightEdgeX =
                sphereAnchorBlinkerX - textColumnPitch
            if self.minimalSymbolHudX ~= nil then
                -- The sphere background itself adds 4 px padding on its right.
                -- Offset the logical edge by the same amount so both black
                -- panels meet cleanly without overlapping the second symbol
                -- column.
                rightEdgeX = self.minimalSymbolHudX
                    - self.speedMeter:scalePixelToScreenWidth(4)
            end

            -- Alternative minimal layout: horizontal sphere bar.
            -- The two wheels of each physical axle are side-by-side in
            -- logical columns 3 and 4. The resolved axles are ordered from
            -- top to bottom. The complete bar is anchored to the SAME lower
            -- HUD edge as the full view and grows upward from that edge.
            -- Only this horizontal Minimal-view branch uses the compact
            -- homogeneous row spacing below.
            if tonumber(self.minimalSphereOrientation) == 1 then
                local columnGap =
                    self.speedMeter:scalePixelToScreenWidth(LightsSymbolHUD.WHEEL_COLUMN_GAP)
                local columnWidth = textColumnPitch

                -- rightEdgeX is the fixed column-2/3 boundary.
                -- The two wheel representatives (R/L) belong to the SAME
                -- physical axle.  Their center distance is deliberately
                -- reduced to 50% of the previous column-to-column distance.
                -- This changes only the R/L pair spacing; axle positions and
                -- the physical front/rear ordering remain untouched.
                local column3Center =
                    rightEdgeX - columnGap - columnWidth * 0.5
                local pairCenterDistance =
                    (columnWidth + columnGap) * 0.5
                local column4Center =
                    column3Center - pairCenterDistance

                -- The FULL HUD background's lower edge is the vertical
                -- reference. Do not derive the horizontal bar from the light
                -- icon rows; that caused the previous version to drift and
                -- lose lower rows when six axles were selected.
                local fullHudLowerEdge =
                    (self.hudBottom or 0)
                    - self.speedMeter:scalePixelToScreenHeight(2)

                local barPaddingX =
                    self.speedMeter:scalePixelToScreenWidth(4)
                local barPaddingY =
                    self.speedMeter:scalePixelToScreenHeight(3)

                -- Use the SAME physical front->rear axle ordering principle
                -- as the working vertical Minimal view.  In the vertical view
                -- the resolved axle Z positions determine where the axle
                -- columns sit.  For the horizontal layout that same Z position
                -- is rotated into the Y axis: front axle = top, rear axle =
                -- bottom.  The complete physical span is compressed to the
                -- compact 18-px-per-axle target span, while preserving the
                -- relative distances between the real axle positions.
                local lastSphereY =
                    fullHudLowerEdge
                    + barPaddingY
                local rowPositions = {}
                local physicalSpanZ = nil
                if minZ ~= nil and maxZ ~= nil then
                    physicalSpanZ = math.abs(maxZ - minZ)
                end

                -- The horizontal layout uses a tighter, uniform axle-row pitch.
                -- Keep the two wheels of one physical axle visually close while
                -- retaining enough room for the 16px sphere itself.
                local compactSpanY =
                    self.speedMeter:scalePixelToScreenHeight(
                        math.max(0, (shownGroups - 1) * 16)
                    )

                for axleDisplayIndex = 1, shownGroups do
                    local axleIndex = groupOrder[axleDisplayIndex]
                    local axle = self.slipResolvedAxles[axleIndex]
                    local z = axle ~= nil and tonumber(axle.z) or nil
                    local t = nil

                    if z ~= nil and minZ ~= nil and maxZ ~= nil
                        and physicalSpanZ ~= nil and physicalSpanZ > 0.001 then
                        -- Same mapping as the vertical reference: max Z is
                        -- front/top and min Z is rear/bottom.
                        t = (maxZ - z) / physicalSpanZ
                    end

                    if t == nil then
                        -- Safe fallback only when a physical Z position is
                        -- unavailable. The normal resolved axle ordering is
                        -- retained and the compact target pitch is used.
                        t = (shownGroups > 1)
                            and ((axleDisplayIndex - 1) / (shownGroups - 1))
                            or 0
                    end

                    -- Keep the physical front/rear order from the vertical
                    -- reference, but use the compact homogeneous row span.
                    -- The resolved Z position controls the relative location
                    -- inside that span; it never changes the axle ordering.
                    rowPositions[axleDisplayIndex] =
                        lastSphereY
                        + compactSpanY * (1.0 - t)
                end

                -- Enforce a real visual gap between every two physical axle rows.
                -- Inside an axle pair (A1/A2, A3/A4, A5/A6) the existing small
                -- gap remains.  At a visual separator (A2/A3, A4/A5) the gap is
                -- deliberately doubled so the separator has a clearly visible
                -- air space to both neighbouring axle rows.
                -- The vehicle Z positions remain the primary reference, but a
                -- compressed/closely packed vehicle must never make two axle
                -- sphere pairs touch or overlap.
                local axleGapY =
                    self.speedMeter:scalePixelToScreenHeight(3)
                local separatorGapY =
                    self.speedMeter:scalePixelToScreenHeight(6)

                if shownGroups > 1 then
                    local lastIndex = shownGroups
                    rowPositions[lastIndex] = lastSphereY
                    for axleDisplayIndex = lastIndex - 1, 1, -1 do
                        local rawY = rowPositions[axleDisplayIndex]
                        local lowerY = rowPositions[axleDisplayIndex + 1]
                        local gapY = axleGapY
                        if (axleDisplayIndex % 2) == 0
                            and axleDisplayIndex < shownGroups then
                            gapY = separatorGapY
                        end
                        local minimumY = lowerY + sphereH + gapY
                        if rawY == nil or rawY < minimumY then
                            rowPositions[axleDisplayIndex] = minimumY
                        end
                    end
                elseif shownGroups == 1 then
                    rowPositions[1] = lastSphereY
                end

                local firstRowY = rowPositions[1] or lastSphereY
                -- The axle labels (A1...A6) sit left of the R/L sphere pair.
                -- The background must therefore extend far enough to cover
                -- the COMPLETE label, not stop between the "A" and its digit.
                local labelGapX =
                    self.speedMeter:scalePixelToScreenWidth(4)
                local labelTextWidth =
                    getTextWidth(labelSize, "A6")
                local labelCenterX =
                    column4Center - columnWidth * 0.5 - labelGapX
                local barLeft =
                    labelCenterX - labelTextWidth * 0.5 - barPaddingX
                local barRight =
                    column3Center + columnWidth * 0.5 + barPaddingX
                local barBottom =
                    fullHudLowerEdge
                local barTop =
                    firstRowY + sphereH + barPaddingY

                if self.minimalLightBarBackground == nil then
                    self.minimalLightBarBackground = Overlay.new(
                        g_baseUIFilename,
                        0, 0, 1, 1
                    )
                    self.minimalLightBarBackground:setUVs(g_colorBgUVs)
                end
                self.minimalLightBarBackground:setPosition(barLeft, barBottom)
                self.minimalLightBarBackground:setDimension(
                    math.max(0, barRight - barLeft),
                    math.max(0, barTop - barBottom)
                )
                self.minimalLightBarBackground:setColor(0, 0, 0, 0.75)
                self.minimalLightBarBackground:render()

                for axleDisplayIndex = 1, shownGroups do
                    local groupKey = groupOrder[axleDisplayIndex]
                    local group = groups[groupKey]
                    table.sort(group, function(a, b)
                        return (tonumber(a.sideIndex) or 0)
                            < (tonumber(b.sideIndex) or 0)
                    end)

                    local y = rowPositions[axleDisplayIndex]

                    for row = 1, 2 do
                        local entry = group[row]
                        if entry ~= nil then
                            local percent =
                                tonumber(self.slipWheelPercent[entry.index])
                            local state = "GRAY"
                            if percent ~= nil
                                and not (
                                    self.slipWheelInvalid ~= nil
                                    and self.slipWheelInvalid[entry.index] == true
                                ) then
                                state = newSlipOverlayState(
                                    percent,
                                    driveReady,
                                    rotating,
                                    "minimal:" .. tostring(entry.index),
                                    getSlipNow()
                                )
                            end

                            local x
                            if #group == 1 then
                                x = (column3Center + column4Center) * 0.5
                            else
                                x = row == 1 and column3Center or column4Center
                            end
                            local overlay =
                                sphereOverlays[state] or sphereOverlays.GRAY
                            overlay:setDimension(sphereW, sphereH)
                            overlay:setColor(1, 1, 1, 1.0)
                            overlay:setPosition(
                                x - sphereW * 0.5,
                                y
                            )
                            overlay:render()
                        end
                    end

                    -- Keep the axle label at the left side of the two
                    -- sphere columns, aligned with the same row.
                    setTextAlignment(RenderText.ALIGN_CENTER)
                    setTextBold(true)
                    setTextColor(1, 1, 1, 1)
                    renderText(
                        column4Center - columnWidth * 0.5
                            - self.speedMeter:scalePixelToScreenWidth(4),
                        y,
                        labelSize,
                        "A" .. tostring(axleDisplayIndex)
                    )
                    setTextBold(false)
                    setTextAlignment(RenderText.ALIGN_LEFT)

                    -- Keep the same grouping rule as the working vertical
                    -- Minimal view: two physical axles form one visual pair,
                    -- then a separator. For 4 axles this is A1/A2 | A3/A4;
                    -- for 6 axles it is A1/A2 | A3/A4 | A5/A6.
                    -- The separator itself is positioned from the REAL vehicle
                    -- axle Z positions: it sits halfway between the last axle
                    -- of the pair and the first axle of the next pair.
                    if (axleDisplayIndex % 2) == 0
                        and axleDisplayIndex < shownGroups then
                        local nextY = rowPositions[axleDisplayIndex + 1]
                        if nextY ~= nil then
                            local lineY =
                                (y + sphereH + nextY) * 0.5
                            separatorOverlay:setDimension(
                                math.max(
                                    self.speedMeter:scalePixelToScreenWidth(8),
                                    barRight - barLeft
                                ),
                                self.speedMeter:scalePixelToScreenHeight(1)
                            )
                            separatorOverlay:setColor(1, 1, 1, 0.70)
                            separatorOverlay:setPosition(
                                barLeft,
                                lineY
                            )
                            separatorOverlay:render()
                        end
                    end
                end

                return
            end

            -- Black backing for the COMPLETE minimal sphere light bar.
            -- The right edge is the fixed column-2/3 boundary; the bar grows
            -- left towards the HUD centre. It is rendered before the spheres
            -- and labels, so the entire bar reads as one continuous black panel.
            if self.minimalLightBarBackground == nil then
                self.minimalLightBarBackground = Overlay.new(
                    g_baseUIFilename,
                    0, 0, 1, 1
                )
                self.minimalLightBarBackground:setUVs(g_colorBgUVs)
            end

            local barPaddingX =
                self.speedMeter:scalePixelToScreenWidth(4)
            local barPaddingY =
                self.speedMeter:scalePixelToScreenHeight(3)
            local barLeft =
                rightEdgeX - sphereW - compactSpan - barPaddingX
            local barRight =
                rightEdgeX + barPaddingX
            local barBottom =
                labelY - barPaddingY
            local barTop =
                firstY + sphereH + barPaddingY

            self.minimalLightBarBackground:setPosition(
                barLeft,
                barBottom
            )
            self.minimalLightBarBackground:setDimension(
                math.max(0, barRight - barLeft),
                math.max(0, barTop - barBottom)
            )
            self.minimalLightBarBackground:setColor(0, 0, 0, 0.75)
            self.minimalLightBarBackground:render()

            local separatorTop =
                firstY + sphereH + self.speedMeter:scalePixelToScreenHeight(2)
            local separatorBottom =
                labelY - self.speedMeter:scalePixelToScreenHeight(2)

            for axleDisplayIndex = 1, shownGroups do
                local groupKey = groupOrder[axleDisplayIndex]
                local group = groups[groupKey]
                local axle = self.slipResolvedAxles[groupKey]

                table.sort(group, function(a, b)
                    return (tonumber(a.sideIndex) or 0)
                        < (tonumber(b.sideIndex) or 0)
                end)

                local z = axle ~= nil and tonumber(axle.z) or nil
                local t = 0.5
                if z ~= nil and minZ ~= nil and maxZ ~= nil
                    and math.abs(maxZ - minZ) > 0.001 then
                    -- max z is front; map front -> left, rear -> right.
                    t = (maxZ - z) / (maxZ - minZ)
                elseif shownGroups > 1 then
                    t = (axleDisplayIndex - 1) / (shownGroups - 1)
                end

                -- Reverse the horizontal direction: t=0 (front/first
                -- resolved axle) is on the left side of the block, while the
                -- right edge remains fixed at the light-slot boundary.
                local x =
                    rightEdgeX
                    - sphereW * 0.5
                    - compactSpan * (1.0 - t)

                -- Two actual wheel values, vertically stacked.
                for row = 1, 2 do
                    local entry = group[row]
                    if entry ~= nil then
                        local percent =
                            tonumber(self.slipWheelPercent[entry.index])
                        local state = "GRAY"

                        if percent ~= nil
                            and not (
                                self.slipWheelInvalid ~= nil
                                and self.slipWheelInvalid[entry.index] == true
                            ) then
                            state = newSlipOverlayState(
                                percent,
                                driveReady,
                                rotating,
                                "minimal:" .. tostring(entry.index),
                                getSlipNow()
                            )
                        end

                        local y
                        if #group == 1 then
                            y = (firstY + secondY) * 0.5
                        else
                            y = (row == 1) and firstY or secondY
                        end
                        local overlay =
                            sphereOverlays[state] or sphereOverlays.GRAY

                        overlay:setDimension(sphereW, sphereH)
                        overlay:setColor(1, 1, 1, 1.0)
                        overlay:setPosition(
                            x - sphereW * 0.5,
                            y
                        )
                        overlay:render()
                    end
                end

                -- Axle label underneath the wheel pair.
                setTextAlignment(RenderText.ALIGN_CENTER)
                setTextBold(true)
                setTextColor(1, 1, 1, 1)
                renderText(
                    x,
                    labelY,
                    labelSize,
                    "A" .. tostring(axleDisplayIndex)
                )
                setTextBold(false)
                setTextAlignment(RenderText.ALIGN_LEFT)

                -- Separator between axle columns, matching the compact
                -- visual language of the reference layout.
                if axleDisplayIndex < shownGroups
                    and (axleDisplayIndex % 2) == 0 then
                    local nextAxle = self.slipResolvedAxles[
                        groupOrder[axleDisplayIndex + 1]
                    ]
                    local nextZ =
                        nextAxle ~= nil and tonumber(nextAxle.z) or nil
                    local nextT = 0.5

                    if nextZ ~= nil and minZ ~= nil and maxZ ~= nil
                        and math.abs(maxZ - minZ) > 0.001 then
                        nextT = (maxZ - nextZ) / (maxZ - minZ)
                    elseif shownGroups > 1 then
                        nextT = axleDisplayIndex / (shownGroups - 1)
                    end

                    local nextX =
                        rightEdgeX
                        - sphereW * 0.5
                        - compactSpan * (1.0 - nextT)
                    local lineX = (x + nextX) * 0.5

                    separatorOverlay:setDimension(
                        self.speedMeter:scalePixelToScreenWidth(1),
                        math.max(
                            self.speedMeter:scalePixelToScreenHeight(8),
                            separatorTop - separatorBottom
                        )
                    )
                    separatorOverlay:setColor(1, 1, 1, 0.70)
                    separatorOverlay:setPosition(
                        lineX - self.speedMeter:scalePixelToScreenWidth(0.5),
                        separatorBottom
                    )
                    separatorOverlay:render()
                end
            end

            return
        end

        if renderMode == 0 then
            -- Axle mode: one symbol and one A/V/H + percent line per group.
            for displayIndex = 1, shownGroups do
                local groupKey = groupOrder[displayIndex]
                local group = groups[groupKey]
                local sum = 0
                local count = 0
                for _, entry in ipairs(group) do
                    if not (self.slipWheelInvalid ~= nil and self.slipWheelInvalid[entry.index] == true) then
                        local value = tonumber(self.slipWheelPercent[entry.index])
                        if value ~= nil then
                            sum = sum + value
                            count = count + 1
                        end
                    end
                end

                local overlay = self.slipRender.axle[displayIndex]
                local pos
                    if configuredLimit == 6 and self.slipPositions.sixAxle ~= nil then
                        pos = self.slipPositions.sixAxle[displayIndex]
                    else
                        pos = self.slipPositions["axle" .. tostring(displayIndex)]
                    end
                if overlay ~= nil and pos ~= nil and count > 0 then
                    local percent = sum / count
                    local state, displayValue = newSlipOverlayState(
                        percent,
                        driveReady,
                        rotating,
                        "axle:" .. tostring(displayIndex),
                        getSlipNow()
                    )
                    local compact = hudViewMode == 1
                    newSlipRenderOverlay(overlay, state, pos[1], pos[2])
                    local label = self.slipDisplayLabels["axle" .. tostring(displayIndex)]
                        or ("A" .. tostring(displayIndex))
                    local percentText = string.format("%d%%", math.floor(displayValue + 0.5))
                    local labelWidth = getTextWidth(textSize, label)
                    local percentWidth = getTextWidth(textSize, percentText)
                    local totalWidth = labelWidth + gap + percentWidth
                    local textX = self.positions.blinkers[1] - totalWidth

                    -- Six-axis PAIR mode: the symbol column was moved one
                    -- slot to the left. Move label + percent by exactly the
                    -- same horizontal offset so all three stay together.
                    if configuredLimit == 6 and self.slipPositions.sixAxle ~= nil then
                        local pairPos = self.slipPositions.sixAxle[displayIndex]
                        local basePos = self.slipPositions.axle1
                        if pairPos ~= nil and basePos ~= nil then
                            textX = textX + (pairPos[1] - basePos[1])
                        end
                    end

                    local textY = pos[2] - self.speedMeter:scalePixelToScreenHeight(8) * (hudViewMode == 1 and 0.70 or 1.0)

                    setTextAlignment(RenderText.ALIGN_LEFT)
                    setTextBold(true)
                    setTextColor(1, 1, 1, 1)
                    renderText(textX, textY, textSize, label)
                    if hudViewMode ~= 1 then
                        renderText(textX + labelWidth + gap, textY, textSize, percentText)
                    end
                    setTextBold(false)
                    setTextAlignment(RenderText.ALIGN_LEFT)
                end
            end
        else
            -- Individual-wheel mode: show every wheel belonging to the
            -- selected display axle groups, up to the existing 8-wheel UI.
            local wheelDisplayIndex = 0
            for displayIndex = 1, shownGroups do
                local groupKey = groupOrder[displayIndex]
                local group = groups[groupKey]

                table.sort(group, function(a, b)
                    return (tonumber(a.sideIndex) or 0) < (tonumber(b.sideIndex) or 0)
                end)

                for sideIndex, entry in ipairs(group) do
                    if wheelDisplayIndex >= LightsSymbolHUD.WHEEL_DISPLAY_MAX then
                        break
                    end

                    wheelDisplayIndex = wheelDisplayIndex + 1
                    local overlay = self.slipRender.wheel[wheelDisplayIndex]
                    local wheelPositions = configuredLimit == 6
                            and (self.wheelPositionsSixAxle or self.wheelPositions)
                            or self.wheelPositions

                    -- A display row is a physical axle, not a fixed pair of
                    -- sequential wheel numbers. This keeps a one-wheel axle
                    -- on its own row instead of pulling the first wheel of the
                    -- following axle into the empty second slot.
                    local slotIndex = (displayIndex - 1) * 2 + math.min(sideIndex, 2)
                    local pos = wheelPositions["wheel" .. tostring(slotIndex)]

                    -- For a true single-wheel axle (trike/motorcycle style),
                    -- center the one wheel between the normal left/right HUD
                    -- columns. Two-wheel axles keep the established columns.
                    if #group == 1 and pos ~= nil then
                        local leftPos = wheelPositions["wheel" .. tostring((displayIndex - 1) * 2 + 1)]
                        local rightPos = wheelPositions["wheel" .. tostring((displayIndex - 1) * 2 + 2)]
                        if leftPos ~= nil and rightPos ~= nil then
                            pos = {
                                (leftPos[1] + rightPos[1]) * 0.5,
                                leftPos[2]
                            }
                        end
                    end

                    if overlay ~= nil and pos ~= nil
                        and not (self.slipWheelInvalid ~= nil and self.slipWheelInvalid[entry.index] == true) then
                        local percent = tonumber(self.slipWheelPercent[entry.index])
                        if percent ~= nil then
                            local state, displayValue = newSlipOverlayState(
                                percent,
                                driveReady,
                                rotating,
                                "wheel:" .. tostring(entry.index),
                                getSlipNow()
                            )
                            local compact = hudViewMode == 1
                            newSlipRenderOverlay(overlay, state, pos[1], pos[2])
                        local label = entry.label or ("R" .. tostring(wheelDisplayIndex))
                        local percentText = string.format("%d%%", math.floor(displayValue + 0.5))
                        local labelWidth = getTextWidth(textSize, label)
                        local percentWidth = getTextWidth(textSize, percentText)
                        local totalWidth = labelWidth + gap + percentWidth
                        local iconCenterX = pos[1] + (self.slipRender.size[1] * (hudViewMode == 1 and 0.70 or 1.0) * 0.5)
                        local textX = iconCenterX - totalWidth * 0.5
                        local textY = pos[2] - self.speedMeter:scalePixelToScreenHeight(2) - textSize

                        setTextAlignment(RenderText.ALIGN_LEFT)
                        setTextBold(true)
                        setTextColor(1, 1, 1, 1)
                        renderText(textX, textY, textSize, label)
                        if hudViewMode ~= 1 then
                            renderText(textX + labelWidth + gap, textY, textSize, percentText)
                        end
                        setTextBold(false)
                        setTextAlignment(RenderText.ALIGN_LEFT)
                        end
                    end
                end
            end
        end
    end

    end

    local rendererOk, rendererError = pcall(runIndependentSlipRenderer)
    if not rendererOk then
        -- The independent renderer remains fail-safe: an unexpected rendering
        -- error must never propagate into the game's HUD/update chain.
    end
end


function LightsSymbolHUD:getTireConditionColor(wear)
    -- wear is normalized to 0..1: 1 = new, 0 = fully worn
    if wear >= 0.40 then
        return 0.0, 1.0, 0.0, 1.0
    elseif wear >= 0.30 then
        return 1.0, 1.0, 0.0, 1.0
    elseif wear >= 0.15 then
        -- Continuous transition: yellow -> orange -> wine red.
        local t = (0.30 - wear) / 0.15
        local yellow = {1.0, 1.0, 0.0}
        local wine = {0.45, 0.0, 0.08}
        local r = yellow[1] + (wine[1] - yellow[1]) * t
        local g = yellow[2] + (wine[2] - yellow[2]) * t
        local b = yellow[3] + (wine[3] - yellow[3]) * t
        return r, g, b, 1.0
    else
        return 0.45, 0.0, 0.08, 1.0
    end
end

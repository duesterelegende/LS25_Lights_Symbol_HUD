-- Lights Symbol HUD persistent setting + FS25 General Settings integration.
-- The visible controls follow the same General Settings pattern used by
-- LongBeam Pro: clone the existing GIANTS section header and multi-option
-- template instead of trying to register an abstract SettingsModel entry.

LightsSymbolHUDSettings = {}
LightsSymbolHUDSettings.displayAxles = 4
LightsSymbolHUDSettings.displayMode = 0 -- 0 = axle pairs, 1 = individual driven wheels
LightsSymbolHUDSettings.hudViewMode = 0 -- 0 full, 1 compact, 2 minimal, 3 hidden
LightsSymbolHUDSettings.slipResponseMode = 1 -- 0 direct, 1 normal, 2 calm
LightsSymbolHUDSettings.minimalSphereOrientation = 0 -- 0 vertical, 1 horizontal (minimal view only)

local LightsSymbolHUDSettingsUI = {}
local LightsSymbolHUDSettingsUI_mt = Class(LightsSymbolHUDSettingsUI)

function LightsSymbolHUDSettings:getSettingsFilePath()
    local settingsDirectory = getUserProfileAppPath() .. "modSettings"
    if createFolder ~= nil then
        createFolder(settingsDirectory)
    end
    return settingsDirectory .. "/LightsSymbolHUD.xml"
end

function LightsSymbolHUDSettings:validate()
    local value = tonumber(self.displayAxles)
    if value ~= 0 and value ~= 2 and value ~= 4 and value ~= 6 then
        value = 4
    end
    self.displayAxles = value

    local mode = tonumber(self.displayMode)
    if mode ~= 0 and mode ~= 1 then
        mode = 0
    end
    self.displayMode = mode
    local hudMode = tonumber(self.hudViewMode)
    if hudMode ~= 0 and hudMode ~= 1 and hudMode ~= 2 and hudMode ~= 3 then hudMode = 0 end
    self.hudViewMode = hudMode

    local responseMode = tonumber(self.slipResponseMode)
    if responseMode ~= 0 and responseMode ~= 1 and responseMode ~= 2 then responseMode = 1 end
    self.slipResponseMode = responseMode

    local sphereOrientation = tonumber(self.minimalSphereOrientation)
    if sphereOrientation ~= 0 and sphereOrientation ~= 1 then sphereOrientation = 0 end
    self.minimalSphereOrientation = sphereOrientation
end

function LightsSymbolHUDSettings:loadSettings()
    local path = self:getSettingsFilePath()
    if not fileExists(path) then
        self:validate()
        return
    end

    local xmlFile = loadXMLFile("LightsSymbolHUD", path)
    if xmlFile == nil or xmlFile == 0 then
        self:validate()
        return
    end

    local value = getXMLInt(xmlFile, "LightsSymbolHUD.settings#displayAxles")
    if value ~= nil then
        self.displayAxles = value
    end

    local mode = getXMLInt(xmlFile, "LightsSymbolHUD.settings#displayMode")
    if mode ~= nil then
        self.displayMode = mode
    end
    local hudMode = getXMLInt(xmlFile, "LightsSymbolHUD.settings#hudViewMode")
    if hudMode ~= nil then
        self.hudViewMode = hudMode
    end
    local responseMode = getXMLInt(xmlFile, "LightsSymbolHUD.settings#slipResponseMode")
    if responseMode ~= nil then
        self.slipResponseMode = responseMode
    end
    local sphereOrientation = getXMLInt(xmlFile, "LightsSymbolHUD.settings#minimalSphereOrientation")
    if sphereOrientation ~= nil then
        self.minimalSphereOrientation = sphereOrientation
    end
    delete(xmlFile)
    self:validate()
end

function LightsSymbolHUDSettings:saveSettings()
    self:validate()

    local xmlFile = createXMLFile(
        "LightsSymbolHUD",
        self:getSettingsFilePath(),
        "LightsSymbolHUD"
    )
    if xmlFile == nil or xmlFile == 0 then
        return
    end

    setXMLInt(xmlFile, "LightsSymbolHUD.settings#displayAxles", self.displayAxles)
    setXMLInt(xmlFile, "LightsSymbolHUD.settings#displayMode", self.displayMode)
    setXMLInt(xmlFile, "LightsSymbolHUD.settings#hudViewMode", self.hudViewMode)
    setXMLInt(xmlFile, "LightsSymbolHUD.settings#slipResponseMode", self.slipResponseMode)
    setXMLInt(xmlFile, "LightsSymbolHUD.settings#minimalSphereOrientation", self.minimalSphereOrientation)
    saveXMLFile(xmlFile)
    delete(xmlFile)
end

function LightsSymbolHUDSettings:getDisplayAxleLimit()
    self:validate()
    return self.displayAxles
end

function LightsSymbolHUDSettings:getDisplayMode()
    self:validate()
    return self.displayMode
end
function LightsSymbolHUDSettings:getHudViewMode()
    self:validate()
    return self.hudViewMode
end

function LightsSymbolHUDSettings:getSlipResponseMode()
    self:validate()
    return self.slipResponseMode
end

function LightsSymbolHUDSettings:getMinimalSphereOrientation()
    self:validate()
    return self.minimalSphereOrientation
end

function LightsSymbolHUDSettingsUI.new(settings)
    local self = setmetatable({}, LightsSymbolHUDSettingsUI_mt)
    self.settings = settings
    self.controls = {}
    return self
end

function LightsSymbolHUDSettingsUI:updateFocusIds(element)
    if element == nil then
        return
    end

    element.focusId = FocusManager:serveAutoFocusId()
    if element.elements ~= nil then
        for _, child in pairs(element.elements) do
            self:updateFocusIds(child)
        end
    end
end

function LightsSymbolHUDSettingsUI:createSection(settingsPage)
    local sectionTitle = nil
    for _, element in ipairs(settingsPage.generalSettingsLayout.elements) do
        if element.name == "sectionHeader" then
            sectionTitle = element:clone(settingsPage.generalSettingsLayout)
            sectionTitle:setText(g_i18n:getText("lightsSymbolHUD_setting_title"))
            break
        end
    end

    if sectionTitle ~= nil then
        sectionTitle.focusId = FocusManager:serveAutoFocusId()
        table.insert(settingsPage.controlsList, sectionTitle)
    end

    return sectionTitle
end

function LightsSymbolHUDSettingsUI:createOptionControl(settingsPage, controlId, labelKey, descriptionKey, optionTexts, callbackName)
    local elementBox = settingsPage.multiVolumeVoiceBox:clone(settingsPage.generalSettingsLayout)
    self:updateFocusIds(elementBox)

    elementBox.id = controlId .. "Box"

    local option = elementBox.elements[1]
    option.target = self
    option.id = controlId
    option:setDisabled(false)

    elementBox.elements[2]:setText(g_i18n:getText(labelKey))
    option.elements[1]:setText(g_i18n:getText(descriptionKey))
    option:setTexts(optionTexts)
    option:setCallback("onClickCallback", callbackName)
    option.target = self

    table.insert(settingsPage.controlsList, elementBox)
    self.controls[controlId] = elementBox
    return elementBox, option
end

function LightsSymbolHUDSettingsUI:createAxleControl(settingsPage)
    self.axleControl, self.axleOption = self:createOptionControl(
        settingsPage,
        "lightsSymbolHUD_displayAxles",
        "lightsSymbolHUD_displayAxles_short",
        "lightsSymbolHUD_displayAxles_long",
        {
            g_i18n:getText("lightsSymbolHUD_displayAxles_0"),
            g_i18n:getText("lightsSymbolHUD_displayAxles_2"),
            g_i18n:getText("lightsSymbolHUD_displayAxles_4"),
            g_i18n:getText("lightsSymbolHUD_displayAxles_6")
        },
        "on_lightsSymbolHUD_displayAxles_changed"
    )
end

function LightsSymbolHUDSettingsUI:createDisplayModeControl(settingsPage)
    self.modeControl, self.modeOption = self:createOptionControl(
        settingsPage,
        "lightsSymbolHUD_displayMode",
        "lightsSymbolHUD_displayMode_short",
        "lightsSymbolHUD_displayMode_long",
        {
            g_i18n:getText("lightsSymbolHUD_displayMode_axlePairs"),
            g_i18n:getText("lightsSymbolHUD_displayMode_wheels")
        },
        "on_lightsSymbolHUD_displayMode_changed"
    )
end

function LightsSymbolHUDSettingsUI:createHudViewModeControl(settingsPage)
    self.hudViewControl, self.hudViewOption = self:createOptionControl(
        settingsPage, "lightsSymbolHUD_hudViewMode",
        "lightsSymbolHUD_hudViewMode_short", "lightsSymbolHUD_hudViewMode_long",
        {
            g_i18n:getText("lightsSymbolHUD_hudViewMode_full"),
            g_i18n:getText("lightsSymbolHUD_hudViewMode_compact"),
            g_i18n:getText("lightsSymbolHUD_hudViewMode_minimal"),
            g_i18n:getText("lightsSymbolHUD_hudViewMode_off")
        },
        "on_lightsSymbolHUD_hudViewMode_changed"
    )
end
function LightsSymbolHUDSettingsUI:createMinimalSphereOrientationControl(settingsPage)
    self.sphereOrientationControl, self.sphereOrientationOption = self:createOptionControl(
        settingsPage,
        "lightsSymbolHUD_minimalSphereOrientation",
        "lightsSymbolHUD_minimalSphereOrientation_short",
        "lightsSymbolHUD_minimalSphereOrientation_long",
        {
            g_i18n:getText("lightsSymbolHUD_minimalSphereOrientation_vertical"),
            g_i18n:getText("lightsSymbolHUD_minimalSphereOrientation_horizontal")
        },
        "on_lightsSymbolHUD_minimalSphereOrientation_changed"
    )
end

function LightsSymbolHUDSettingsUI:createSlipResponseModeControl(settingsPage)
    self.slipResponseControl, self.slipResponseOption = self:createOptionControl(
        settingsPage,
        "lightsSymbolHUD_slipResponseMode",
        "lightsSymbolHUD_slipResponseMode_short",
        "lightsSymbolHUD_slipResponseMode_long",
        {
            g_i18n:getText("lightsSymbolHUD_slipResponseMode_direct"),
            g_i18n:getText("lightsSymbolHUD_slipResponseMode_normal"),
            g_i18n:getText("lightsSymbolHUD_slipResponseMode_calm")
        },
        "on_lightsSymbolHUD_slipResponseMode_changed"
    )
end

function LightsSymbolHUDSettingsUI:setMinimalSphereOrientation(value)
    if self.sphereOrientationOption ~= nil then
        self.sphereOrientationOption:setState((tonumber(value) or 0) + 1)
    end
end

function LightsSymbolHUDSettingsUI:getMinimalSphereOrientation(state)
    return math.max(0, math.min(1, (tonumber(state) or 1) - 1))
end

function LightsSymbolHUDSettingsUI:onMinimalSphereOrientationChanged(state)
    self.settings.minimalSphereOrientation = self:getMinimalSphereOrientation(state)
    self.settings:validate()
end

function LightsSymbolHUDSettingsUI:setSlipResponseMode(value)
    if self.slipResponseOption ~= nil then self.slipResponseOption:setState((tonumber(value) or 1) + 1) end
end

function LightsSymbolHUDSettingsUI:getSlipResponseMode(state)
    return (tonumber(state) or 2) - 1
end

function LightsSymbolHUDSettingsUI:on_lightsSymbolHUD_slipResponseMode_changed(state)
    local value = self:getSlipResponseMode(state)
    self.settings.slipResponseMode = value
    self.settings:validate()
    self.settings:saveSettings()
end

function LightsSymbolHUDSettingsUI:setHudViewMode(value)
    if self.hudViewOption ~= nil then self.hudViewOption:setState((tonumber(value) or 0) + 1) end
end
function LightsSymbolHUDSettingsUI:getHudViewMode(state)
    return math.max(0, math.min(3, (tonumber(state) or 1) - 1))
end
function LightsSymbolHUDSettingsUI:onHudViewModeChanged(state)
    self.settings.hudViewMode = self:getHudViewMode(state)
    self.settings:validate()
end
function LightsSymbolHUDSettingsUI:setAxleValue(value)

    if self.axleOption == nil then
        return
    end

    local state = value == 0 and 1
        or (value == 2 and 2
        or (value == 4 and 3 or 4))
    self.axleOption:setState(state)
end

function LightsSymbolHUDSettingsUI:getAxleValue(state)
    if state == 1 then
        return 0
    elseif state == 2 then
        return 2
    elseif state == 3 then
        return 4
    end
    return 6
end

function LightsSymbolHUDSettingsUI:setModeValue(value)
    if self.modeOption == nil then
        return
    end

    self.modeOption:setState(value == 1 and 2 or 1)
end

function LightsSymbolHUDSettingsUI:getModeValue(state)
    return state == 2 and 1 or 0
end

function LightsSymbolHUDSettingsUI:onSettingChanged(state)
    self.settings.displayAxles = self:getAxleValue(state)
    self.settings:validate()
end

function LightsSymbolHUDSettingsUI:onDisplayModeChanged(state)
    self.settings.displayMode = self:getModeValue(state)
    self.settings:validate()
end

function LightsSymbolHUDSettingsUI:populate()
    self:setAxleValue(self.settings:getDisplayAxleLimit())
    self:setModeValue(self.settings:getDisplayMode())
    self:setHudViewMode(self.settings:getHudViewMode())
    self:setSlipResponseMode(self.settings:getSlipResponseMode())
    self:setMinimalSphereOrientation(self.settings:getMinimalSphereOrientation())
end

function LightsSymbolHUDSettingsUI:onFrameClose()
    self.settings:saveSettings()
end

function LightsSymbolHUDSettingsUI:registerSettings()
    if g_gui == nil
        or g_gui.screenControllers == nil
        or g_gui.screenControllers[InGameMenu] == nil
        or g_gui.screenControllers[InGameMenu].pageSettings == nil then
        return false
    end

    local settingsPage = g_gui.screenControllers[InGameMenu].pageSettings
    self.sectionTitle = self:createSection(settingsPage)
    table.insert(self.controls, self.sectionTitle)
    self:createAxleControl(settingsPage)
    self:createDisplayModeControl(settingsPage)
    self:createHudViewModeControl(settingsPage)
    self:createMinimalSphereOrientationControl(settingsPage)
    self:createSlipResponseModeControl(settingsPage)

    -- Both controls are attached directly to their multi-option elements,
    -- following the same working LongBeam Pro General Settings pattern.
    self.on_lightsSymbolHUD_displayAxles_changed = function(_, state)
        self:onSettingChanged(state)
    end
    self.on_lightsSymbolHUD_displayMode_changed = function(_, state)
        self:onDisplayModeChanged(state)
    end
    self.on_lightsSymbolHUD_hudViewMode_changed = function(_, state)
        self:onHudViewModeChanged(state)
    end
    self.on_lightsSymbolHUD_slipResponseMode_callback = function(_, state)
        self:on_lightsSymbolHUD_slipResponseMode_changed(state)
    end
    self.on_lightsSymbolHUD_minimalSphereOrientation_changed = function(_, state)
        self:onMinimalSphereOrientationChanged(state)
    end

    self.axleOption:setCallback("onClickCallback", "on_lightsSymbolHUD_displayAxles_changed")
    self.axleOption.target = self
    self.modeOption:setCallback("onClickCallback", "on_lightsSymbolHUD_displayMode_changed")
    self.modeOption.target = self
    self.hudViewOption:setCallback("onClickCallback", "on_lightsSymbolHUD_hudViewMode_changed")
    self.hudViewOption.target = self
    self.sphereOrientationOption:setCallback("onClickCallback", "on_lightsSymbolHUD_minimalSphereOrientation_changed")
    self.sphereOrientationOption.target = self
    self.slipResponseOption:setCallback("onClickCallback", "on_lightsSymbolHUD_slipResponseMode_callback")
    self.slipResponseOption.target = self

    InGameMenuSettingsFrame.onFrameOpen = Utils.appendedFunction(
        InGameMenuSettingsFrame.onFrameOpen,
        function()
            self:populate()
        end
    )

    InGameMenuSettingsFrame.onFrameClose = Utils.appendedFunction(
        InGameMenuSettingsFrame.onFrameClose,
        function()
            self:onFrameClose()
        end
    )

    self:populate()
    settingsPage.generalSettingsLayout:invalidateLayout()
    return true
end

function LightsSymbolHUDSettings:initUI()
    if self.uiInitialized then
        return
    end

    if g_gui == nil
        or g_gui.screenControllers == nil
        or g_gui.screenControllers[InGameMenu] == nil
        or g_gui.screenControllers[InGameMenu].pageSettings == nil then
        return
    end

    self.ui = LightsSymbolHUDSettingsUI.new(self)
    if self.ui:registerSettings() then
        self.uiInitialized = true
    end
end

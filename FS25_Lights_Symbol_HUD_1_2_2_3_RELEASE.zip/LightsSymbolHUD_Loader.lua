-- Lights Symbol HUD loader
-- HUD-only: does not modify vehicle light ranges or vehicle light functions.
-- The vanilla HUD methods are extended, never replaced.

local directory = g_currentModDirectory
local lightsSymbolHUDInstance = nil

source(Utils.getFilename("LightsSymbolHUD_Settings.lua", directory))
source(Utils.getFilename("LightsSymbolHUD.lua", directory))

local function LSH_loadedMission(mission)
    if mission == nil or mission.cancelLoading then
        return
    end

    if LightsSymbolHUDSettings ~= nil and not LightsSymbolHUDSettings.settingsLoaded then
        LightsSymbolHUDSettings:loadSettings()
        LightsSymbolHUDSettings.settingsLoaded = true
    end

    if mission.hud == nil or mission.hud.speedMeter == nil then
        return
    end

    if lightsSymbolHUDInstance == nil then
        lightsSymbolHUDInstance = LightsSymbolHUD:new(
            mission.hud.speedMeter,
            directory
        )
        lightsSymbolHUDInstance:load()

        mission.hud.drawControlledEntityHUD =
            Utils.appendedFunction(
                mission.hud.drawControlledEntityHUD,
                function(hud)
                    if lightsSymbolHUDInstance ~= nil and hud.isVisible then
                        local ok, err = pcall(lightsSymbolHUDInstance.drawHUD, lightsSymbolHUDInstance)
                if not ok then
                    print(string.format("[LightsSymbolHUD] drawHUD runtime error: %s", tostring(err)))
                end
                    end
                end
            )

        mission.hud.setControlledVehicle =
            Utils.appendedFunction(
                mission.hud.setControlledVehicle,
                function(_, vehicle)
                    if lightsSymbolHUDInstance ~= nil then
                        local ok, err = pcall(lightsSymbolHUDInstance.setVehicle, lightsSymbolHUDInstance, vehicle)
                        if not ok then
                            print(string.format("[LightsSymbolHUD] setVehicle runtime error: %s", tostring(err)))
                        end

                        -- When a vehicle becomes controlled, ask EWFS to refresh
                        -- its already-owned state. HUD never sets or clears EWFS.
                        local wfs = rawget(_G, "ReifenVerschleissWegfahrsperre")
                        if wfs ~= nil and type(wfs.refreshVehicleState) == "function" and vehicle ~= nil then
                            local okRefresh, refreshErr = pcall(wfs.refreshVehicleState, vehicle)
                            if not okRefresh then
                                print(string.format("[LightsSymbolHUD] EWFS refresh error: %s", tostring(refreshErr)))
                            end
                        end
                    end
                end
            )
    end
end


local function LSH_initSettingUI()
    if LightsSymbolHUDSettings ~= nil then
        if not LightsSymbolHUDSettings.settingsLoaded then
            LightsSymbolHUDSettings:loadSettings()
            LightsSymbolHUDSettings.settingsLoaded = true
        end
        LightsSymbolHUDSettings:initUI()
    end
end

local function LSH_unload()
    if lightsSymbolHUDInstance ~= nil then
        lightsSymbolHUDInstance:delete()
        lightsSymbolHUDInstance = nil
    end
end

Mission00.loadMission00Finished =
    Utils.appendedFunction(Mission00.loadMission00Finished, LSH_loadedMission)

if InGameMenu ~= nil then
    InGameMenu.onMenuOpened =
        Utils.appendedFunction(InGameMenu.onMenuOpened, LSH_initSettingUI)
end

FSBaseMission.saveSavegame =
    Utils.appendedFunction(FSBaseMission.saveSavegame, function()
        if LightsSymbolHUDSettings ~= nil then
            LightsSymbolHUDSettings:saveSettings()
        end
    end)

FSBaseMission.delete =
    Utils.appendedFunction(FSBaseMission.delete, LSH_unload)
